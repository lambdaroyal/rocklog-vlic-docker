//controllers.js

'use strict';

var vlic = angular.module('vlic', ['ui.router', 'ngDialog', 'ngWebsocket']);

vlic.controller('vlicCtrl', function ($scope, $rootScope, $state,
                                      USER_ROLES,
                                      AuthService) {
  $scope.logout = function() {
    AuthService.logout();
    $state.go("welcome");
  }
})

  .run(function ($rootScope, $state, USER_ROLES, AUTH_EVENTS, AuthService, ngDialog, $websocket, $location) {
    $rootScope.currentUser = null;
    $rootScope.userRoles = USER_ROLES;
    $rootScope.isAuthorized = AuthService.isAuthorized;
    $rootScope.isAuthenticated = AuthService.isAuthenticated;
    
    $rootScope.setCurrentUser = function (user) {
      $rootScope.currentUser = user;
    };

    (function initAutobahn() {
      $rootScope.autobahn = new Autobahn('ws://' + $location.$$host + ':' + $location.$$port + '/autobahn', {stateCallback: function(state) {
        console.log("[autobahn] transiated to state: " + state);
        
      }});
      $rootScope.autobahn.sub("worldmap", function(data) {
        console.log("received message on topic worldmap: " + JSON.stringify(data));
      });
    })();


    (function initWebSocket() {
      var path = 'ws://' + $location.$$host + ':' + $location.$$port + '/card/search';

      $rootScope.cardSearchWs = $websocket.$new({url: path,
                                                 lazy: true,
                                                 enqueue: true,
                                                 reconnect: true,
                                                 protocols: []});
      $rootScope.cardSearchWs
        .$on('$close', function () {
          console.log('Noooooooooou, I want to have more fun with ngWebsocket, damn it!');
        });
    })();

    $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
      //set the target the user wants to navigate to
      $rootScope.navigationTarget = [toState, toParams];
      var authorizedRoles = toState.data.authorizedRoles;
      if (!AuthService.isAuthorized(authorizedRoles)) {
        if (AuthService.isAuthenticated()) {
          // user is not allowed
          $rootScope.$broadcast(AUTH_EVENTS.notAuthorized);
        } else {
          // user is not logged in
          $rootScope.$broadcast(AUTH_EVENTS.notAuthenticated);
        }

      }});


    $rootScope.$on(AUTH_EVENTS.notAuthenticated, function(event, args) {
      event.preventDefault();
      ngDialog.open({
        className: 'ngdialog-theme-mine',
        showClose: false,
        closeByDocument: false,
        closeByEscape: false,
        template: 'login/loginModal.html',
        controller: 'loginModalCtrl'});

    });

    $rootScope.$on(AUTH_EVENTS.loginSuccess, function(event, args) {
      $rootScope.cardSearchWs.$open();

      //go to the desired target
      $state.go($rootScope.navigationTarget[0].name, $rootScope.navigationTarget);
      $rootScope.setCurrentUser(args);
    });
  })

  .directive('focusOn', function() {
    return function(scope, elem, attr) {
      scope.$on('focusOn', function(e, name) {
        if(name === attr.focusOn) {
          elem[0].focus();
        }
      });
    };
  })

  .factory('focus', function ($rootScope, $timeout) {
    return function(name) {
      $timeout(function (){
        $rootScope.$broadcast('focusOn', name);
      });
    }
  })

  .factory('StringBuffer', function() {
    /**
     * Fast String Buffer that avoid garbaging lots of immutable objects. comparable
     * to the StringBuffer of the java universe
     * 
     * @class
     * @returns {StringBuffer}
     */
    function StringBuffer() {
      this.buffer = [];
    };

    /**
     * Adds a string to the string buffer
     * 
     * @param string
     * @function
     */
    StringBuffer.prototype.append = function(string) {
      this.buffer.push(string);
      return this;
    };

    /**
     * Gives back the buffer content as a single string
     * 
     * @function
     */
    StringBuffer.prototype.toString = function() {
      return this.buffer.join("");
    };

    return StringBuffer;

  });
