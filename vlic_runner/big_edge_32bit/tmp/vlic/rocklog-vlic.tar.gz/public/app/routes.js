//routes.js

vlic.config(function ($stateProvider,$urlRouterProvider, USER_ROLES) {
  //
  // For any unmatched url, redirect to /state1
  $urlRouterProvider.otherwise("/worldmap");

  $stateProvider
    .state('worldmap', {
      url: '/worldmap',
      templateUrl: 'worldmap/worldmapPartial.html',
      controller: 'worldmapCtrl',
      data: {
        authorizedRoles: [USER_ROLES.all]
      },
    })  
    .state('welcome', {
      url: '/welcome',
      templateUrl: 'welcome/welcomePartial.html',
      data: {
        authorizedRoles: [USER_ROLES.all]
      }
    })
    .state('dashboard', {
      url: '/dashboard',
      templateUrl: 'dashboard/dashboardPartial.html',
      data: {
        authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
      }
    })
    .state('card', {
      url: '/card',
      templateUrl: 'card/cardPartial.html',
      controller: 'cardCtrl',
      data: {
        authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
      }
    })
    .state('xfer', {
      url: '/xfer',
      templareUrl: 'xfer/xferPartial.html',
      controller: 'xferCtrl',
      data: {
        authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]  
      }
    })
    .state('login', {
      url: '/login',
      templateUrl: 'login/loginPartial.html',
      data: {
        authorizedRoles: [USER_ROLES.all]
      }
    })
    .state('dataimport', {
      url: '/dataimport',
      templateUrl: 'dataimport/dataimportPartial.html',
      controller: 'dataimportCtrl',
      data: {
        authorizedRoles: [USER_ROLES.admin, USER_ROLES.editor]
      }
    });

})
