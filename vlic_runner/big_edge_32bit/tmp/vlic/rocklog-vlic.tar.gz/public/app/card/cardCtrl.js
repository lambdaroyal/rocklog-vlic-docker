vlic.controller('cardCtrl', function ($scope, $rootScope, StringBuffer, focus) {
  $scope.searchResultContainer = d3.select("#searchResultContainer");
  //denotes the entered text
  $scope.text = '';

  //denotes all entered texts since the most recent reset/start of the form.
  //this is used to rerun all searches of this history up to a certain point
  $scope.searchHistory = [];

  //denotes the number of elements at all, the elements fetched in last round as
  //well as the fetch time (ms)
  $scope.resultStats = {countOverall: 0, count: 0, fetchTime: 0, timeout: false};

  $scope.$on('updateCardStatsCount', function(event, arg) {
    $scope.resultStats.countOverall = $scope.resultStats.countOverall + arg.count;
    $scope.resultStats.count = arg.count;
    $scope.resultStats.fetchTime = arg.fetchTime;
  });

  $scope.submit = function() {
    if($scope.text) {
      $rootScope.cardSearchWs.$emit('search',{searchText: $scope.text});
      $scope.searchHistory.push($scope.text);
      $scope.text = '';
      focus("focusText");
    }
  };

  //resets the form in order to allow the user to submit a new search
  $scope.keyUp = function(e) {
    if(e.which == 27) {
      $scope.searchHistory = [];
      var cards = $scope.searchResultContainer.selectAll('div.card').data([]);
      cards.exit().remove();
    }
  };

  //redo the search by combining the search up to the search text searchHistory[index]
  $scope.redo = function(index) {
    //remove all visible cards
    var cards = $scope.searchResultContainer.selectAll('div.card').data([]);
    cards.exit().remove();

    //slice the array and do an interative search
    var sub = $scope.searchHistory.slice(0, index + 1);
    sub.map(function(n) {
      $rootScope.cardSearchWs.$emit('search', {searchText: n});
    });
    $scope.searchHistory = sub;
    $scope.text = '';
    focus("focusText");                                  
  }

  $rootScope.cardSearchWs.$on('searchStats', function(data) {
    //update the stats
    $rootScope.$broadcast('updateCardStatsCount', data);
  });

  $rootScope.cardSearchWs.$on('search', function(data) {
    console.log('The sebsocket server has sent the following search result:');
    console.log(data);

    //get those of interest
    var stockData = data.filter(function(d) {return d[1].coll === 'stock' && d[1].amount > 0});

    //aggregate some data for nested d3 binds
    stockData = stockData.map(function(d) {
      d[1]._amountHistory = [d[1].amount];
      if(d[1].origAmount && d[1].origAmount > d[1].amount) {
        d[1]._amountHistory.push(d[1].origAmount - d[1].amount);
        d[1]._amountColor = d3.scale.category10();
        d[1]._amountRatio = (d[1].amount / d[1].origAmount * 100).toFixed(0);
      } else {
        d[1]._amountColor = function(i) {return "green";};
      }
      return d;
    });

    var cards = $scope.searchResultContainer.selectAll('div.card').data(stockData, function(d){
      return new StringBuffer()
        .append(d[1].coll)
        .append('_')
        .append(d[1]._id)
        .toString();
    });

    var newCards = cards.enter()
        .append('div')
        .classed({
          'card': true,
          'cardStock': true
        });

    var renderPanel = function(parent, caption, fn) {
      var panel = parent.append('div').attr('class', 'cardPanel');
      panel.append('div').attr('class', 'cardAttrValue').text((fn));
      panel.append('div').attr('class', 'cardAttrCaption').text(caption);      
    }

    var renderAmount = function(parent) {

      var width = 55,
          height = 55,
          radius = Math.min(width, height) / 2;

      var pie = d3.layout.pie()
          .sort(null);

      var arc = d3.svg.arc()
          .innerRadius(radius)
          .outerRadius(radius - 5);

      var panel = parent.append('div').attr('class', 'cardPanel');
      var attrValue = panel.append('div').attr('class', 'cardAttrValue');

      var svg = attrValue.append("svg")
          .attr('class', 'amount')
          .attr("width", width)
          .attr("height", height)
          .append("g")
          .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");
      var path = svg.selectAll("path")
          .data(function(d){
            var r = pie(d[1]._amountHistory);
            for(i = 0; i < r.length; i++) {
              r[i]._amountColor = d[1]._amountColor;
            }
            return r;
          })
          .enter().append("path")
          .attr("fill", function(d,i) { 
            return d._amountColor(i);
          })
          .attr("d", arc);
      svg.append("text")
        .attr("class", "amount")
        .attr("text-anchor", "middle")
        .attr("x","0")
        .attr("y","0")
        .text(function(d) {
          return d[1].amount;
        })
      svg.append("text")
        .attr("class", "uom")
        .attr("text-anchor", function(d) {

          return d[1]._amountRatio ? "end" : "middle";})
        .attr("x",function(d) {
          return d[1]._amountRatio ? "-2" : "0";})
        .attr("y","10")
        .text(function(d) {
          return d[1].uom;
        });
      svg.append("text")
        .attr("class", "uom")
        .attr("text-anchor", function(d) {
          return d[1]._amountRatio ? "start" : "middle";})
        .attr("x","2")
        .attr("y","10")
        .text(function(d) {
          return d[1]._amountRatio ? d[1]._amountRatio + "%" : "";});

      panel.append('div').attr('class', 'cardAttrCaption').text("Amount");

    }

    var renderLocation = function(parent) {
      var width = 81,
          height = 55;

      var panel = parent.append('div').attr('class', 'cardPanel');
      var attrValue = panel.append('div').attr('class', 'cardAttrValue');

      var svg = attrValue.append("svg")
          .attr('class', 'amount')
          .attr("width", width)
          .attr("height", height)
          .append("g")
          .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");
      svg.append("path")
        .attr("d", "M 0 -13 L 0 12")
        .attr("stroke", "#404040")
        .attr("visibility", function(d) {
          var loc = d[1].location[1];
          return loc.ebene || loc.feld ? "visible" : "hidden";
        });

      //render only area
      svg.append("text")
        .attr("class", "location-vbig")
        .attr("text-anchor", "middle")
        .attr("x","0")
        .attr("y","0")
        .text(function(d) {
          var loc = d[1].location[1];
          return loc.bereich;
        })
        .attr("visibility", function(d) {
          var loc = d[1].location[1];
          return loc.ebene || loc.feld ? "hidden" : "visible";
        });

      //render only level
      svg.append("text")
        .attr("class", "location-big")
        .attr("text-anchor", "start")
        .attr("x","1")
        .attr("y","0")
        .text(function(d) {
          var loc = d[1].location[1];
          var r = new StringBuffer();
          if(loc.ebene) {
            r.append(loc.ebene.toString().startsWith("ebene") ? loc.ebene : ("Ebene " + loc.ebene));
          }
          return r.toString();

        })
        .attr("visibility", function(d) {
          var loc = d[1].location[1];
          return loc.ebene ? "visible" : "hidden";
        });

      //render only field
      svg.append("text")
        .attr("class", "location-big")
        .attr("text-anchor", "end")
        .attr("x","-1")
        .attr("y","0")
        .text(function(d) {
          var loc = d[1].location[1];
          var r = new StringBuffer();
          if(loc.feld) {
            r.append(loc.feld.toString().startsWith("feld") ? loc.feld : ("Feld " + loc.feld));
          }
          return r.toString();

        })
        .attr("visibility", function(d) {
          var loc = d[1].location[1];
          return loc.feld ? "visible" : "hidden";
        });

      //render gang/seite
      svg.append("text")
        .attr("class", "location-small")
        .attr("text-anchor", "end")
        .attr("x","-1")
        .attr("y","10")
        .text(function(d) {
          var loc = d[1].location[1];
          if(loc.gang) {
            return loc.gang.toString().startsWith("gang") ? loc.gang : ("Gang " + loc.gang);
          } else {
            return "";
          }
        });
      svg.append("text")
        .attr("class", "location-small")
        .attr("text-anchor", "start")
        .attr("x","1")
        .attr("y","10")
        .text(function(d) {
          var loc = d[1].location[1];
          if(loc.seite) {
            return loc.seite;
          } else {
            return "";
          }
        });
      panel.append('div').attr('class', 'cardAttrCaption').text("Location");


    }

    var renderLuType = function(parent) {
      var width = 55,
          height = 55;

      var panel = parent.append('div').attr('class', 'cardPanel');
      var attrValue = panel.append('div').attr('class', 'cardAttrValue');

      var svg = attrValue.append("svg")
          .attr('class', 'amount')
          .attr("width", width)
          .attr("height", height)
          .append("g")
          .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");
      svg.append("text")
        .attr("class", "luType")
        .attr("text-anchor", "middle")
        .attr("x","0")
        .attr("y","0")
        .text(function(d) {
          return d[1].luType;
        });
      panel.append('div').attr('class', 'cardAttrCaption').text("Loadunit");


    }
    


    var renderStockCards = function(cards) {
      var cardActions = cards.append('div').attr('class', 'cardActions');
      cardActions.append('span').attr('class', 'glyphicon glyphicon-transfer');
      cardActions.append('span').attr('class', 'glyphicon glyphicon-trash');
      var cardMain = cards.append('div').attr('class', 'cardMain');

      var cardHeaders = cardMain.append('div').attr('class','cardHeader');
      renderPanel(cardHeaders, 'Ident', function(d) {return d[1].ident;});
      renderPanel(cardHeaders, 'Article', function(d) {return d[1].article[1].ident;});
      renderPanel(cardHeaders, 'Type', function(d) {return d[1].coll;});
      

      //body with major attributes
      var cardBody = cardMain.append('div').attr('class', 'cardBody');
      renderAmount(cardBody);
      renderLocation(cardBody);
      renderLuType(cardBody);
    }


    renderStockCards(newCards);
    /*

      var articleData = data.filter(function(d) {return d[1].coll === 'article'});

      var cards = $scope.searchResultDivs.data(articleData, function(d){
      return new StringBuffer()
      .append(d[1].coll)
      .append('_')
      .append(d[1]._id)
      .toString();
      });

      var newCards = cards.enter()
      .append('div')
      .classed({
      'card': true,
      'cardData': true
      });

      var cardHeaders = cards.append('div').attr('class','cardHeader');
      cardHeaders.append('div').attr('class', 'cardIdent')
      .text(function(d) {
      return d[1].ident;
      });
      cardHeaders.append('div').attr('class', 'cardType')
      .text(function(d) {
      return d[1].coll;
      });

      //body with major attributes
      var cardBody = cards.append('div').attr('class', 'cardBody');
      cardBody.append('div').attr('class', 'cardCaption')
      .text('Class');
      cardBody.append('div').attr('class', 'cardAttributeRight')
      .text(function(d) {
      return d[1].güteklasse;
      });
      cardBody.append('div').attr('class', 'cardCaption')
      .text('Storage');
      cardBody.append('div').attr('class', 'cardAttributeRight')
      .text(function(d) {
      return d[1].lagereigenschaft;
      });
      cardBody.append('div').attr('class', 'cardCaption')
      .text('Vendor');
      cardBody.append('div').attr('class', 'cardAttributeFloatRight')
      .text(function(d) {
      return d[1].lieferant;
      });
      cardBody.append('div').attr('class', 'cardCaption')
      .text('');
    */
    //    cards.exit().remove();

  });
});
