// dataimportCtrl.js

vlic.constant('LOC_DATAIMPORT', {
  loadingCardtypesFailed: 'Cannot load cardtypes, dataimport currently not possible',
  loadingCardtypeimportdefinitionsFailed: 'Cannot load cardtype importdefinitions, dataimport currently not possible'})
  .controller('dataimportCtrl', function ($scope, $rootScope, $http, errors, focus, LOC_DATAIMPORT) {

    $scope.$on('$viewContentLoaded', function f() {
        $scope.cardtypes = $http.get("/cardtype").then(function(res) {
          $scope.cardtypes = res.data;
        }, errors.catch(LOC_DATAIMPORT.loadingCardtypesFailed));
    });
  })

