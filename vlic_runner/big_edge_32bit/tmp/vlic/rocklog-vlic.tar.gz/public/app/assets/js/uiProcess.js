/**
 * Classes for controlling visual processes. A process consists of several steps. A step can be submitted (go to next state) or cancelled
 * (go to the previous state)
 *
 */
"use strict";

var GlobalCount = {
  current: 0,
  get: function() {
    this.current = this.current + 1;
    return "UIProcessStep_" + this.current;
  }
}

var UIProcessStepState = Object.freeze({
  "INACTIVE": 0 ,
  "INITIALIZING": 1,
  "ACTIVE": 2 ,
  "READY_TO_SUBMIT": 3,
  "SUBMITTING": 4 // and back to INITIALIZING
});

var UIProcessStep = function() {
  return {
    id: GlobalCount.get(),
    /** reference to aggregating process */
    process: null,
    state: m.prop(UIProcessStepState.INACTIVE),
    /** this callback is used by the abstract part of this equation, (this class) that calls this function with true/false.
     * the concrete part UIProcessStepComponent pop of flag in order to update the busy state of the submit button
     */
    longRunningBusy: function(f){},
    checkLongRunning : function() {
      if(this.state() === UIProcessStepState.INITIALIZING || this.state() === UIProcessStepState.SUBMITTING) {
        this.longRunningBusy(true);
      } else {
        this.longRunningBusy(false);
      }
    },
    setState: function(s) {
      //invoke some timer if in busy state
      this.state(s);

      if(s === UIProcessStepState.INITIALIZING || s === UIProcessStepState.SUBMITTING) {
        (function(step) {
          setTimeout(function() {
            step.checkLongRunning();
          },500)})(this);
      } else {
        //reset
        this.longRunningBusy(false);
      }
    },
    title: "",
    /**
     * null or string, denotes the caption of the cancel button and at the same time whether a cancel symbol is included after the title
     */
    cancel: "Cancel",
    /**
     * null or string, denotes the caption the submit button and at the same time whether there is a submit button at all
     */
    submit: "Submit",
    /** denotes whether the user can input something within this step at all, if an non-interactive step is submitted/cancelled then the next/previous interactive state gets activated but the onEnter function of all non-interactive steps on the way gets called with retainContent=true*/
    submitEnabled: m.prop(true),
    interactive: true,
    /** gets called when the aggregating process is initialized */
    onProcessInit: null,
    /** gets called when the steps gets entered (either first step or next after submit or previous after cancel), must call the provided callback to process further*/
    onEnter: function(retainContent, callback) {
      callback();
    },
    /** gets called when the steps gets exited, must call the provided callback to process further*/
    onExit: function(callback, forward) {
      callback();
    }
  }
}


var UIProcess = function(){
  return {
    steps: [],
    add: function(step) {
      step.process = this;
      this.steps.push(step)
    },
    activeStep: null,
    init: function() {
      for(var i in this.steps) {
        var step = this.steps[i];
        if(step.onProcessInit) {
          step.onProcessInit();
        }
      }

      if(this.steps.length > 0) {
        this.steps[0].onEnter(false, this.afterOnEnterCallback.bind(this, true, this.steps[0]));
        
        this.steps[0].setState(UIProcessStepState.ACTIVE);
        this.activeStep = 0;
      }
    },

    /** must be called within onEnter in order to transiate a step further from INITIALIZING -> ACTIVE */
    afterOnEnterCallback: function(forward, step) {
      step.setState(UIProcessStepState.ACTIVE);
      //jump further if we face a non-interactive step
      if(!step.interactive) {
        this.transiate(forward);
      } else {
        this.scrollTo();
      }
    },

    afterOnExitCallback: function(forward, step, doContinue) {
      if(doContinue !== false) {
        if(step) {
          step.setState(UIProcessStepState.INACTIVE);
        }
        var nextStep = forward ? (this.steps.length > this.activeStep + 1 ? this.steps[this.activeStep + 1] : null ) : (this.activeStep > 0 ? this.steps[this.activeStep - 1] : null);
        if(nextStep !== null) {
          this.activeStep = this.activeStep + (forward ? 1 : -1);
          //if we jump back to a interactive step we retain all content
          nextStep.setState(UIProcessStepState.INITIALIZING);
          nextStep.onEnter(!forward && nextStep.interactive, this.afterOnEnterCallback.bind(this, forward, nextStep));
        }

      } else {
        step.setState(UIProcessStepState.ACTIVE);
      }
      m.endComputation();
    },

    /** enter the previous/next step */
    transiate: function(forward) {
      //fast fail
      if(this.steps.length == 0) {
        return false;
      }    
      
      //if we face the first one and the user cancels we quit
      if(!forward && this.activeStep === 0) {
        return false;
      }
      //workhorse

      m.startComputation();

      //first time: no onExit on current one
      if(this.activeStep === null) {
        this.activeStep = forward ? 0 : this.steps[this.steps.length - 1];
        this.afterOnExitCallback(forward, null);
      } else {
        var oldStep = this.steps[this.activeStep];
        oldStep.setState(UIProcessStepState.SUBMITTING);
        oldStep.onExit(this.afterOnExitCallback.bind(this, forward, oldStep), forward);
      }

    },

    /**brings the current process step to the upper bound, if its bottom is down the absolute bottom*/
    scrollTo: function() {
      if(this.activeStep) {
        var step = this.steps[this.activeStep];
        var rects = document.getElementById(step.id).getBoundingClientRect();
        if(rects.bottom > window.innerHeight) {
          d3_queue.queue().defer(function() {
            window.scrollBy(0, rects.bottom - window.innerHeight + 10);
          });
        }
      }
    },

    setCurrentStepActive: function() {
      if(this.activeStep) {
        var step = this.steps[this.activeStep];
        step.setState(UIProcessStepState.ACTIVE);
     }
    },
    
    submit: function() {
      this.transiate(true);
    },

    cancel: function() {
      this.transiate(false);
    }
  }
}

///////////////////////////////////////////////////////////////////
// mithril related stuff, binding of ViewModel components
// to concrete UI Components
///////////////////////////////////////////////////////////////////

var UIProcessComp = {
  /**
   * requests args.process to be a UIProcess
   */
  view: function(ctrl, args) {
    args.steps = args.steps || [];
    return m("div[class=uiProcess]", 
             
             args.process.steps.map(function(step) {
               return m.component(UIProcessStepComp, {step: step});
             }));
  }
}

var UIProcessStepComp = {
  /**
   * requests args.step to be UIProcessStep and optional args.step.component denoting the factory function to create the inner component
   */
  view: function(ctrl, args) {
    var body = [];
    if(args.step.component) {
      body.push(m.component(args.step.component, args));
    }
    var active = args.step.state() === UIProcessStepState.ACTIVE;

    if(args.step.interactive) {
      if(args.step.submit) {
        body.push(m("button",{type:"button",class:"btn btl-lg btn-success", disabled: (!active || !args.step.submitEnabled()), onclick: args.step.process.submit.bind(args.step.process)}, 
                    [m("span",{id: "submit.span." + args.step.id}),args.step.submit]));
        body.push(m("span", " "));
      }
      if(args.step.cancel) {
        body.push(m("button",{type:"button",class: "btn btn-danger", disabled: !active, onclick: args.step.process.cancel.bind(args.step.process)}, args.step.cancel));
      }
    }

    if(!args.step) {
      throw("UIProcessStepComp must be called with args containing a 'step' attribute denoting a UIProcessStep instance");
    }

    //register callback for proper busy handling
    args.step.longRunningBusy = function(f) {
      var elem = document.getElementById("submit.span." + args.step.id);
      if(elem) {
        elem.className = f ? "glyphicon glyphicon-refresh glyphicon-refresh-animate" : "";
      }
    }

    var xs = [];
    if(args.step.title != "") {
      xs.push(m("div[class=panel-heading]", args.step.title));
    }
    xs.push(m("div[class=panel-body]", body));

    return m("div",{id: args.step.id, class: active ? "uiStep panel panel-primary" : "uiStep panel panel-default"}, xs);
  }  
}
