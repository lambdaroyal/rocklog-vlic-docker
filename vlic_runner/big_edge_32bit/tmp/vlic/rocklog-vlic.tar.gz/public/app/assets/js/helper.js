/**
 * Fast String Buffer that avoid garbaging lots of immutable objects. comparable
 * to the StringBuffer of the java universe
 * 
 * @class
 * @returns {StringBuffer}
 */
var LRStringBuffer = function() {
  this.buffer = [];
};

/**
 * Adds a string to the string buffer
 * 
 * @param string
 * @function
 */
LRStringBuffer.prototype.append = function(string) {
  this.buffer.push(string);
  return this;
};

/**
 * Gives back the buffer content as a single string
 * 
 * @function
 */
LRStringBuffer.prototype.toString = function() {
  return this.buffer.join("");
};

enumerator = function(store) {
  var prop = function() {
    if(arguments.length) {
      store = arguments[0];
    } else {
      store = store + 1;   
    }
    return store;
  }
  return prop;
};

propWithCallback = function(store, fn) {
		var prop = function() {
			if (arguments.length) {
                          var old = store;
                          store = arguments[0];
                          if(fn) {
                            fn(store, old);
                          }
                        }
			return store;
		};

		return prop;
	}

//applies only the last call to lambda that occured within a interval of time [threshhold] in ms, or the first one if no one occured before, default threshold is 250ms, yields a function.
function throttle(fn, threshhold) {
  threshhold || (threshhold = 250);

  var last, deferTimer;
  return function () {
    var now = +new Date,
        args = arguments;
    if (last && now < last + threshhold) {
      // hold on to it
      clearTimeout(deferTimer);
      deferTimer = setTimeout(function () {
        last = now;
        fn.apply(this, args);
      }, threshhold);
    } else {
      last = now;
      fn.apply(this, args);
    }
  };
}

//applies only the last call to lambda that occured within a interval of time [threshhold] in ms, or the first one if no one occured before, default threshold is 250ms, yields an object that provides the function get() that can be called on unthrottled events as well as a function flush() that immediately executes a pending event (if any) and returns true iff there was a pending event
function throttleWrap(fn, threshhold) {
  threshhold || (threshhold = 250);

  var last, deferTimer, lastArgs;

  var get = function() {
    var now = +new Date,
        lastArgs = (args = arguments);
    if (last && now < last + threshhold) {
      // hold on to it
      clearTimeout(deferTimer);
      lastArgs = args;
      deferTimer = setTimeout(function () {
        last = now;
        fn.apply(this, args);
      }, threshhold);
    } else {
      last = now;
      fn.apply(this, args);
    }
  };

  var flush = function() {
    var now = +new Date;
    if(last && now < last + threshhold) {
      clearTimeout(deferTimer);
      last = now;
      fn.apply(this, args);
      return true;
    } else {
      return false;
    }
  };

  var cancel = function() {
    var now = +new Date;
    if(last && now < last + threshhold) {
      clearTimeout(deferTimer);
      last = now;
      return true;
    } else {
      return false;
    }
  };


  return {get: function() {return get}, flush: function() {return flush}, cancel: function() {return cancel}};
}

//sets the ui focus to an element given by id without mithril redraw
var focus = focus || function(id) {
  setTimeout(function() {
    var div = document.getElementById(id);
    if(div) {
      div.focus();
    }
  }, 20)}

//A simple way to optimize this is to use partial application to pre-bind a controller instance
var submodule = submodule || function(module, args) {
  return module.view.bind(this, new module.controller(args))
}


//check for ipad/iphone
var isApfel = isApfel || navigator.userAgent.match(/iPad/i) != null || navigator.userAgent.match(/iPhone/i) != null;

var docPath = function(node, path, attr, empty, pos) {
  var pos = (pos || 0);

  if(node === undefined || node[1] === undefined || !(typeof node[1] === "object")) {
    return empty;
  }

  if(path.length == pos) {
    return node[1][attr] !== undefined && node[1][attr] !== "" ? node[1][attr] : empty;
  }

  //get to the proper child
  node = node[1][path[pos]];

  if(node !== undefined) {
    return docPath(node, path, attr, empty, pos + 1);
  } else {
    return empty;
  }
  
}


var setAttrToPath = function(node, path, attr, value, pos) {
  var pos = (pos || 0);
  if(node === undefined || node[1] === undefined || !(typeof node[1] === "object")) {
    return;
  }

  if(path.length == pos) {
    if(node[1][attr] !== undefined && (typeof node[1][attr] === "number")) {
      value = parseInt(value);
    }
    node[1][attr] = value;
    return;
  }

  //get to the proper child
  node = node[1][path[pos]];

  if(node !== undefined) {
    setAttrToPath(node, path, attr, value, pos + 1);
  }
  
}
//given a lambdamemory tupel data path consisting of path elements [path] and an attribute [attr] returns a string representation for easy mapping
var pathToString = function(path, args) {
  return path.reduce(function(acc, i) {
    return acc.append("/").append(i);
  }, new LRStringBuffer()).append("[").append(args).append("]").toString();
}

/**
 * traverses a data hierarchie by path [prefix], which is a seq of tupels where first elem is topology name and second is topology element value
 */
var hierarchieDfs =  function(data, prefix) {
  if(!data) {
    return undefined;
  }
  if(!prefix || prefix.length === 0) {
    return data;
  }
  var xs = data.filter(function(x) {
    return x.k && x.k === prefix[0][1];
  });
  var x = xs.length > 0 ? xs[0] : undefined;

  if(x) {
    var prefix = prefix.slice(1);
    if(prefix.length > 0) {
      return hierarchieDfs(x.v, prefix);
    } else {
      return x;
    }
  }

  return undefined;
}

