// loginCtrl.js

vlic.constant('AUTH_EVENTS', {
  loginSuccess: 'auth-login-success',
  loginFailed: 'auth-login-failed',
  logoutSuccess: 'auth-logout-success',
  sessionTimeout: 'auth-session-timeout',
  notAuthenticated: 'auth-not-authenticated',
  notAuthorized: 'auth-not-authorized'
})

  .constant('USER_ROLES', {
    all: '*',
    admin: 'admin',
    editor: 'editor',
    std: 'std'
  })

  .controller('loginModalCtrl', function ($scope, $rootScope, AUTH_EVENTS, AuthService, focus) {
    $scope.credentials = {
      accepted: false,
      email: '',
      password: '',
      nameForCreate: '',
      passwordForCreate: '',
      emailForCreate: '' 
    };
    $scope.submit = function (credentials) {
      AuthService.login(credentials).then(function (user) {
        $scope.closeThisDialog();
        $rootScope.$broadcast(AUTH_EVENTS.loginSuccess, user);
      }, function (err) {
        $scope.errors = [err.data];
        focus("focusEmail");
        $rootScope.$broadcast(AUTH_EVENTS.loginFailed);
      });
    };
    $scope.create = function (credentials) {
      AuthService.create(credentials).then(function(user) {
        $scope.closeThisDialog();
        $rootScope.$broadcast(AUTH_EVENTS.loginSuccess, user);
      }).catch(function(err) {
        $scope.errors = [err.data];
        focus("focusNameForCreate");
        $rootScope.$broadcast(AUTH_EVENTS.loginFailed);        
      });
    };

  })
