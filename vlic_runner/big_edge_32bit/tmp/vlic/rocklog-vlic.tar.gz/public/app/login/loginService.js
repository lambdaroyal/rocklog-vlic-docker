//loginService.js

vlic.service('Session', function () {
  this.create = function (sessionId, userName, userRole) {
    this.id = sessionId;
    this.userName = userName;
    this.userRole = userRole;
  };
  this.destroy = function () {
    this.id = null;
    this.userName = null;
    this.userRole = null;
  };
})

  .factory('AuthService', function ($http, Session, USER_ROLES) {
    var authService = {};
    
    authService.login = function (credentials) {
      Session.destroy();
      return $http
        .post('/auth/login', credentials)
        .then(function (res) {
          Session.create(res.data.id, res.data.user.name,
                         res.data.user.role);
          return res.data.user;
        });
    };

    authService.logout = function() {
      Session.destroy();
    }


    authService.create = function (credentials) {
      return $http.post('/auth/create', credentials)
        .then(function(res) {
          Session.create(res.data.id, res.data.user.name,
                         res.data.user.role);
          return res.data.user;
        });
    };
    
    authService.isAuthenticated = function () {
      return !!Session.userName;
    };

    authService.session = function () {
      return Session;
    }
    
    authService.isAuthorized = function (authorizedRoles) {
      if (!angular.isArray(authorizedRoles)) {
        authorizedRoles = [authorizedRoles];
      }
      return authorizedRoles.indexOf(USER_ROLES.all) !== -1 ||
        (authService.isAuthenticated() &&
         authorizedRoles.indexOf(Session.userRole) !== -1);
    };
    
    return authService;
  })

  .config(function ($httpProvider) {
    $httpProvider.interceptors.push([
      '$injector',
      function ($injector) {
        return $injector.get('AuthInterceptor');
      }
    ]);
  })

  .factory('AuthInterceptor', function ($rootScope, $q,
                                        AUTH_EVENTS) {
    return {
      responseError: function (response) { 
        $rootScope.$broadcast({
          401: AUTH_EVENTS.notAuthenticated,
          403: AUTH_EVENTS.notAuthorized,
          419: AUTH_EVENTS.sessionTimeout,
          440: AUTH_EVENTS.sessionTimeout
        }[response.status], response);
        return $q.reject(response);
      }
    };
  })


