var login = {
  Session: (function() {
    this.create = function (sessionId, userName, userRole, obj) {
      this.id = sessionId;
      this.userName = userName;
      this.userRole = userRole;
      this.obj = obj;
      //this property denotes the id of the numberrange currently assigned to the user
      this.sidNumberrange = propWithCallback(obj[1].sidNumberrange, function(n) {
        global.autobahn.sync({event:"user", data: {user: login.Session.obj[0], nrange: n} , sessionId: global.autobahn.sessionId, fn: "set-sid-numberrange"}).catch(function(msg) {
          console.log(msg);
        });;

      });
    };
    this.destroy = function () {
      this.id = null;
      this.userName = null;
      this.userRole = null;
    };

    return this;
  }())
};

login.vm = (function() {
  var vm = {checked: m.prop(false)};

  vm.credentials = {
    accepted: false,
    email: '',
    password: '',
    nameForCreate: '',
    passwordForCreate: '',
    passwordForCreateRetype: '',
    emailForCreate: '' 
  };

  vm.errors = [];

  vm.submit = function() {
    vm.errors = [];
    login.Session.destroy();
    m.request({method: "POST", url: global.pathnamePrefix + "/auth/login", deserialize: function(value) {
      return value;
    },
               data: vm.credentials})
      .then(function(res) {
        res = JSON.parse(res);
        login.Session.create(res.id, res.user.name,
                             res.user.role, res.user.obj);
        route("/search", searchRoot);
      }, function(err) {
        vm.errors.push(err);
      });
    return false;
  }

  vm.createUser = function() {
    vm.errors = [];
    if(vm.credentials.passwordForCreateRetype != vm.credentials.passwordForCreate) {
      vm.errors.push("Password and retyped password do not match. Try again.");
      vm.credentials.passwordForCreateRetype = vm.credentials.passwordForCreate = "";
      return false;
    }
    login.Session.destroy();
    m.request({method: "POST", url: global.pathnamePrefix + "/auth/create", deserialize: function(value) {
      return value;
    },
               data: vm.credentials})
      .then(function(res) {
        res = JSON.parse(res);
        login.Session.create(res.id, res.user.name,
                             res.user.role, res.user.obj);
        route("/search", searchRoot);
      }, function(err) {
        vm.errors.push(err);
      });
    return false;
  }

  vm.init = function() {
    login.Session.destroy();
    d3.select("div#spa").selectAll("div[role=auth]").style("visibility", "hidden");
    //disable all content except for login
    invariants.vm.functions.enable("logout", false);
  };

  return vm;

}());

login.controller = function() {
  login.vm.init();
  return {
    onunload: function() {
      d3.select("div#spa").selectAll("div[role=auth]").style("visibility", "");
      invariants.vm.functions.enable("logout", login.Session.id !== undefined);
      login.vm.credentials = {
        accepted: false,
        email: '',
        password: '',
        nameForCreate: '',
        passwordForCreate: '',
        passwordForCreateRetype: '',
        emailForCreate: '' 
      }
    }
  };
}

login.view = function(controller) {
  //since we migrated from good old angularjs we don't have m.props so we we have to have this lambda
  var set = function(attr, n){ login.vm.credentials[attr] = n;}

  return  <div class="modal-dialog">
    <div class="modal-dialog-content">
    <div class="modal-box"> 
    <div class="row">
    <div class="col-md-6">
    <h3 class="bottom">Sign In</h3> 
    <form onsubmit={login.vm.submit.bind(login.vm)} target="#" role="form">
    <div class="form-group">
    <label for="email">Email</label>
    <input type="email" class="form-control" 
  oninput={m.withAttr("value", set.bind(this, "email"))} 
  focus-on="focusEmail"/>
    </div>
    <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control"
  oninput={m.withAttr("value", set.bind(this, "password"))}/>
    </div>
    <input type="submit" class="btn btn-success"/>
    </form>
    </div>
    <div class="col-md-6">
    <h3 class="bottom">Create-Account</h3> 
    <div class="form-group">
    <form onsubmit={login.vm.createUser.bind(login.vm)} role="form">
    <div class="form-group">
    <label for="name">Name</label>
    <input type="name" class="form-control" 
  value={(function(){return login.vm.credentials.nameForCreate}())}
  oninput={m.withAttr("value", set.bind(this, "nameForCreate"))}
  focus-on="focusNameForCreate"/>
    </div>
    <div class="form-group">
    <label for="email">Email</label>
    <input type="email" class="form-control"
  value={(function(){ return login.vm.credentials.emailForCreate}())}
  oninput={m.withAttr("value", set.bind(this, "emailForCreate"))}
    />
    </div>
    <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control"
  value={(function(){ return login.vm.credentials.passwordForCreate}())}
  oninput={m.withAttr("value", set.bind(this, "passwordForCreate"))}
    />
    </div>
    <div class="form-group">
    <label for="password">Retype Password</label>
    <input type="password" class="form-control" 
  value={(function(){ return login.vm.credentials.passwordForCreateRetype}())}
  oninput={m.withAttr("value", set.bind(this, "passwordForCreateRetype"))}
    />
    </div>
    <div class="form-group">
    <div class="checkbox">
    <label><input type="checkbox" 
  checked={login.vm.checked()}  onclick={m.withAttr("checked", login.vm.checked)}/> I accept <a href="#">Terms of Service</a> of planet rocklog</label>
    </div>
    </div>
    <input type="submit" ng-model="button" disabled={!login.vm.checked()} class="btn btn-success"/>
    </form>
    </div>
    </div>
    </div>
    <div class="row">
    <div class="col-md-12">
    <div class="form-group">
    <div class="col-xs-9 col-xs-offset-3">
    {(function(){
      if(login.vm.errors.length>0) {
        return m("ul",{id: "errors"}, login.vm.errors.map(function(n) {
          return m("li", n);
        }));
      }
    }())}
  </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
}


