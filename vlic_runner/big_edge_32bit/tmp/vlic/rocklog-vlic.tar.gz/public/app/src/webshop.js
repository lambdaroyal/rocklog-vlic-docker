//Webshop.js - pick from DIDs that where selected in search panel

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state,
// this gets scoped without regard to the controller
// so this won't die if the user steps out of a
// mithril modul that gets unmounted
/////////////////////////////////////////////////////

var webshopRoot = {}
var webshopFunctions = {}
var webshopCards = {
  text: m.prop(""),
  data: [],
  lidPrefix: m.prop([])
}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////

webshopRoot.vm = {
  onload: function() {
    this.dialog = new ModalMessageBar("webshop");
  },
  onunload: function() {
    if(this.dialog) {
      this.dialog.abort();
    }
  }
}

webshopFunctions.vm = {
  init: function() {
    webshopFunctions.vm.functions = new FunctionPanel(
      {
        checkout: {imageClass: "glyphicon glyphicon-shopping-cart", tooltip: "Checkout to confirm picks", enabled: false, onclick: this.oncheckout.bind(this)},
        home: {imageClass: "glyphicon glyphicon-home", tooltip: "Cancel Basket and back to search", onclick: function() {
          route("/search", searchRoot);
        }, enabled: true}});
  },

  oncheckout: function() {
    //search for the articles
    var relevantDids = webshopCards.data.filter(function(n) {
      return n[1]._pickAmount && n[1]._pickAmount > 0; 
    });
    global.autobahn.sync({event:"pick", fn: "pick", sessionId: global.autobahn.sessionId, data: {"lid-prefix": (webshopCards.lidPrefix() || []), dids: relevantDids}})
      .then(function(data) {
        webshopCheckoutCards.data = data.data["picked-sids"];
        route("/webshopCheckout", webshopCheckoutRoot);
      })
      .catch(function(msg) {
        webshopRoot.vm.dialog.show({severity: ModalMessageSeverity.WARNING,
                                    message: msg,
                                    title: "Checkout Failed. Try again.",
                                    onOk: function(callback) {
                                      callback();
                                    }
                                   })});
  }
}

webshopCards.vm = {
  onClick: function(d, cardSelect) {
    if(d[1]._reservedAmount && d[1]._reservedAmount >= d[1].amount) {
      webshopCards.vm.cardPanel.flashCard(cardSelect, true);
    } else { 
      
      if(!webshopFunctions.vm.functions.enabled("checkout")) {
        m.startComputation();
        webshopFunctions.vm.functions.enable("checkout", true);
        m.endComputation();
      };

      d[1]._pickAmount = d[1]._reservedAmount = d[1]._reservedAmount ? d[1]._reservedAmount + 1 : 1;
      
      //if we got here for the first time we update the minus in order to allow decrements
      if(d[1]._pickAmount == 1) {
        webshopCards.vm.cardPanel.updateMinusFunel(cardSelect);
      }

      webshopCards.vm.cardPanel.updateAmount(d, cardSelect);
      webshopCards.vm.cardPanel.flashCard(cardSelect, false);
    }
  },

  onClickMinus: function(d, cardSelect) {
    d[1]._pickAmount = d[1]._pickAmount - 1;
    d[1]._reservedAmount = d[1]._reservedAmount - 1;

    if(webshopFunctions.vm.functions.enabled("checkout")) {
      if(webshopCards.vm.cardPanel.getCards().filter(function(n) {
        return n[1]._pickAmount && n[1]._pickAmount > 0; 
      }).empty()) {  
        m.startComputation();
        webshopFunctions.vm.functions.enable("checkout", false);
        m.endComputation();
      }
    };
    
    if(d[1]._pickAmount == 0) {
      webshopCards.vm.cardPanel.updateMinusFunel(cardSelect);
    }

    webshopCards.vm.cardPanel.updateAmount(d, cardSelect);
    webshopCards.vm.cardPanel.flashCard(cardSelect, false);
  },

  beforeLoad: function() {
    webshopCards.text("");
  },

  onload: function() {
    this.focus();

    //init the cardPanel
    var container = document.getElementById("spaLeft");
    this.cardPanel = new CardPanel(container, 
                                   {onClick: this.onClick, 
                                    onClickMinus: this.onClickMinus,
                                    defaultWidth: 85,
                                    selectOnClick: false});
    this.cardPanel.render(webshopCards.data, true);
  },

  onunload: function() {
    if(this.cardPanel) {
      this.cardPanel.remove();
    }
  },

  oninput : function(value) {
    webshopCards.text(value);
  },
  onkeyup : function(event) {
    webshopCards.vm.search();
  },
  redo: function() {
    webshopCards.text("")
  },
  search: throttle(function() {
    if(webshopCards.text()) {
    }
  }, 300),

  focus: function() {
    setTimeout(function() {
      var div = document.getElementById("searchInput");
      if(div) {
        div.focus();
      }
    }, 20)},
  init: function() {
    
  }
};

var WebshopInputComp = {
  renderLidPrefixSpan: function() {
    if(webshopCards.lidPrefix()) {
      return <div class="form-control searchHistory">
        <a onclick={webshopCards.vm.redo.bind(webshopCards.vm)}><span class="glyphicons glyphicons-filter" title="Click here to search for all SIDs as per the choosen location" data-toggle="tooltip" data-placement="top"/></a></div>
    } else {
      return undefined;
    }
  },

  view: function(ctrl, args) {
    return <div onkeyup={webshopCards.vm.onkeyup.bind(webshopCards.vm)} class="searchContainer form-inline pull-right ng-pristine ng-valid" role="form" autocomplete="off">
      <div class="form-group inner-addon left-addon pull-right">
      <div class="input-group">
      <i class="glyphicon glyphicon-search"></i>
      <input id={args.id} type="text" class="form-control my-input ng-pristine ng-untouched ng-valid" name="text" placeholder="Enter to search" data-toggle="tooltip" data-placement="top" title="Press ESC to discard all cards and to search again" focus-on="focusText" oninput={m.withAttr("value", webshopCards.vm.oninput.bind(webshopCards.vm))} value={args.webshopCards.text()}/> 
      </div>
      </div>
      <div class="form-group">
      {this.renderLidPrefixSpan()}
    </div>
      </div>
  }
}

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////

webshopFunctions.controller = function() {
  webshopFunctions.vm.init();
};
webshopFunctions.view = function(ctrl) {
  return webshopFunctions.vm.functions.view(ctrl);
}

webshopCards.controller = function() {
  webshopCards.vm.init();
};
webshopCards.view = function(ctrl) {
  return m.component(WebshopInputComp, {id: "searchInput", webshopCards: webshopCards});
}

webshopRoot.controller = function() {
  return {
    webshopFunctions : submodule(webshopFunctions),
    webshopCards : submodule(webshopCards),

    onunload: function() {
      webshopCards.vm.onunload();
      webshopRoot.vm.onunload();
    }
  }
}

webshopRoot.onload = function() {
  webshopRoot.vm.onload();
  webshopCards.vm.onload();
}

webshopRoot.beforeLoad = function() {
  webshopCards.vm.beforeLoad();
}

webshopRoot.view = function(ctrl) {
  return [m("div[id=spaFunctions]", ctrl.webshopFunctions()),
          m("div[id=spaLeft]"),
          m("div[id=spaRight]", ctrl.webshopCards())]
}
