/////////////////////////////////////////////////////
// SID Card Small Component
// We don't do virtual DOM stuff here, we don't mount
// cards using mithril, althought mithril is very
// fast, we cannot cope with overhead here, since
// card visualizations are central to ui, and highly 
// sensitive to performance penalties
/////////////////////////////////////////////////////

var CardPanel = function(root, options) {
  this.STATES = Object.freeze(
    {"NOT_RENDERED":0,
     "RENDERED": 1}),
  this.state = m.prop(this.STATES.NOT_RENDERED);
  this.rootSelect = d3.select(root);
  var id = enumerator(0);

  //denotes the most recently selected segment
  this.selected = undefined;

  //denotes whether mouseover, mouseleave events are enabled
  this.mouseMoveListenersEnabled = true;

  var settings = {

    /** log debug messages. */
    debug: true,
    //selects/deselects when clicking on a card
    selectOnClick: true,
    size: Math.min(window.innerHeight, window.innerWidth) * 0.1,
    //time(ms) relevant mouseevents gets throttled
    throttleTime: 50,
    defaultWidth: 65,
    //denotes whether a certain segment gets rendered at all
    isRendered: function(x) {
      return true;
    },
    //a function that denotes whether some slice gets marked
    isMarked: function(x) {
      return false;
    },
    //a function denoting whether a segment is clickable at all
    isSegmentClickable: function(x) {
      return true;
    },
    //callback invoked when the user clicks some segment, the callback is invoked with the user data [d] and the selected DOM nod [node]
    onClick: function(d, cardSelect) {
      return this;
    },
    //callback invoked when the user clicks on the minus Funel (just for DIDs)
    onClickMinus: function(d, cardSelect) {
      
    }
  }
  if (!options) { options = {}; }

  // Overwrite and define settings with options if they exist.
  for (var key in settings) {
    if (typeof options[key] !== 'undefined') {
      this[key] = options[key];
    } else {
      this[key] = settings[key];
    }
  }

  this.rootSelect.style("width",this.defaultWidth + "%");



  this.select = function(d) {
    this.selected = d;
  }

  this.mouseover = function(d) {
    if(this.mouseMoveListenersEnabled) {
      this.select(d);
    }
  }

  this.deselectElements = function() {
    this.selected = undefined;
  }

  this.mouseleave = function(d) {
    if(this.mouseMoveListenersEnabled) {
      this.deselectElements();
    }
  }
  //convenience for deselect selected, enable mouse movement listeners and hide lock
  this.unlock = function() {
    this.deselectElements();
    this.mouseMoveListenersEnabled = true;

    //switch off the lock
    this.rootSelect.select("#lock")
      .style("visibility", "hidden");
  }

  this.selectNodeByData = function(d) {
        var id = new LRStringBuffer()
          .append(d[1].coll)
          .append('_')
          .append(d[0])
          .toString();

        return this.rootSelect.select("#" + id)
  }

  this.mouseclick = function(d) {
    if(d[1]._clickable) {
      var cardSelect = this.selectNodeByData(d);
      if(this.selectOnClick) {
        //update data
        d[1]._selected = !d[1]._selected;
        //update view
        cardSelect.style("border-color", d[1]._selected ? "rgba(255,0,0,0.8)" :"transparent");
      }
      if(this.onClick) {
        this.onClick(d, cardSelect);
      }
    }
  }

  this.getReservedAmountArc = function() {

    var width = 45,
    height = 45,
    radius = Math.min(width, height) / 2;

    var arc2 = d3.svg.arc()
      .innerRadius(radius)
      .outerRadius(radius - 5);
    return arc2;
  }

  //renders the amount for small SIDs
  this.renderAmount = function(parent, redraw) {
    var width = 55,
    height = 55,
    radius = Math.min(width, height) / 2;

    var pie = d3.layout.pie()
      .sort(null);

    var arc = d3.svg.arc()
      .innerRadius(radius)
      .outerRadius(radius - 5);
    var arc2 = this.getReservedAmountArc();

    if(redraw) {
      parent.select("svg").remove();
    }

    var svg = parent.append("svg")
      .attr('class', 'amount')
      .attr("width", width)
      .attr("height", height)
      .append("g")
      .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");
    var path = svg.selectAll("path#amount")
      .data(function(d){
        var r = pie(d[1]._amountHistory);
        return r;
      })
      .enter().append("path")
      .attr("id", "amount")
      .attr("fill", function(d,i) { 
        return i === 0 ? "#3e4690" : "#bcb4d6";
      })
      .attr("d", arc);
    var path2 = svg.selectAll("path#reservedAmount")
      .data(function(d){
        var r = pie(d[1]._reservedAmountHistory);
        return r;
      })
      .enter().append("path")
      .attr("id", "reservedAmount")
      .attr("class", function(d,i) { 
        return i === 0 ? "checkThis" : "none";
      })
      .attr("d", arc2)
  }

  /**
   * (de)selects all cards
   */
  this.selectAll = function(select) {
    this.rootSelect.selectAll("div.card").style("border-color", function(d) {
      d[1]._selected = select;
      return select ? "rgba(255,0,0,0.8)" :"transparent";
    });
    return this;
  }

  /**
   * (de)selects a card by coll type and key.
   * returns the d3 selection for the card
   */ 
  this.select = function(coll, key, select) {
    var id = new LRStringBuffer()
      .append(coll)
      .append('_')
      .append(key)
      .toString();
    var cardSelect = this.rootSelect.select("#" + id)
    cardSelect.style("border-color", function(d) {
      d[1]._selected = select;
      return select ? "rgba(255,0,0,0.8)" :"transparent";
    });
    return cardSelect;
  }

  this.updateLocation = function(cardSelect, location) {
    var lambda = function(d) {
      d[1].location = location;
      return this.renderLocationOnSid(d);
    } 
    cardSelect.select("#location").text(lambda.bind(this));
  }

  /**
   * just sid,
   * repaints the minus funel, visible iff pickamount > 0
   */ 
  this.updateMinusFunel = function(cardSelect) {
    cardSelect.select("#minus").style("visibility", function(d) {
        return d[1]._pickAmount && d[1]._pickAmount > 0 ? "" : "hidden";
      });
  }

  this.flashCard = function(cardSelect, alert) {
      var tween = function() { return d3.interpolate("#888888", alert ? "#ff2020" : "#449d44")} 
      var tweenBack = function() { return d3.interpolate(alert ? "#ff2020" : "#449d44", "#888888")} 

      cardSelect.select("div.shadow").transition().duration(150).styleTween("color", tween).transition().duration(350).styleTween("color", tweenBack);

  }

  /**
   * updates the card amounts using the model data
   */
  this.updateAmount = function(data, cardSelect) {
    this.updateAmountHistory(data);
    this.renderAmount(cardSelect.select("div#amountPie"), true);
    cardSelect.select("div#reservedAmount").text(this.getReservedAmountText.bind(this));
  }

  this.renderLocationOnSid = function(d) {
    //fail fast
    if(!d[1].location)
      return "-";
    if(!global.rampup.cardmeta.location)
      return "n/a";
    var res = global.rampup.cardmeta.location[1]["ui-trim"].reduce(function(acc,x,index) {
      var key = x[0];
      var val = d[1].location[1][key];
      if(val) {
        if(index > 0) {
          acc.append("-");
        }
        acc.append(("" + val).substring(0, x[1]));
      }
      return acc;
    }, new LRStringBuffer());
    return res.toString();
  }

  this.renderSID = function(newCards) {
    //spacer on left header
    newCards.append("div").attr("class", "col-66 noPadding").append("div").attr("class", "spacer");
    //funel
    newCards.append("div").attr("class", "col-33 border-left-top-right noPadding bg")
      .append("div").attr("class", "funel").style("text-align","center")
      .append("a")
      .attr("data-toogle", "tooltip")
      .attr("data-placement", "top")
      .attr("title", "Click here to open the attachment in a new tab")
      .on("click", function(d) {
        window.open(global.pathnamePrefix + '/printing/result?file=' + d[1].initialSidLabel)
      })
      .style("visibility", function(d) {
        return d[1].initialSidLabel === undefined ? "hidden" : "";
      })
      .append("span")
      .attr("class","glyphicons glyphicons-paperclip");
    //the main div contains a 66% left side div with user info and a 33% right side div with amounts
    var mainDiv = newCards.append("div").attr("class", "col-100 border-left-bottom-right bg shadow")
      .on("click", this.mouseclick.bind(this))
;
    var leftDiv = mainDiv.append("div").attr("class","col-66 border-top").append("div").attr("class","col-100 padding-10").selectAll("div.group").data((function(d) {
      var xs = [{caption: "LOCATION", path: this.renderLocationOnSid, id: "location"},
                {caption: "CLIENT", path: ["article"], attr: "client"},
                {caption: "ITEM", path: ["article"], attr: "ident"},
                {caption: "DESCRIPTION", path: ["article"], attr: "description"},
                {caption: "SID", path: function(d) {
                  return "" + d[0];
                }},
                {caption: "INBOUND", path: [], attr: "creation-date"},
                {caption: "UNIT", path: ["article"], attr: "unit", last: true},
                {caption: "BATCH", path: [], attr: "batch", last: true}];
      xs =  xs.map(function(n) {
        n["d"] = d;
        n["maxLength"] = d.maxLength || 13;
        n["naText"] = d.naText || "n/a";
        return n;
      });
      return xs;
    }).bind(this)).enter().append("div").attr("class", "group col-50");
    leftDiv.append("div").attr("class","smallCap").text(function(d) {
      return !d.empty ? d.caption : String.fromCharCode(160);
    })
    leftDiv.append("div").attr("class",function(d) {
      return d.empty || d.last ? "small-noBorder" : "small";
    })
      .attr("id", function(d) {
        return d.id || d.caption || "";
      })
      .text(function(d) {
        var val = String.fromCharCode(160);
        if(d.empty) {
          return val;
        }
        if(typeof d.path === "function") {
          val = d.path.call(this, d.d);
        } else {
          val = docPath(d.d, d.path, d.attr, d.naText);
        }
        if(val.length > d.maxLength) {
          val = val.substring(0, d.maxLength) + "..";
        }
        return val;

      });

    var rightDiv = mainDiv.append("div").attr("class","col-33");
    //spoiler and spacer :)
    rightDiv.append("div").attr("class","pixel-top-left");
    rightDiv.append("div").attr("class","col-100 padding-8");
    var amountDiv = rightDiv.append("div").attr("class","group-noRuler");
    //orig amount
    amountDiv.append("div").attr("class", "big").style("text-align", "center")
      .text(function(d) {
        var x = d[1].origAmount || d[1].amount;
        if(x === undefined) {
          x = String.fromCharCode(160);
        }
        return x;

      });
    amountDiv.append("div").attr("class", "big").style("text-align","center")
      .text(function(model) {
        if(model[1].origAmount !== undefined && model[1].origAmount > model[1].amount) {
          return model[1].amount;
        } else {
          return String.fromCharCode(160);
        }
      });

    this.renderAmount(amountDiv.append("div").style("text-align", "center"));

    amountDiv.append("div").attr("class", "checkThis")
      .style("text-align","center").text(function(model) {
        var orig = model[1].origAmount || model[1]._reservedAmount || model[1].reservedAmount;
        if(model[1]._reservedAmount !== undefined || model[1].reservedAmount) {
          var x = model[1]._reservedAmount || model[1].reservedAmount;
          return x;
        } else {
          return String.fromCharCode(160);
        }

      });

  }

  this.getReservedAmountText = function(model) {
    var orig = model[1].origAmount || model[1]._reservedAmount || model[1].reservedAmount;
    if(model[1]._reservedAmount !== undefined || model[1].reservedAmount) {
          var x = model[1]._reservedAmount || model[1].reservedAmount || String.fromCharCode(160);
          return x;
        } else {
          return String.fromCharCode(160);
        }
  }

  this.renderDID = function(newCards) {
    //spacer on left header
    newCards.append("div").attr("class", "col-66 noPadding").append("div").attr("class", "spacer");
    //funel
    newCards.append("div").attr("class", "col-33 border-left-top-right noPadding bg")
      .append("div")
      .attr("class", "funel").style("text-align","center")
      .append("a")
      .attr("id", "minus")
      .attr("data-toogle", "tooltip")
      .attr("data-placement", "top")
      .attr("title", "Click here to reduce pickamount by one")
      .on("click", (function(d) {
        if(this.onClickMinus) {
          var cardSelect = this.selectNodeByData(d);
          this.onClickMinus(d, cardSelect);
        }
      }).bind(this))
      .style("visibility", function(d) {
        return d[1]._pickAmount && d[1]._pickAmount > 0 ? "" : "hidden";
      })
      .append("span")
      .attr("class","glyphicons glyphicons-minus-sign");
    //the main div contains a 66% left side div with user info and a 33% right side div with amounts
    var mainDiv = newCards.append("div").attr("class", "col-100 border-left-bottom-right bg shadow")
      .on("click", this.mouseclick.bind(this))
;
    var leftDiv = mainDiv.append("div").attr("class","col-66 border-top").append("div").attr("class","col-100 padding-10").selectAll("div.group").data((function(d) {
      var xs = [{caption: "ITEM", path: [], attr: "ident", class: "group col-100"},
                {caption: "DESCRIPTION", path: [], attr: "description", class: "group col-100"},
                {caption: "DID", path: function(d) {
                  return "" + d[0];
                }, last: true},
                {caption: "CLIENT", path: [], attr: "client", last: true} ];
      xs =  xs.map(function(n) {
        n["d"] = d;
        n["maxLength"] = d.maxLength || 13;
        n["naText"] = d.naText || "n/a";
        return n;
      });
      return xs;
    }).bind(this)).enter().append("div")
      .attr("class", function(n) {
        return n.class ? n.class : "group col-50";
      });
    leftDiv.append("div").attr("class","smallCap").text(function(d) {
      return !d.empty ? d.caption : String.fromCharCode(160);
    })
    leftDiv.append("div").attr("class",function(d) {
      return d.empty || d.last ? "small-noBorder" : "small";
    })
      .attr("id", function(d) {
        return d.id || d.caption || "";
      })
      .text(function(d) {
        var val = String.fromCharCode(160);
        if(d.empty) {
          return val;
        }
        if(typeof d.path === "function") {
          val = d.path.call(this, d.d);
        } else {
          val = docPath(d.d, d.path, d.attr, d.naText);
        }
        if(val.length > d.maxLength) {
          val = val.substring(0, d.maxLength) + "..";
        }
        return val;

      });

    var rightDiv = mainDiv.append("div").attr("class","col-33");
    //spoiler and spacer :)
    rightDiv.append("div").attr("class","pixel-top-left");
    rightDiv.append("div").attr("class","col-100 padding-8");
    var amountDiv = rightDiv.append("div").attr("class","group-noRuler");
    //orig amount
    amountDiv.append("div").attr("class", "big").style("text-align", "center")
      .text(function(d) {
        var x = d[1].origAmount || d[1].amount;
        if(x === undefined) {
          x = String.fromCharCode(160);
        }
        return x;

      });
    amountDiv.append("div").attr("class", "big").style("text-align","center")
      .text(function(model) {
        if(model[1].origAmount !== undefined && model[1].origAmount > model[1].amount) {
          return model[1].amount;
        } else {
          return String.fromCharCode(160);
        }
      });

    this.renderAmount(amountDiv.append("div")
                      .attr("id", "amountPie")
                      .style("text-align", "center"));

    amountDiv.append("div")
      .attr("id", "reservedAmount")
      .attr("class", "checkThis").style("text-align","center")
      .text(this.getReservedAmountText.bind(this));
  }


  //returns those cards that are currently selected
  this.getSelectedCards = function() {
    return this.rootSelect.selectAll("div.card").filter(function(n) {
      return n[1]._selected === true;
    })
  }

  this.getCards = function() {
    return this.rootSelect.selectAll("div.card");
  }

  //returns those cards that are currently not selected
  this.getDeselectedCards = function() {
    return this.rootSelect.selectAll("div.card").filter(function(n) {
      return n[1]._selected === false;
    })
  }

  this.getDataOfSelectedCards = function() {
    var data = [];
    this.getSelectedCards().each(function(n) {
      data.push(n);
    });
    return data;
  }

  //returns number of cards on the desk
  this.getCardCount = function() {
    return this.rootSelect.selectAll("div.card").size();
  }

  this.removeAllCards = function() {
    this.rootSelect.selectAll("div.card").remove()
  }

  //removes all those cards from view that are within the the cards that match a certain collection [coll] and the given keys
  this.removeCards = function(coll, keys) {
    for(i in keys) {
      
      
      this.rootSelect.select("#" + (new LRStringBuffer()
                                    .append(coll)
                                    .append('_')
                                    .append(keys[i])
                                    .toString())).remove();
    }
  }

  this.remove = function() {
    this.rootSelect.select("div#cardPanel").remove();
  }

  this.updateAmountHistory = function(d) {
        d[1]._amountHistory = [d[1].amount];
        if(d[1].origAmount && d[1].origAmount > d[1].amount) {
          d[1]._amountHistory.push(d[1].origAmount - d[1].amount);
          d[1]._amountRatio = (d[1].amount / d[1].origAmount * 100).toFixed(0);
        }

        var reservedAmount = d[1]._reservedAmount || d[1].reservedAmount;
        var origAmount = d[1].origAmount || d[1].amount;
        d[1]._reservedAmountHistory = [];
        if(reservedAmount && origAmount) {
          d[1]._reservedAmountHistory.push((reservedAmount / origAmount * 100).toFixed(0));
          d[1]._reservedAmountHistory.push((origAmount - reservedAmount) / origAmount * 100).toFixed(0);
        }
  }

  //renders the cards for the first time
  this.render = function(data, keepOldStuff) {
    this.selected = undefined;

    var cardPanel = undefined;
    if(this.state() === this.STATES.NOT_RENDERED || this.rootSelect.select("#cardPanel").size() == 0) {
      //render the sunburst container div
      cardPanel = this.rootSelect.append("div")
        .attr("id", "cardPanel");
      this.state(this.STATES.RENDERED);
    } else {
      cardPanel = this.rootSelect.select("#cardPanel");
    }

    //remove all remaining stuff
    if(!keepOldStuff) {
      this.rootSelect.selectAll("div.card").remove();
    }

    if(data.length == 0) {
      return this;
    }

    //aggregate some data for nested d3 binds
    data = data.map((function(d) {
      d[1]._selected = false;
      d[1]._clickable = true;
      if("stock" === d[1].coll || "article" === d[1].coll) {
        this.updateAmountHistory(d);
      }
      return d;
    }).bind(this));

    var cards = cardPanel.selectAll("div.card").data(data, function(d){
      return new LRStringBuffer()
        .append(d[1].coll)
        .append('_')
        .append(d[0])
        .toString();
    });

    var newCards = cards.enter().append("div")
      .attr("class", function(d) {
        return "card smallCard " + d[1].coll;
      })
      .attr("id", function(d){
        return new LRStringBuffer()
          .append(d[1].coll)
          .append('_')
          .append(d[0])
          .toString();
      });
    
    if(data.length > 0 && "article" == data[0][1].coll) {
      this.renderDID(newCards);
    } else {
      this.renderSID(newCards);
    }
    return this;
  }
}
