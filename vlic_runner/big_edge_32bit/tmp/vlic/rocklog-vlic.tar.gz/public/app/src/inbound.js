//Inbound Process, Transfer

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state
/////////////////////////////////////////////////////
var inboundRoot = {}
var inboundFunctions = {}
var inboundProcess = {
  model: [undefined, {coll: "stock", article: [undefined, {coll: "article"}], location: [undefined, {}], amount: 1}],
  count: m.prop(1),
  print: m.prop(false),
  editField: undefined
}

var inboundContext = {}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////
inboundRoot.vm = {}

inboundFunctions.vm = {
  init: function() {
    inboundFunctions.vm.functions = new FunctionPanel(
      {home: {imageClass: "glyphicon glyphicon-home", tooltip: "Back to search", onclick: function() {
        route("/search", searchRoot);
      }, enabled: true}});
  }
}

inboundProcess.vm = {
  nonJsonErrors: function(xhr) {
    return xhr.status > 200 ? JSON.stringify(xhr.responseText) : xhr.responseText
  },
  //denotes the currently used sid numberrange, used for remote updates
  currentNumberrange: m.prop(undefined),
  //denotes the last recently article ident
  lastRecentlyArticleInput: m.prop(""),
  numberrangeSub: undefined,

  init: function() {
    //inbound.vm.cardtypes = Cardtype.list();
    inboundProcess.vm.process = new UIProcess();

    var step = new UIProcessStep();
    step.model = inboundProcess.model;
    //step.title = "CARD CREATION: Input data and slide in number of cards to create";
    //step.editField = m.prop(undefined);
    step.editField = m.prop(undefined);
    step.shadow = m.prop(undefined);
    step.cancel = null;
    step.component = SIDComponent;
    step.onEnter = function(retainContent, callback) {
      //we check whether the creation data is not yet given -> populate the current
      if(!inboundProcess.model[1]["creation-date"]) {
        inboundProcess.model[1]["creation-date"] = new Date().toISOString().substring(0, 10);
      }

      //if we jump in forward (no article known), then we disable the submit button since the user must select one Article uniquely
      this.submitEnabled(retainContent || inboundProcess.model[1].article[0] != undefined);
      callback();
    }
    step.onExit = function(callback, forward) {
      if(forward) {
        var data = {
          articleIdent: inboundProcess.model[1].article[1].ident,
          count: parseInt(inboundProcess.count()),
          batch: inboundProcess.model[1].batch,
          "creation-date": inboundProcess.model[1]["creation-date"],
          print: inboundProcess.print(),
          sidNumberrange: inboundProcess.vm.currentNumberrange() ? inboundProcess.vm.currentNumberrange()[0] : undefined,
          model: inboundProcess.model[1]
        };
        global.autobahn.sync({event:"inbound", fn:"inbound", data: data}).then(function(data) {

          if(!data.error) {
            //move on to locate the cards
            inboundProcess.vm.showCards(data.data);
          } else {
            inboundProcess.vm.process.init();
          }
          callback();
        })
          .catch(function(msg) { 
            inboundProcess.vm.process.init();
          });
      } else {
        callback();
      }

    };
    inboundProcess.vm.stepChooseArticle = step;
    inboundProcess.vm.process.add(step);

    inboundProcess.vm.process.init();
  },
  
  //shows the newly created cards after inbound
  showCards: function(data) {
    xferCards.vm.enableInboundMode(true);
    xferCards.vm.sendBackLabel(inboundProcess.print());
    xferTarget.vm.invariantPrefix(inboundContext.vm.sunburst.invariantPrefix());
    xferCards.data = data;
    route("/xfer", xferRoot);
  },  

  oninput: function(path, attr, value) {
    if(pathToString(path, attr) == pathToString(["article"], "ident")) {
      this.oninputArticle(value);
    }
  },

  onsubmit: function(path, attr) {
    if(pathToString(path, attr) == pathToString(["article"], "ident")) {
      this.onsubmitArticle();
    }
  },


  onsubmitArticle: function() {
    if(inboundProcess.model[1].article[0] !== undefined) {
      
      setAttrToPath(inboundProcess.model, [], "amount", docPath(inboundProcess.model, ["article"], "inboundAmount", 1));
      setAttrToPath(inboundProcess.model, ["article"], "ident", docPath(inboundProcess.model, ["article"], "_origIdent"));
    }
  }, 

  oncancel: function(path, attr) {
    if(pathToString(path, attr) == pathToString(["article"], "ident")) {
      this.oncancelArticle();
    }
  },

  oncancelArticle: function() {
    inboundProcess.model[1].article = [undefined,{}];
  }, 

  oninputArticle: function(x) {
    this.lastRecentlyArticleInput(x);
    this.oninputArticleThrottled(x);
  },

  oninputArticleThrottled: throttle(function(x) {
    //check if process can continue
    global.autobahn.sync({event:"search", query: x, sessionId: global.autobahn.sessionId, search: "unique-article"}).then(function(data) {
      m.startComputation();
      inboundProcess.vm.stepChooseArticle.submitEnabled(data.data !== null);
      if(data.data !== null) {
        setAttrToPath(data.data, [], "_origIdent", docPath(data.data, [], "ident"));
        setAttrToPath(data.data, [], "ident", inboundProcess.vm.lastRecentlyArticleInput());
        inboundProcess.model[1].article = data.data;
        inboundContext.vm.updateSunburst(x);
      } else {
        inboundProcess.model[1].article = [undefined,{ident: inboundProcess.vm.lastRecentlyArticleInput()}];  
      }
 
      m.endComputation();

    });

  }, 350),

  onunload: function() {
    if(inboundProcess.vm.numberrangeSub) {
      global.autobahn.desub(global.TOPICS.numberrangeFollow, inboundProcess.vm.numberrangeSub);
    }
  }
}

inboundContext.vm = {
  lastSearch: m.prop(""),
  updateSunburst: function(x, prefix) {
    inboundContext.vm.lastSearch(x);
    //update location context
    global.autobahn.sync({event:"search", query: x, sessionId: global.autobahn.sessionId, search: "hierarchie-location-for-inbound", opts: ["prefix", prefix !== undefined ? prefix : inboundContext.vm.sunburst.invariantPrefix()]}).then(function(data) {
      inboundContext.vm.sunburst.render.bind(inboundContext.vm.sunburst)(data.data, data.meta);
    });

  },

  isMarked : function(x) {
    if(x.orig.l === true) {
      return x.orig.capacity > 0;
    }
    return false;
  },
  matchingStock : function(x) {
    return x.orig.l === true && x.orig.v !== undefined && x.orig.v["count-matching-stocks"] > 0;
  },
  onload: function() {
    inboundContext.vm.sunburst = 
      new Sunburst(
        d3.select("div#spaRight"), 
        {size: Math.min(window.innerHeight * 0.7, window.innerWidth * 0.25), svgCss: "sunburstRight", sequenceCss: "sequenceRight",
         isRendered: function(x) {
           return (x.orig.capacity !== undefined && x.orig.capacity > 0) || inboundContext.vm.isMarked(x) || inboundContext.vm.matchingStock(x) || x.orig.l === false;
         },
         isSegmentClickable: function(x) {
           return inboundContext.vm.isMarked(x) ||
             (x.orig.capacity !== undefined && x.orig.capacity > 0); 
         },
         getRadiusRatio: function(x) {
           return (x.orig.l === false || inboundContext.vm.isMarked(x)) ? 1.0 : 0.4;
         },
         getCenterString: function(x) {
           return "" + x.data.orig.capacity;
         },
         getCenterDescription: function(x) {
           return "Capacity left";
         },
         isMarked: inboundContext.vm.isMarked,
         onZoomin: function(prefix) {
           inboundContext.vm.updateSunburst(inboundContext.vm.lastSearch(), prefix);
         },
         onZoomout: function(prefix) {
           inboundContext.vm.updateSunburst(inboundContext.vm.lastSearch(), prefix);
         },
         isLeafZoomable: function(prefix,d) {
           return d.data.orig.v.c !== undefined && d.data.orig.v.c > 1;
         }
        }
      );
    //dummy search at start-up
    inboundContext.vm.updateSunburst("");
  }
}

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
inboundFunctions.controller = function() {
  inboundFunctions.vm.init();
};
inboundFunctions.view = function(ctrl) {
  return inboundFunctions.vm.functions.view(ctrl);
}

inboundProcess.controller = function() {
  inboundProcess.vm.init();
  //observing server-side number range events
  inboundProcess.vm.numberrangeSub = global.autobahn.sub(global.TOPICS.numberrangeFollow, function(data){
    if(inboundProcess.vm.currentNumberrange() && inboundProcess.vm.currentNumberrange()[0] == data[0]) {
      m.startComputation();
      m.endComputation();
    }
  });
  
};

inboundProcess.view = function(ctrl) {
  return m.component(UIProcessComp, {process: inboundProcess.vm.process});
};

inboundContext.controller = function() {
}

inboundContext.view = function(ctrl) {
  return [];
}

inboundRoot.controller = function() {
  return {
    inboundFunctions : submodule(inboundFunctions),
    inboundProcess : submodule(inboundProcess),
    inboundContext : submodule(inboundContext),
    onunload: function() {
      inboundProcess.vm.onunload();
    }
  };
}

inboundRoot.view = function(ctrl) {
  return [m("div[id=spaFunctions]", ctrl.inboundFunctions()),
          m("div[id=spaLeft]", {class: "col-60"}, ctrl.inboundProcess()),
          m("div[id=spaRight]")];
}

inboundRoot.onload = function() {
  inboundContext.vm.onload();
}

var SIDComponent = {
  view: function(ctrl, args) {
    var body = [];
    var active = args.step.state() == UIProcessStepState.ACTIVE;

    //the numberrange component inside
    var numberrangeComp = new SIDNumberrangeComp(
      m.prop(global.rampup.numberranges().filter(
        function(n) { return n[1].coll == "stock" })),
      login.Session.sidNumberrange, inboundProcess.count);
    numberrangeComp.currentNumberrange = inboundProcess.vm.currentNumberrange;
    numberrangeComp.onRollForward = function(nrange) {

      global.autobahn.sync({event:"numberrange", fn:"roll-forward", key: nrange[0], count: 1}).then(function(data) {
        //update model
        if(data.data[1].running > nrange[1].running) {
          m.startComputation();
          //check whether incomming data is never
          nrange[1] = data.data[1];
          m.endComputation();
        }

      })
        .catch(function(msg) { 
          console.log(msg);
        });
    }

    var footerRenderer = function() {
      return <div class="col-100 noPadding">
        <div class="col-80 left">
        <span class="default">Number of cards</span>
        <input class="table-cell" style="width: 50%" type="range" min="1" max="100" step="1" name="count" value={inboundProcess.count()}  oninput={ m.withAttr("value", inboundProcess.count)} data-toogle="tooltip" data-placement="top" title="Slide-in number of SIDs to create"/>
        <span class="default">{inboundProcess.count()}</span>
        </div>
        <div style="float: right;">
        <a data-toogle="tooltip" data-placement="top" title="Select to create PDF SID label"
           onclick={function(){
             inboundProcess.print(!inboundProcess.print())
           }}
           class={inboundProcess.print() ? "enabled" : "disabled"}>
        <span class="glyphicons glyphicons-print"></span>
        </a>
        </div>
        </div>
    }

    var bigsid = new BigSID(args.step.model, {
      editField: args.step.editField,
      shadow: args.step.shadow,
      oninput: inboundProcess.vm.oninput.bind(inboundProcess.vm),
      onsubmit: inboundProcess.vm.onsubmit.bind(inboundProcess.vm),
      oncancel: inboundProcess.vm.oncancel.bind(inboundProcess.vm),
      numberrangeComp: numberrangeComp,
      footerRenderer: footerRenderer});
    return bigsid.view();
  }
}
