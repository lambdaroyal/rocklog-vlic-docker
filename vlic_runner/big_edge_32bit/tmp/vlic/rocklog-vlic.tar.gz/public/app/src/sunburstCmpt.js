/////////////////////////////////////////////////////
// Sunburst Component
// We don't do virtual DOM stuff here, we don't mount
// sunbursts using mithril, althought mithril is very
// fast, we cannot cope with overhead here, since
// sunbursts are central to ui, a highly sensitive to
// performance penalties
/////////////////////////////////////////////////////

//root denotes the element to anker the sunburst into, options is a map
var Sunburst = function(root, options) {
  this.STATES = Object.freeze(
    {"NOT_RENDERED": 0,
     "RENDERED": 1});
  /**
   * (1) denotes that the user most recently requested zoom in action by pressing +/zoom without predecessing selection within the sunburst,
   * so the following click! (not select) will do a zoom-in without the triggering the onclick handler.
   *
   * (2) on the other hand: when the user did already select a element a zoom action via +/zoom is directly resulting in the rerendering the
   * sunburst in zoomed mode
   */
  this.zoominRequested = m.prop(false);
  this.state = m.prop(this.STATES.NOT_RENDERED);
  this.root = root;
  var id = enumerator(0);
  var pathId = enumerator(0);
  this.ring = function(xs) {
    var _next = id() % xs.length;
    return xs[_next];
  };
  //denotes a small integer ring to change the mark colors for near by siblings that are marked
  this.markColors = this.ring.bind(vm, ["#403698", "#455190"]);

  //denotes the most recently selected segment
  this.selected = undefined;

  this.topology = undefined;
  //denotes that the server sent down less than all remaining levels
  this.cutDown = m.prop(false);
  //denotes a array of tupels, where each tupel consists of the level discriminator name as well as the value. This gets set indirectly by zoom-in, zoom-out: done by the following ctrl flow
  // |-------|--------|--------------------|------------------------|--------->
  // render  zoomin   prefix=vm.onZoomin   invariantPrefix(prefix)  render
  this.invariantPrefix = m.prop([]);

  //denotes whether mouseover, mouseleave events are enabled
  this.mouseMoveListenersEnabled = true;

  //denotes the colors to use round robin
  var baseColors = [[89,83,115,1],
                    [192,127,29,1],
                    [79,146,212,1]];
  //returns the color to be used for a slice, sliceCount denotes the number of slices to be rendered with the same base color, i denotes the index ranging from [0 .. slicesCount[
  var color = function(n, alpha, slicesCount, i) {
    var c = baseColors[n % baseColors.length];
    var cor = i !== undefined ? Math.pow(1.0 - 1.0 / slicesCount, i)  : 1;
    var ret = new LRStringBuffer().append("rgba(").append(Math.round(Math.round(c[0] * cor))) 
        .append(",").append(Math.round(c[1] * cor)).append(",").append(Math.round(c[2] * cor))
        .append(",").append(alpha !== undefined ? alpha : c[3]).append(")").toString();
    return ret;
  }

  var settings = {

    /** log debug messages. */
    debug: true,
    /** how many levels are to be rendered at max*/
    maxDeepth: undefined,
    /** overrides deepth as per data */
    deepthConstraint: undefined,
    size: Math.min(window.innerHeight, window.innerWidth) * 0.7,
    // gretel dimensions: width, height, spacing, width of tip/tail.
    gretelDim: {
      w: 75, h: 20, s: 3, t: 10
    },
    //time(ms) relevant mouseevents gets throttled
    throttleTime: 50,
    //denotes whether a certain segment gets rendered at all
    isRendered: function(x) {
      return true;
    },
    //a function that denotes whether some slice gets marked
    isMarked: function(x) {
      return false;
    },
    //a function that denotes the ratio of the radius to use, by default this function yields 1, use this to denote something that is partially present
    getRadiusRatio: function(x) {
      return 1.0;
    },
    //a function denoting whether a segment is clickable at all
    isSegmentClickable: function(x) {
      return true;
    },
    //denotes the string that is displayed within the center of the sunburst, by default we show percentage of the segment with regard to the full sunburst
    getCenterString: function(d) {
      //d.data[1] contains the number of elements as per this slice
      var percentage = (100 * d.data.count / this.totalSize).toPrecision(3);
      var percentageString = percentage + "%";
      if (percentage < 0.1) {
        percentageString = "< 0.1%";
      }

      return percentageString;
    },
    getCenterDescription: function(d) {
      return "";
    },

    //use this to achive right alignment for context sunbursts
    svgCss: "sunburst",
    //use this and a margin to bring down the whole sunburst
    sequenceCss: "sequence",
    //callback invoked when the user clicks some segment, the callback is invoked with sequenceArray of data to the clicked segment
    onClick: undefined,
    //callback invoked when the user clicks on the zoom in function
    onZoomin: function(prefix) {
      return this;
    },
    //callback invoked when the user clicks on the zoom out function
    onZoomout: function(prefix) {
      return this;
    },
  }
  if (!options) { options = {}; }

  // Overwrite and define settings with options if they exist.
  for (var key in settings) {
    if (typeof options[key] !== 'undefined') {
      this[key] = options[key];
    } else {
      this[key] = settings[key];
    }
  }

  //calc some invariants based on the known options
  this.radius = this.size / 2;

  this.getArc = function (deepth) {
    //+1 for inner segment that is empty, reserved for text
    var slice = Math.floor(this.radius / (this.maxDeepth + 1));

    return d3.svg.arc()
      .innerRadius(slice * deepth)
  }

  // Given a node in a partition layout, return an array of all of its ancestor
  // nodes, highest first, but excluding the root.
  var getAncestors = function(node) {
    var path = [node];
    var current = node;
    while (current.parent) {
      path.unshift(current.parent);
      current = current.parent;
    }
    return path;
  }

  /**
   * returns an array consisting of a tupels, where the first element of the tupel denotes the key as per the topology, whereas the second one denotes the value
   */
  this.getPrefix = function(node) {
    if(node === undefined && this.selected !== undefined) {
      return this.invariantPrefix().concat(this.getPrefix(this.selected))
    }

    var xs = getAncestors(node);
    xs = xs.map((function(x, i) {
      res = [this.topology[i], x.data.orig.k];
      res.color = x.color;
      return res;
    }).bind(this));
    return xs;
  }

  //initializes the trail
  this.initializeGretel = function() {
    // Add the svg area.
    var trail = root.select("#sequence").append("svg:svg")
        .attr("width", this.size * 1.5)
        .attr("height", this.gretelDim.h)
        .attr("id", "trail");
    // Add the label at the end, for the percentage.
    trail.append("svg:text")
      .attr("id", "endlabel");
  }

  // Generate a string that describes the points of a gretel polygon.
  this.gretelPoints = function(d, i) {
    var points = [];
    points.push("0,0");
    points.push(this.gretelDim.w + ",0");
    points.push(this.gretelDim.w + this.gretelDim.t + "," + (this.gretelDim.h / 2));
    points.push(this.gretelDim.w + "," + this.gretelDim.h);
    points.push("0," + this.gretelDim.h);
    if (i > 0) { // Leftmost gretel; don't include 6th vertex.
      points.push(this.gretelDim.t + "," + (this.gretelDim.h / 2));
    }
    return points.join(" ");
  }

  // Update the gretel trail to show the current sequence
  this.updateGretel = function(nodeArray) {
    // Data join; key function combines name and depth (= position in sequence).
    var g = root.select("#trail")
        .selectAll("g")
        .data(this.invariantPrefix().concat(nodeArray), function(d) { 
          if(d.data) {
            //clicked value
            return d.data.id;  
          } else {
            //prefix value
            return d.join("_");
          }
        });

    // Add gretel and label for entering nodes.
    var entering = g.enter().append("svg:g");

    entering.append("svg:polygon")
      .attr("points", this.gretelPoints.bind(this))
      .style("fill", function(d) { 
        return d.color;        
      });

    entering.append("svg:text")
      .attr("x", (this.gretelDim.w + this.gretelDim.t) / 2)
      .attr("y", this.gretelDim.h / 2)
      .attr("dy", "0.35em")
      .attr("text-anchor", "middle")
      .text(function(d) { 
        if(d.data) {
          return d.data.desc; 
        } else {
          //prefix value
          return d[1];
        }
      });

    // Set position for entering and updating nodes.
    g.attr("transform", (function(d, i) {
      return "translate(" + i * (this.gretelDim.w + this.gretelDim.s) + ", 0)";
    }).bind(this));

    // Remove exiting nodes.
    g.exit().remove();

    // Make the gretel trail visible, if it's hidden.
    root.select("#trail")
      .style("visibility", "");

  }
  
  /** returns the data elements from root to the selected one*/
  this.selectElement = function(d) {
    var percentageString = this.getCenterString(d);
    root.select("#percentage")
      .text(percentageString)
      .style("visibility", "");

    var centerDescription = this.getCenterDescription(d);
    root.select("#explanation")
      .text(centerDescription)
      .style("visibility", "");

    var sequenceArray = getAncestors(d);
    this.updateGretel(sequenceArray);

    // Fade all the segments.
    root.selectAll("path")
      .style("opacity", 0.2);

    // Then highlight only those that are an ancestor of the current segment.
    this.svg.selectAll("path")
      .filter(function(node) {
        return (sequenceArray.indexOf(node) >= 0);
      })
      .style("opacity", d.clickable ? 1 : 0.3)
      //.style("opacity", d.clickable ? 1 : 0.3);

    this.selected = d;

    return sequenceArray;
  }

  this.mouseover = function(d) {
    if(this.mouseMoveListenersEnabled) {
      this.selectElement(d);
    }
  }

  this.deselectElements = function() {
    this.selected = undefined;

    // Hide the breadcrumb trail
    root.select("#trail")
      .style("visibility", "hidden");

    // Deactivate all segments during transition.
    root.selectAll("path").on("mouseover", null);

    var mouseoverPartial = this.mouseover.bind(this);

    // Transition each segment to full opacity and then reactivate it.
    root.selectAll("path")
      .transition()
    //.duration(1000)
      .style("opacity", 1)
      .each("end", function() {
        d3.select(this).on("mouseover", mouseoverPartial);
      });
    root.select("#percentage")
      .style("visibility", "hidden");

    root.select("#explanation")
      .style("visibility", "hidden");
  }

  this.mouseleave = function(d) {
    if(this.mouseMoveListenersEnabled) {
      this.deselectElements();
    }
  }
  //convenience for deselect selected, enable mouse movement listeners and hide lock
  this.unlock = function() {
    this.deselectElements();
    this.mouseMoveListenersEnabled = true;

    //switch off the lock
    root.select("#lock")
      .style("visibility", "hidden");
  }

  this.zoominInternal = function(d) {
    if(this.onZoomin !== undefined) {
      try {
        var prefix = this.getPrefix(d);
        if(prefix.length < this.maxDeepth || this.cutDown()) {
          if(!d.data.orig.l || (d.data.orig.v.c !== undefined && d.data.orig.v.c > 1)) {
            this.invariantPrefix(this.invariantPrefix().concat(prefix));
            this.onZoomin(this.invariantPrefix());
          }
        }
        
      } finally {
        this.zoominRequested(false);
      }
    }

  }

  this.mouseclick = function(d) {
    if(d.clickable) {
      //check if a zoomin/zoomout was requested recently
      if(this.zoominRequested()) {
        this.zoominInternal(d);
      } else {

        if(this.selected === undefined || this.selected.data.id != d.data.id || this.mouseMoveListenersEnabled) {
          //if not yet selected or mousemovelisteners are still active, we select it and disable mouse movement listeners
          this.selectElement(d);
          this.mouseMoveListenersEnabled = false;

          //switch on the lock 
          root.select("#lock")
            .style("visibility", "");

        } else {
          //the same for the second time
          this.unlock();
        }

        if(this.onClick) {
          var sequenceArray = getAncestors(d)
          this.onClick(sequenceArray);
        }
      }
    }
  }

  this.zoomin = function() {
    if(this.selected === undefined) {
      this.zoominRequested(true);
    } else {
      this.zoominInternal(this.selected);
    }
  }

  this.zoomout = function() {
    if(this.onZoomout && this.invariantPrefix().length > 0) {
      try {
        this.invariantPrefix().pop();
        this.onZoomout(this.invariantPrefix());
      } finally {
        //revoke former zoomin request (since this request is now rendered senseless)
        this.zoominRequested(false);
      }
    }
  }


  /**
   * @parentSlice parent Node we append the new arc to
   * @data slice of the data (model)
   * @deepth initial is 1, with each recursion this gets incremented (to be refactored)
   * @parentId the unique id of the parent path element
   * @start start gradient in degree * 2 * PI / 360
   * @stop stop gradient in degree * 2 * PI / 360
   * @segmentColor index of the color to use for the slice and all recursive calls
   */
  this.renderLevel = function(parentSlice, data, deepth, parentId, start, end, segmendColor) {
    if (deepth <= this.maxDeepth) {
      if (typeof data == "object" && data.reduce !== undefined) {
        var slice = Math.floor(this.radius / (this.maxDeepth + 1))
        var arc = this.getArc(deepth)
            .startAngle(function (d) {
              return d.start;
            })
            .endAngle(function (d) {
              return d.stop;
            })
            .outerRadius(function(d) {
              var inc = (slice - 2) * d.radiusRatio;
              return (slice * deepth) + inc;
            });


        //we did not get to the outermost level

        //denotes the overall ratio (the whole cake)
        //in domain uom
        var overall = data.reduce(function (acc, x) {
          //.c like count
          return acc + (x.l == false ? x.c : 1);
        }, 0);

        //we map in an additional value that is used to calculate the size of the cake since
        //a slice might be to small, so we redistribute a bit to have slices of at least 5 percent
        //furthermore we push in an id that denotes the element uniquely
        var average = overall / data.length;
        var overallSmoothed = 0;
        data = data.map(function(i) {
          var m = {orig: i};
          //.k like key, might be a number
          m.desc = i.k != undefined ? ("" + i.k) : "n/a"; 
          //.c like count
          m.count =  i.c;
          var correction = Math.pow(Math.abs(average - i.c), 0.6);
          m.countSmoothed = i.c + (average > i.c ? correction : -correction);
          m.id = parentId + "_" + pathId();
          overallSmoothed = overallSmoothed + m.countSmoothed;
          return m;
        });

        var isMarkedPartial = this.isMarked.bind(this);
        var isRenderedPartial = this.isRendered.bind(this);
        var isSegmentClickablePartial = this.isSegmentClickable.bind(this);
        var getRadiusRatioPartial = this.getRadiusRatio.bind(this);

        var slices = data.reduce(function (acc, i, index) {
          var ratio = i.countSmoothed / overallSmoothed;

          var slice = ratio * (end - start);
          var mark = isMarkedPartial(i);
          var render = isRenderedPartial(i);
          if (acc.length > 0) {
            var _start = acc[acc.length - 1].stop;
            acc.push({
              start: _start,
              stop: _start + slice,
              parent: parentSlice,
              data: i,
              mark: mark,
              render: render,
              radiusRatio: getRadiusRatioPartial(i),
              clickable: isSegmentClickablePartial(i)              
            });
          } else {
            acc.push({
              start: start,
              stop: start + slice,
              parent: parentSlice,
              data: i,
              mark: mark,
              render: render,
              radiusRatio: getRadiusRatioPartial(i),
              clickable: isSegmentClickablePartial(i)
            });
          }
          return acc;
        }, []);

        var markColorsPartial = this.markColors.bind(this);
        var getArcPartial = this.getArc.bind(this, deepth);

        var path = this.svg.selectAll("#" + parentId)
            .data(slices, function(d) {
              return d.data.id;
            })
            .enter().append("svg:path")
            .attr("id", function(d) {
              return d.data.id;
            })
            .style("visibility", function(d) {
              return d.render ? "" : "hidden";
            })
            .attr("fill-rule", "evenodd")
            .attr("fill",

                  function (d, i) {                    
                    var col = undefined;
                    if(d.mark) {
                      col = markColorsPartial();
                    } else if(segmendColor !== undefined) {
                      col = d.clickable ? color(segmendColor, undefined, slices.length, i) : color(segmendColor, 0.5, slices.length, i);
                    } else {
                      col =  d.clickable ? color(i, undefined) : color(i, 0.3);
                    }
                    //push back col for later usage
                    if(d.color === undefined) {
                      d["color"] = col;
                    }
                    return col;
                  }).attr("d", arc)
            //.style("opacity", Math.pow(1 / deepth, 0.7))
            .on("mouseover", this.mouseover.bind(this))
            .on("click", this.mouseclick.bind(this));

        //render next level
        for (var i = 0; i < data.length; i++) {
          //we don't render leaf data, the outermost slice denotes the segmentation that results in the leaf data
          var slice = slices[i];
          this.renderLevel(slice, data[i].orig.v, deepth + 1, data[i].id, slice.start, slice.stop, segmendColor === undefined ? i : segmendColor);
        }
      }
    }
  }

  this.remove = function() {
    //render gretel trail above the sunburst
    root.select("div#sequence").remove();
    root.select("div#sunburst").remove();
  }

  //traverses the data model recursivly in order to get the max deepth
  this.getMaxDeepth = function(data) {
    return data.map((function(x) {
      if(x.l) {
        return 1;
      } else {
        return this.getMaxDeepth(x.v) + 1;
      }
    }).bind(this))
      .reduce(function(acc, x) {
        return Math.max(acc, x);
      }, 0);
  }

  this.onkeyup = function(event) {
    switch(event.keyCode) {
    case 13: search.vm.updateSunburst.flush(); search.vm.submit(); break;
    case 27: search.vm.updateSunburst.cancel(); search.vm.cancel(); break;
    }}

  //renders the thing for the first time
  this.render = function(data, meta) {
    if(data === undefined || data.map === undefined) {
      throw "render(data, meta) must be called on [data] parameter which is an array"
    }
    if(meta === undefined || meta.topology === undefined) {
      throw "render(data, meta) must be called on [meta] parameter which is an object, containing the key topology, that is in turn an array"
    }

    //get some metadata
    
    this.maxDeepth = this.getMaxDeepth(data);
    if(this.deepthConstraint) {
      this.maxDeepth = Math.min(this.maxDeepth, this.deepthConstraint);
    }
    this.topology = meta.topology;
    this.cutDown = m.prop(meta.cutDown || false);

    //reset state
    this.selected = undefined;
    this.zoominRequested(false);

    //reduce to some facts
    this.totalSize = data.reduce(function(acc, x) {
      //.c like count
      return acc + (x.l == false ? x.c : 1);
    }, 0);

    if(this.state() === this.STATES.NOT_RENDERED) {

      //render gretel trail above the sunburst
      var sequence = root.append("div")
          .attr("id", "sequence")
          .attr("class", this.sequenceCss);

      var actions = root.append("div")
          .attr("id", "actions");
      //render the zoom-in
      actions.append("a")
        .attr("data-toogle", "tooltip")
        .attr("data-placement", "top")
        .attr("title", "Click or press + to zoom-in")
        .attr("id","zoomin")
        .style("z-index", 1)
        .style("visibility", this.onZoomin !== undefined ? "" : "hidden")
        .on("click", this.zoomin.bind(this))
        .append("span").attr("class", "glyphicon glyphicon-zoom-in .x2").attr("aria-hidden", "true");
      //render the zoom-out
      actions.append("a")
        .attr("data-toogle", "tooltip")
        .attr("data-placement", "top")
        .attr("title", "Click or press - to zoom-out")
        .attr("id","zoomout")
        .style("z-index", 1)
        .style("visibility", (this.invariantPrefix().length > 0 && this.onZoomout !== undefined) ? "" : "hidden")
        .on("click", this.zoomout.bind(this))
        .append("span").attr("class", "glyphicon glyphicon-zoom-out .x2").attr("aria-hidden", "true");    
      
      //render the sunburst container div
      var div = root.append("div")
          .attr("id", "sunburst");
      //render the lock that can be used to deselect (alternative to select the same twice)
      sequence.append("a")
        .attr("data-toogle", "tooltip")
        .attr("data-placement", "top")
        .attr("title", "Click to revoke the selection")
        .attr("id","lock")
        .style("z-index", 1)
        .style("visibility", "hidden")
        .on("click", this.unlock.bind(this))
        .append("span").attr("class", "glyphicon glyphicon-pushpin").attr("aria-hidden", "true");
      
      //render the actual svg group
      this.svg = div
        .append("svg")
        .attr("width", this.size)
        .attr("height", this.size)
        .attr("class", this.svgCss)
        .on("keyup", this.onkeyup.bind(this))
        .append("g")
        .attr("id", "container")
        .attr("transform", "translate(" + this.radius + "," + this.radius + ")");

      //render center text that contains the ratio in percent
      this.svg
        .append("text").attr("id", "explanation")
        .attr("y", "1em")
        .style("visibility", "hidden");
      this.svg
        .append("text").attr("id", "percentage")
        .style("visibility", "hidden");

      // Bounding circle underneath the sunburst, to make it easier to detect
      // when the mouse leaves the parent g.
      this.svg.append("svg:circle")
        .attr("r", this.radius)
        .style("opacity", 0)

      //initialize trail
      this.initializeGretel();

      // Add the mouseleave handler to the bounding circle.
      root.select("#container").on("mouseleave", this.mouseleave.bind(this));

      this.renderLevel(null, data, 1, "path", 0, 2 * Math.PI);
      this.state(this.STATES.RENDERED);
    } else {
      this.unlock();
      //wipe out old content
      this.svg.selectAll("path").remove();
      this.renderLevel(null, data, 1, "path", 0, 2 * Math.PI);
      
      //update zoomin
      root.select("#zoomout").style("visibility", (this.invariantPrefix().length > 0 && this.onZoomout !== undefined) ? "" : "hidden");

    }
    return this;
  }
}
