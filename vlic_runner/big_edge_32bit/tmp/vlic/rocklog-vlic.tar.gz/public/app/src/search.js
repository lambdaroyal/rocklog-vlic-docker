//Search Process - This is a aggregating process that comes with function menu on the left,
//and a search on the right initially taking all space up

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state,
// this gets scoped without regard to the controller
// so this won't die if the user steps out of a
// mithril modul that gets unmounted
/////////////////////////////////////////////////////

var searchRoot = {}
var searchFunctions = {}
var search = {
  history: m.prop([]),
  text: m.prop(""),
}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////

searchRoot.vm = {
  onload: function() {
    this.dialog = new ModalMessageBar("search");
  },
  onunload: function() {
    if(this.dialog) {
      this.dialog.abort();
    }
  }
}

searchFunctions.vm = {
  //denotes that the user pressed the button, now he can select a location or press again for searching the whole space
  webshopPressedOnce: m.prop(false),
  webshopButtonAddClass: m.prop(""),

  init: function() {
    searchFunctions.vm.functions = new FunctionPanel(

      {add: {imageClass: "glyphicon-plus", tooltip: "Create new stocks",
             onclick: function() {
               
               route("/inbound", inboundRoot);
             }, enabled: true
            },
       edit: {imageClass: "glyphicon-pencil", tooltip: "Modify cards", 
              onclick: function() {
                if(search.vm.cardPanel) {
                  var data = search.vm.cardPanel.getDataOfSelectedCards();
                  if(data.length > 0) {
                    sideditRoot.data = data;
                    route("/sidedit", sideditRoot);
                  }
                }
              }, enabled: false},
       xfer: {imageClass: "glyphicon-fullscreen", tooltip: "Transfer stocks",
              onclick: function() {
                if(search.vm.cardPanel) {
                  var data = search.vm.cardPanel.getDataOfSelectedCards();
                  if(data.length > 0) {
                    xferCards.vm.enableInboundMode(false);
                    xferTarget.vm.invariantPrefix([]);
                    xferCards.data = data;
                    route("/xfer", xferRoot);
                  }
                }
              }, enabled: false},
       clone: {imageClass: "glyphicon-duplicate", tooltip: "Clone card", enabled: false},
       importdata: {imageClass: "glyphicon-import", tooltip: "Import card from file", enabled: false},
       selectAll: {imageClass: "glyphicon", tooltip: "Select all cards", enabled: false, imageRenderer: FunctionSelectAll, enabled: false},
       deselectAll: {imageClass: "glyphicon", tooltip: "Deselect all cards", imageRenderer: FunctionDeselectAll, enabled: false},
       trash: {imageClass: "glyphicon glyphicon-trash", tooltip: "Delete cards", enabled: false},
       webshop: {imageClass: "glyphicon glyphicon-shopping-cart", tooltip: "Pick to basket from selected selected location/all locations", addClass: this.webshopButtonAddClass, enabled: true, onclick: this.onwebshop.bind(this)}});
  },

  toggleOverviewFunction: function(enable) {
    ["webshop"].map(function(n) {
      searchFunctions.vm.functions.enable(n, enable);
    });
  },

  beforeLoad: function() {
    this.webshopPressedOnce(false);
    this.webshopButtonAddClass("");
  },

  onwebshop: function() {
    if(!this.webshopPressedOnce()) {
      this.webshopPressedOnce(true);
      this.webshopButtonAddClass("toggled");
    } else {
      //search for the articles
      global.autobahn.sync({event:"search", query: (search.vm.lidPrefix() || []), sessionId: global.autobahn.sessionId, search: "did-by-lid-prefix"})
        .then(function(data) {
                                       webshopCards.data = data.data;
                                       webshopCards.lidPrefix(search.vm.lidPrefix() || []);
                                       route("/webshop", webshopRoot);
                                       callback();
        })
        .catch(function(msg) {
          searchRoot.vm.dialog.show({severity: ModalMessageSeverity.WARNING,
                                     message: "Webshopping is currently not available due to your slow internet connectivity. Try again.",
                                     title: "Webshop not available",
                                     onOk: function(callback) {
                                       callback();
                                     }
                                    })});

    }
  }
}

search.vm = {
  //denotes a condition all subsequently searches must incooperate, with layman terms, only those cards are displayed that match the condition
  lidPrefix: m.prop(),
  updateSunburst : throttleWrap(function(value) {
    return;
    global.autobahn.sync({event:"search", query: value, sessionId: global.autobahn.sessionId, search: "hierarchie-proj-article-location"}).then(function(data) {
      var fn = search.vm.sunburst.render.bind(search.vm.sunburst);
      fn(data.data);

    })
  }, 300),

  /**
   * switches from overview mode to search mode
   */
  switchMode: function(overview, old) {
    if(overview === true) {
      if(old != overview) {
        this.lidPrefix(undefined);
        this.renderOverviewSunburst();
        this.removeSearchStats();
        searchFunctions.vm.toggleOverviewFunction(true);
      }

    } else if (overview === false) {
      if(old != overview) {
        this.removeOverviewSunburst();
        this.renderSearchStats();
        this.resetSearchStats();
        this.focus();
        searchFunctions.vm.toggleOverviewFunction(false);
      }
    }
  },

  trash: function() {
    m.startComputation();
    var selectedCards = this.cardPanel.getSelectedCards();
    var data = [];
    selectedCards.each(function(n) {
      data.push( {key: n[0], coll: n[1].coll});
    });
    
    searchRoot.vm.dialog.show({severity: ModalMessageSeverity.WARNING, 
                               message: (data.length > 1 ? "The selected SIDs will be deleted. Are you sure?" : "This SID will be deleted. Are you sure?"),
                               title: "Are you sure?",
                               okLabel: "Delete",
                               onCancel: function(callback) {
                                 m.endComputation();
                                 callback();
                               },
                               onOk: function(callback) {
                                 global.autobahn.sync({event:"card", data: data, sessionId: global.autobahn.sessionId, fn: "delete"}).then(function(data) {
                                   selectedCards.remove();
                                   search.vm.enableFunctionsAfterTrash();
                                   m.endComputation();
                                   callback();
                                 })
                                   .catch(function(msg) {
                                     console.log(msg);
                                     m.endComputation();
                                     callback();
                                   });

                               }});
  },

  selectAll: function() {
    m.startComputation();
    searchFunctions.vm.functions.enable("selectAll", false);
    ["deselectAll","trash","xfer","edit"].map(function(n) {
      searchFunctions.vm.functions.enable(n, true);
    });
    m.endComputation();
    this.cardPanel.selectAll(true);
  },

  deselectAll: function() {
    m.startComputation();
    searchFunctions.vm.functions.enable("selectAll", true);
    ["deselectAll","trash","xfer","edit"].map(function(n) {
      searchFunctions.vm.functions.enable(n, false);
    });

    m.endComputation();
    this.cardPanel.selectAll(false);
  },

  enableSelectAll: function() {
    m.startComputation();
    searchFunctions.vm.functions.enable("selectAll", true);
    m.endComputation();
  },

  enableFunctionsAfterTrash: function() {
    searchFunctions.vm.functions.enable("selectAll", this.cardPanel.getCardCount() > 0);
    ["deselectAll","trash","xfer","edit"].map(function(n) {
      searchFunctions.vm.functions.enable(n, false);
    });
    m.endComputation();
  },

  enableFunctionsAfterDeselection: function() {
    if(!this.cardPanel.getSelectedCards().empty()) {
      ["deselectAll","trash","xfer","edit"].map(function(n) {
        searchFunctions.vm.functions.enable(n, true);
      });
    } else {
      ["deselectAll","trash","xfer","edit"].map(function(n) {
        searchFunctions.vm.functions.enable(n, false);
      });
    }
  },

  onClick: function(d) {
    m.startComputation();
    var selected = d[1]._selected;

    //user switched one card on: enable delete, enable deselect all
    if(selected) {
      ["deselectAll","trash","xfer","edit"].map(function(n) {
        searchFunctions.vm.functions.enable(n, true);
      });

      //select all gets disabled when all cards are selected
      searchFunctions.vm.functions.enable("selectAll", !search.vm.cardPanel.getDeselectedCards().empty());

      m.endComputation();
      
    } else {
      //user switched on off: enable selectAll,check whether there is one selected left 
      searchFunctions.vm.functions.enable("selectAll", true);

      search.vm.enableFunctionsAfterDeselection();
      m.endComputation();
    }

    m.endComputation();
  },

  beforeLoad: function() {
    search.history([]);
    search.text("");
  },

  onzoomOverview: function(prefix) {
    var x = global.rampup.onlinestats()["lid-hierarchie"];
    data = hierarchieDfs(x.data, prefix);
    if(data) {
      var meta = {topology: x.meta.topology.slice(prefix.length)};
      if(data.v) {
        search.vm.overviewSunburst.render(data.v, meta);
      } else if(data.length > 0) {
        search.vm.overviewSunburst.render(data, meta);
      }             
    }
  },

  renderOverviewSunburst: function() {
    d3.select("#spaLeft").selectAll("div#overview").remove();
    if(global.rampup.onlinestats()) {
      var root = d3.select("#spaLeft").append("div").attr("id", "overview").attr("class", "overview");
      search.vm.overviewSunburst = new Sunburst(root,
                                                {deepthConstraint: 3,
                                                 size: Math.min(window.innerHeight * 0.60, window.innerWidth * 0.60),
                                                 getCenterString: function(x) {
                                                   return "" + x.data.count;
                                                 },
                                                 getCenterDescription: function(x) {
                                                   return "# Locations";
                                                 },
                                                 onZoomin: search.vm.onzoomOverview.bind(search.vm),
                                                 onZoomout: search.vm.onzoomOverview.bind(search.vm),
                                                 isSegmentClickable: function(x) {
                                                   return true
                                                 },

                                                 onClick: search.vm.onclickSunburst.bind(search.vm)

                                                });

      search.vm.overviewStats = new StatsComp(root, {
        "sid-count": global.rampup.onlinestats()["sid-count"],
        "lid-count": global.rampup.onlinestats()["lid-count"]
      });


      var xs = global.rampup.onlinestats()["lid-hierarchie"];
      xs.meta.maxDeepth = 3;
      search.vm.overviewSunburst.render(xs.data, xs.meta);
      search.vm.overviewStats.view();
    }
  },

  removeOverviewSunburst: function() {
    d3.select("#spaLeft").selectAll("div#overview").remove();
  },

  renderSearchStats: function() {
    var root = d3.select("#spaLeft").append("div").attr("id", "searchStats").attr("class", "searchStats");
    search.vm.searchStats = new StatsComp(root, {
      "sid-count": global.rampup.onlinestats()["sid-count"],
      "lid-count": global.rampup.onlinestats()["lid-count"],
      delay: "n/a"
    });
    search.vm.searchStats.view();
  },

  removeSearchStats: function() {
    d3.select("#spaLeft").selectAll("div#searchStats").remove();
  },

  onclickSunburst: function(sequenceArray) {

    //get hierarchie
    var hierarchie = search.vm.overviewSunburst.getPrefix();
    this.lidPrefix(hierarchie);

    //check we are in pre-webshop mode
    if(searchFunctions.vm.webshopPressedOnce()) {
      searchFunctions.vm.onwebshop();
      return;
    }

    this.overview(false);
    
    global.autobahn.sync({event:"search", query: "", lidPrefix: hierarchie, sessionId: global.autobahn.sessionId, search: "sid-all"});
    search.text("");
    search.vm.focus();    
  },

  recalcSearchStats: function() {
    if(!this.overview() && this.searchStats) {
      var sids = 0;
      var lids = new Map();
      this.cardPanel.getCards().each((function(data) {
        sids = sids + 1;
        if(data[1].location) {
          lids.set(data[1].location[0],data[1].location[0]);
        }
      }).bind(this));
      this.searchStats["sid-count"] = sids;
      this.searchStats["lid-count"] = lids.size;
      this.searchStats.update();

    }
  },
  resetSearchStats: function() {
    if(!this.overview() && this.searchStats) {
      this.searchStats["sid-count"] = 0;
      this.searchStats["lid-count"] = 0;
      this.searchStats["delay"] = 0;
      this.searchStats.update();
    }
  },

  onload: function() {
    this.focus();

    //init the cardPanel
    var container = document.getElementById("spaLeft");
    this.cardPanel = new CardPanel(container, {onClick: this.onClick});

    this.overview(true);

    
    //search.vm.sunburst = new Sunburst(d3.select("div#spaLeft"), {size: window.innerHeight * 0.8});
    search.vm.isMarked = function(x) {
      return (x.orig[1] !== undefined && typeof x.orig[1] == "object" && typeof x.orig[1].capacity == "number") ? 
        (x.orig[1].locked == false && x.orig[1].capacity > 0) : false;
    }
    search.vm.matchingStock = function(x) {
      return (x.orig[1] !== undefined && typeof x.orig[1] == "object" && typeof x.orig[1]["count-matching-stocks"] == "number" && x.orig[1]["count-matching-stocks"] > 0) ? true : false;
    }

    //decorate the function buttons with select/deselect/trash listeners
    searchFunctions.vm.functions.setOnclick("selectAll",this.selectAll.bind(this));
    searchFunctions.vm.functions.setOnclick("deselectAll",this.deselectAll.bind(this));
    searchFunctions.vm.functions.setOnclick("trash", this.trash.bind(this)); 

    //subscribe to search results from server
    this.searchresultSub = global.autobahn.sub(global.TOPICS.searchresult, function(data) {
      if(!search.vm.overview()) {
        search.vm.cardPanel.render(data.data, true);
        search.vm.recalcSearchStats();
        if(!searchFunctions.vm.functions.enabled("selectAll") && data.data.length > 0) {
          m.startComputation();
          searchFunctions.vm.functions.enable("selectAll", true);
          m.endComputation();
        };
      }
    });
    this.searchdelaySub = global.autobahn.sub(global.TOPICS.searchdelay, (function(data) {
      if(!this.overview() && this.searchStats && data.delay) {
        this.searchStats.delay = data.delay;
        this.searchStats.update();
      }
      console.log("received message on topic searchdelay: " + JSON.stringify(data));
    }).bind(this));

    this.onlinestatsFollow = global.autobahn.sub(
      global.TOPICS.onlinestatsFollow, 
      (function(data){
        if(this.overview() && this.overviewStats) {
          this.overviewStats[data[0]] = data[1];
          this.overviewStats.update();
        }
      }).bind(this));

    return this;
  },

  onunload: function() {
    if(this.onlinestatsFollowSub) {
      global.autobahn.desub(global.TOPICS.onlinestatsFollow, inboundProcess.vm.onlinestatsFollowSub);
    }
    global.autobahn.desub(global.TOPICS.searchresult, this.searchresultSub);
    global.autobahn.desub(global.TOPICS.searchdelay, this.searchdelaySub);
    if(this.cardPanel) {
      this.cardPanel.remove();
    }
    if(this.overview()) {
      this.removeOverviewSunburst();
    } else {
      this.removeSearchStats();
    }
  },

  oninput : function(value) {
    search.text(value);
    search.vm.updateSunburst.get()(value);
  },
  onkeyup : function(event) {
    switch(event.keyCode) {
    case 13: search.vm.updateSunburst.flush(); search.vm.submit(); break;
    case 27: search.vm.updateSunburst.cancel(); search.vm.cancel(); break;
    }}
  ,
  submit : throttle(function() {
    if(search.text()) {
      search.vm.overview(false);
      search.vm.resetSearchStats();

      if(this.lidPrefix() && search.history().length == 0) {
        this.cardPanel.removeAllCards();
      }

      search.history().push(search.text());
      var req = {event:"search", query: search.text(), sessionId: global.autobahn.sessionId, search: "sid"};
      if(this.lidPrefix()) {
        req.lidPrefix = this.lidPrefix;
      }
      global.autobahn.sync(req);
      search.text("");
    }
  }, 300),

  cancel : function() {
    search.history([]);
    search.text("");
    this.cardPanel.removeAllCards();
    search.vm.recalcSearchStats();

    ["selectAll", "deselectAll", "trash", "xfer","edit"].map(function(n) {
      searchFunctions.vm.functions.enable(n, false);
    });
    this.overview(true);
  },

  focus: function() {
    setTimeout(function() {
      var div = document.getElementById("searchInput");
      if(div) {
        div.focus();
      }
    }, 20)},


  //do the search again up to selected index
  redo: function(i) {
    this.cardPanel.removeAllCards();
    search.vm.recalcSearchStats();

    search.text("");
    search.vm.focus();
    
    if(i < 0 && this.lidPrefix()) {
      search.history([]);
      global.autobahn.sync({event:"search", query: "", lidPrefix: this.lidPrefix(), sessionId: global.autobahn.sessionId, search: "sid-all"});

    } else {
      search.history(search.history().slice(0, i + 1));
      search.history().map((function(n) {
        var req = {event:"search", query: n, sessionId: global.autobahn.sessionId, search: "sid"};
        if(this.lidPrefix()) {
          req.lidPrefix = this.lidPrefix;
        }

        global.autobahn.sync(req);
      }).bind(this)); 

    }

  },

  init: function() {
    this.overview = propWithCallback(undefined, this.switchMode.bind(this));

    //decorate the checkdigit
    this.oncheckdigitinput = function(input) {
      m.startComputation();
      var req = {"by-sid": true, "by-lid": true}
      if(this.checkDigitInput.lastInput.length > 0) {
        var lastState = this.checkDigitInput.state() === this.checkDigitInput.STATES.UP ? "checkdigit1" : "checkdigit0";
        req[lastState] = this.checkDigitInput.lastInput.join("");
      }
      var currentState = this.checkDigitInput.state() === this.checkDigitInput.STATES.UP ? "checkdigit0" : "checkdigit1";
      req[currentState] = input;
      global.autobahn.sync({event:"search", query: req, sessionId: global.autobahn.sessionId, search: "checkdigit-to-sid"}).then(function(data) {
        if(data.data !== undefined) {
          //we got a functional response
          if(data.data.data !== undefined) {
            if(data.data.data.length === 1) {
              //here false means to remove the old stuff
              search.vm.checkDigitInput.reset();
              search.vm.overview(false);
              search.history().push(data.data.data[0][0]);
              search.vm.cardPanel.render(data.data.data, true);
              search.vm.recalcSearchStats();


            } else if(data.data.data.length > 1) {
              search.vm.checkDigitInput.switchState();
            } else {
              search.vm.checkDigitInput.reset();
            }
          }
        }

        //render always
        m.endComputation();
      })};
    
    this.checkdigitView = function() {
      var hidden = this.checkDigitInput.input.length == 0 && this.checkDigitInput.lastInput.length == 0;
      return [<div class={"btn btn-default btn-lg btn-function sprechblase " + (hidden ? "hidden" : "visible")} onclick={this.checkDigitInput.onreset.bind(this.checkDigitInput)}>
              <span class={this.checkDigitInput.lastInput.length > 0 ? "" : "hidden"}>Checkdigit <span class="input">{this.checkDigitInput.lastInput}</span> is not unique</span><br/>
              <span class={"force " + (this.checkDigitInput.lastInput.length > 0 ? "" : "hidden")}>Key in the other checkdigit on the card.</span><br/>
              <span class={this.checkDigitInput.input.length > 0 ? "" : "hidden"}>You keyed in <span class="input">{this.checkDigitInput.input}</span></span><br/>
              <br/>Press this speech bubble to reset the input.</div>,
              this.checkDigitInput.view()]
    }

    this.checkDigitInput = new MobileCheckDigitInput({oninput: this.oncheckdigitinput.bind(this),
                                                      autoCollapse: true,
                                                      fontSize: 1.5});
  }
};

var SearchInputComp = {
  renderLidPrefixSpan: function() {
    if(search.vm.lidPrefix()) {
      return <div class="form-control searchHistory">
        <a onclick={search.vm.redo.bind(search.vm,-1)}><span class="glyphicons glyphicons-filter" title="Click here to search for all SIDs as per the choosen location" data-toggle="tooltip" data-placement="top"/></a></div>
    } else {
      return undefined;
    }
  },

  view: function(ctrl, args) {
    return <div onkeyup={search.vm.onkeyup.bind(search.vm)} class="searchContainer form-inline pull-right ng-pristine ng-valid" role="form" autocomplete="off">
      <div class="form-group inner-addon left-addon pull-right">
      <div class="input-group">
      <i class="glyphicon glyphicon-search"></i>
      <input id={args.id} type="text" class="form-control my-input ng-pristine ng-untouched ng-valid" name="text" placeholder="Enter to search" data-toggle="tooltip" data-placement="top" title="Press ESC to discard all cards and to search again" focus-on="focusText" oninput={m.withAttr("value", search.vm.oninput.bind(search.vm))} value={args.search.text()}/> 
      </div>
      </div>
      <div class="form-group">
      {this.renderLidPrefixSpan()}
    {
      args.search.history().map(function(n,i) {
        return <span>
          <div class="form-control searchHistory"><a onclick={search.vm.redo.bind(search.vm,i)}>{n}</a></div>
          </span>

      })
    }
    </div>

    </div>
  }
}

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////

searchFunctions.controller = function() {
  searchFunctions.vm.init();
};
searchFunctions.view = function(ctrl) {
  return searchFunctions.vm.functions.view(ctrl);
}

search.controller = function() {
  search.vm.init();
};
search.view = function(ctrl) {
  return m.component(SearchInputComp, {id: "searchInput", search: search});
}

searchRoot.controller = function() {
  return {
    searchFunctions : submodule(searchFunctions),
    search : submodule(search),

    onunload: function() {
      search.vm.onunload();
      searchRoot.vm.onunload();
    }
  }
}

searchRoot.onload = function() {
  searchRoot.vm.onload();
  search.vm.onload();
}

searchRoot.beforeLoad = function() {
  search.vm.beforeLoad();
  searchFunctions.vm.beforeLoad()
}

searchRoot.view = function(ctrl) {
  return [m("div[id=spaFunctions]", ctrl.searchFunctions()),
          m("div[id=spaLeft]"),
          m("div[id=spaRight]", ctrl.search()),
          m("div[id=spaInvariantsRB]", search.vm.checkdigitView())]
}
