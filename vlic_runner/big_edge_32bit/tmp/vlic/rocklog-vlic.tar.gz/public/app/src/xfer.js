//Xfer Process, Transfer stocks to another location
//Technically the xfer process takes cardpanel into account, displays all the selected sids on the left
//displays the location sunburst with empty locations on the right and let the user drop to empty or capacitife locations
//then the user can pin the sunburst, so all the (already selected) stocks get transfered
//the user can repeat this process as long as desired

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state
/////////////////////////////////////////////////////
var xferRoot = {}
var xferFunctions = {}
var xferTarget = {}
var xferCards = {
  data: []
}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////
xferRoot.vm = {}

xferFunctions.vm = {
  trashAvailable: m.prop(false),

  init: function() {
    xferFunctions.vm.functions = new FunctionPanel(

      {selectAll: {imageClass: "glyphicon", tooltip: "Select all cards", enabled: false, imageRenderer: FunctionSelectAll, enabled: false},
       deselectAll: {imageClass: "glyphicon", tooltip: "Deselect all cards", imageRenderer: FunctionDeselectAll, enabled: false},
       trash: {imageClass: "glyphicon glyphicon-trash", tooltip: "Delete cards", enabled: false},
       home: {imageClass: "glyphicon glyphicon-home", tooltip: "Back to search", onclick: function() {
         route("/search", searchRoot);
       }, enabled: true}});
  }
}


xferCards.vm = {
  //this property denotes whether we want generate a label at first drop (after sid was generated)
  printOnFirstDrop: m.prop(false),
  //this property denotes whether generated labels are send async back to the client
  sendBackLabel: m.prop(false),
  
  enableInboundMode: function(enable) {
    this.printOnFirstDrop(enable);
    xferFunctions.vm.trashAvailable(enable);
  },

  selectAll: function() {
    m.startComputation();
    xferFunctions.vm.functions.enable("selectAll", false);
    xferFunctions.vm.functions.enable("deselectAll", true);
    xferFunctions.vm.functions.enable("trash", xferFunctions.vm.trashAvailable());

    m.endComputation();
    this.cardPanel.selectAll(true);
  },

  deselectAll: function() {
    m.startComputation();
    xferFunctions.vm.functions.enable("selectAll", true);
    xferFunctions.vm.functions.enable("deselectAll", false);
    xferFunctions.vm.functions.enable("trash", false);

    m.endComputation();
    this.cardPanel.selectAll(false);
  },

  enableSelectAll: function() {
    m.startComputation();
    xferFunctions.vm.functions.enable("selectAll", true);
    m.endComputation();
  },

  enableFunctionsAfterTrash: function() {
    xferFunctions.vm.functions.enable("selectAll", this.cardPanel.getCardCount() > 0);
    ["deselectAll","trash","xfer"].map(function(n) {
      xferFunctions.vm.functions.enable(n, false);
    });
    m.endComputation();
  },

  enableFunctionsAfterDeselection: function() {
    if(!this.cardPanel.getSelectedCards().empty()) {
      ["deselectAll"].map(function(n) {
        xferFunctions.vm.functions.enable(n, true);
      });
      xferFunctions.vm.functions.enable("trash", xferFunctions.vm.trashAvailable());

    } else {
      ["deselectAll","trash"].map(function(n) {
        xferFunctions.vm.functions.enable(n, false);
      });
    }
  },

  onClick: function(d) {
    m.startComputation();
    var selected = d[1]._selected;

    //user switched one card on: enable delete, enable deselect all
    if(selected) {
      ["deselectAll"].map(function(n) {
        xferFunctions.vm.functions.enable(n, true);
      });
      xferFunctions.vm.functions.enable("trash", xferFunctions.vm.trashAvailable());


      //select all gets disabled when all cards are selected
      xferFunctions.vm.functions.enable("selectAll", !xferCards.vm.cardPanel.getDeselectedCards().empty());
      
    } else {
      //user switched on off: enable selectAll,check whether there is one selected left 
      xferFunctions.vm.functions.enable("selectAll", true);

      xferCards.vm.enableFunctionsAfterDeselection();
    };
    m.endComputation();
  },

  onload: function() {
    //decorate the function buttons with select/deselect/trash listeners
    xferFunctions.vm.functions.setOnclick("selectAll",this.selectAll.bind(this));
    xferFunctions.vm.functions.setOnclick("deselectAll",this.deselectAll.bind(this));
    xferFunctions.vm.functions.setOnclick("trash",this.trash.bind(this));

    return this;
  },

  //mounts the panel 
  mount: function() {
    var container = document.getElementById("spaLeft");
    this.cardPanel = new CardPanel(container, {onClick: this.onClick});
    if(xferCards.data.length > 0) {
      xferFunctions.vm.functions.enable("selectAll", true);
      xferFunctions.vm.functions.enable("deselectAll", false);
    } else {
      xferFunctions.vm.functions.enable("selectAll", false);
      xferFunctions.vm.functions.enable("deselectAll", false);
    }
    
    m.endComputation();
    //since render relies on d3 we do it asynchronously
    setTimeout(function() {
      xferCards.vm.cardPanel.render(xferCards.data);
      xferCards.vm.selectAll();
    }, 10);
  },

  onunload: function() {
    if(this.cardPanel) {
      this.cardPanel.remove();
    }
  },

  trash: function() {
    m.startComputation();
    var selectedCards = this.cardPanel.getSelectedCards();
    var data = [];
    selectedCards.each(function(n) {
      data.push( {key: n[0], coll: n[1].coll});
    });

    global.autobahn.sync({event:"card", data: data, sessionId: global.autobahn.sessionId, fn: "delete"}).then(function(data) {
      selectedCards.remove();
      
      //get out if nothing is left
      if(xferCards.vm.cardPanel.getCardCount() == 0) {
        route("/search", searchRoot);
        m.endComputation();
      } else {
        search.vm.enableFunctionsAfterTrash();
      }
    })
  },

  dropOnCheckdigit: function(input) {


  },

  drop: function(sequenceArray) {
    //get hierarchie
    var hierarchie = xferTarget.vm.sunburst.getPrefix();

    //get all selected data
    var keys = xferCards.data.filter(function(x) {
      return x[1]._selected;
    }).map(function(x) {
      return x[0];
    });

    //do only something if something was selected at all
    if(keys.length > 0) {

      global.autobahn.sync({event:"xfer", fn:"drop", data: {keys: keys, constraints: hierarchie, "print-at-first-drop": xferCards.vm.printOnFirstDrop(), "send-back-label": xferCards.vm.sendBackLabel()}}).then(function(data) {
        //deselect those that where relocated
        data.data[1].map(function(n) {
          var cardSelect = xferCards.vm.cardPanel.select("stock", n.sid, false);
          //update model
          xferCards.vm.cardPanel.updateLocation(cardSelect, n.location);
        });

        //so we can select again all
        if(data.data[1].length > 0) {
          m.startComputation();
          xferCards.vm.enableSelectAll();
          xferCards.vm.enableFunctionsAfterDeselection();
          m.endComputation();
        }

        //update the sunburst with empty locations
        xferTarget.vm.updateSunburst("");      
      })
        .catch(function(msg) { 
          console.log(msg)
        });
    }
  }
};

xferTarget.vm = {
  updateSunburst: function(x, prefix) {
    //update location context
    global.autobahn.sync({event:"search", query: x, sessionId: global.autobahn.sessionId, search: "hierarchie-location-for-inbound", opts: ["prefix", prefix !== undefined ? prefix :xferTarget.vm.sunburst.invariantPrefix()]}).then(function(data) {
      xferTarget.vm.sunburst.render.bind(xferTarget.vm.sunburst)(data.data, data.meta);
    })

  },
  //use this to inject a search constraint on the sunburst
  invariantPrefix: m.prop([]),
  isMarked : function(x) {
    if(x.orig.l === true) {
      return x.orig.capacity > 0;
    }
    return false;
  },
  matchingStock : function(x) {
    return x.orig.l === true && x.orig.v !== undefined && x.orig.v["count-matching-stocks"] > 0;
  },

  onload: function() {
    xferTarget.vm.sunburst = new Sunburst(d3.select("div#spaRight"), 
                                          {size: Math.min(window.innerHeight * 0.7, window.innerWidth * 0.25), svgCss: "sunburstRight", sequenceCss: "sequenceRight",
                                           isRendered: function(x) {
                                             return (x.orig.capacity !== undefined && x.orig.capacity > 0) || inboundContext.vm.isMarked(x) || inboundContext.vm.matchingStock(x) || x.orig.l === false;
                                           },
                                           isSegmentClickable: function(x) {
                                             return xferTarget.vm.isMarked(x) ||
                                               (x.orig.capacity !== undefined && x.orig.capacity > 0); 
                                           },
                                           getRadiusRatio: function(x) {
                                             return (x.orig.l === false || xferTarget.vm.isMarked(x)) ? 1.0 : 0.4;
                                           },
                                           getCenterString: function(x) {
                                             return "" + x.data.orig.capacity;
                                           },
                                           getCenterDescription: function(x) {
                                             return "Capacity left";
                                           },
                                           isMarked: xferTarget.vm.isMarked,
                                           onClick: xferCards.vm.drop,
                                           onZoomin: function(prefix) {
                                             xferTarget.vm.updateSunburst("", prefix);
                                           },
                                           onZoomout: function(prefix) {
                                             xferTarget.vm.updateSunburst("", prefix);
                                           },
                                           isLeafZoomable: function(prefix,d) {
                                             return d.data.orig.v.c !== undefined && d.data.orig.v.c > 1;
                                           }});
    //dummy search at start-up
    xferTarget.vm.sunburst.invariantPrefix(xferTarget.vm.invariantPrefix());
    xferTarget.vm.updateSunburst("");
  },

  onunload: function() {
    if(xferTarget.vm.sunburst) {
      xferTarget.vm.sunburst.remove();
    }
  }
}

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
xferFunctions.controller = function() {
  xferFunctions.vm.init();
};
xferFunctions.view = function(ctrl) {
  return xferFunctions.vm.functions.view(ctrl);
}


xferTarget.controller = function() {
}

xferTarget.view = function(ctrl) {
  return [];
}

xferCards.controller = function() {
};

xferCards.view = function(ctrl) {
  return [];
};

xferRoot.controller = function() {
  return {
    xferFunctions: submodule(xferFunctions),
    xferTarget : submodule(xferTarget),
    xferCards : submodule(xferCards),
    checkDigitInput : submodule(checkDigitInput),

    onunload: function(){
      xferTarget.vm.onunload();
      xferCards.vm.onunload();
    }
  }
}

xferRoot.view = function(ctrl) {
  return [m("div[id=spaFunctions]", ctrl.xferFunctions()),
          m("div[id=spaLeft]"),
          m("div[id=spaRight]")
          //m("div[id=spaInvariantsRB]", ctrl.checkDigitInput())
         ]
}

xferRoot.onload = function() {
  xferTarget.vm.onload();
  xferCards.vm.onload();
  xferCards.vm.mount();
}
