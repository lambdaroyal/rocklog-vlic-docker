//WebshopCheckout.js - 
// After the user decides to checkout the pick amounts the effective picks (SIDs) are displayed and can be printed to pick list

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state,
// this gets scoped without regard to the controller
// so this won't die if the user steps out of a
// mithril modul that gets unmounted
/////////////////////////////////////////////////////

var webshopCheckoutRoot = {}
var webshopCheckoutFunctions = {}
var webshopCheckoutCards = {
  text: m.prop(""),
  data: []
}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////

webshopCheckoutRoot.vm = {
  onload: function() {
    this.dialog = new ModalMessageBar("webshopCheckout");
  },
  onunload: function() {
    if(this.dialog) {
      this.dialog.abort();
    }
  }
}

webshopCheckoutFunctions.vm = {
  init: function() {
    webshopCheckoutFunctions.vm.functions = new FunctionPanel(
      {
        print: {imageClass: "glyphicon glyphicon-print", tooltip: "Print picking list", enabled: true, onclick: this.onprint.bind(this)},
        home: {imageClass: "glyphicon glyphicon-home", tooltip: "Back to search", onclick: function() {
          route("/search", searchRoot);
        }, enabled: true}});
  },

  onprint: function() {
  }
}

webshopCheckoutCards.vm = {

  onload: function() {
    //init the cardPanel
    var container = document.getElementById("spaLeft");
    this.cardPanel = new CardPanel(container, 
                                   { defaultWidth: 85,
                                    selectOnClick: false});
    this.cardPanel.render(webshopCheckoutCards.data, true);
  },

  onunload: function() {
    if(this.cardPanel) {
      this.cardPanel.remove();
    }
  },

  init: function() {
    
  }
};

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////

webshopCheckoutFunctions.controller = function() {
  webshopCheckoutFunctions.vm.init();
};
webshopCheckoutFunctions.view = function(ctrl) {
  return webshopCheckoutFunctions.vm.functions.view(ctrl);
}

webshopCheckoutCards.controller = function() {
  webshopCheckoutCards.vm.init();
};
webshopCheckoutCards.view = function(ctrl) {
  return undefined;
}

webshopCheckoutRoot.controller = function() {
  return {
    webshopCheckoutFunctions : submodule(webshopCheckoutFunctions),
    webshopCheckoutCards : submodule(webshopCheckoutCards),

    onunload: function() {
      webshopCheckoutCards.vm.onunload();
      webshopCheckoutRoot.vm.onunload();
    }
  }
}

webshopCheckoutRoot.onload = function() {
  webshopCheckoutRoot.vm.onload();
  webshopCheckoutCards.vm.onload();
}

webshopCheckoutRoot.view = function(ctrl) {
  return [m("div[id=spaFunctions]", ctrl.webshopCheckoutFunctions()),
          m("div[id=spaLeft]"),
          m("div[id=spaRight]", ctrl.webshopCheckoutCards())]
}
