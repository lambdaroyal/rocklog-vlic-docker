//Search Process - This is a aggregating process that comes with function menu on the left,
//and a search on the right initially taking all space up

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state,
// this gets scoped without regard to the controller
// so this won't die if the user steps out of a
// mithril modul that gets unmounted
/////////////////////////////////////////////////////

var searchRoot = {}
var searchFunctions = {}
var search = {data: []}


/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////

searchRoot.vm = {
  onunload: function() {
    if(this.dialog) {
      this.dialog.abort();
    }
  },
  input: m.prop([]),
  onenter: function() {
    if(searchRoot.vm.input().length > 0) {
      searchRoot.vm.submitScan(searchRoot.vm.input().join(""));
    }
    searchRoot.vm.input([]); 
  },
  onkeypress: function(event) {
    switch(event.charCode) {
    case 0:
      //macbook support
      searchRoot.vm.onenter();
      break;
    case 13: 
      searchRoot.vm.onenter();
      break;
    case 27: searchRoot.vm.input([]); break;
    default: searchRoot.vm.input().push(String.fromCharCode(event.charCode));
    }
  },
  
  submitScan: function(req) {
    global.autobahn.sync({event:"search", query: req, sessionId: global.autobahn.sessionId, search: "sid-by-ident"}).then(function(data) {
      if(data.data !== undefined) {
        //we got a functional response
        if(data.data.length === 1) {
          //here false means to remove the old stuff
          search.data = data.data;
          searchRoot.vm.checkDigitInput.reset();
          searchRoot.vm.recalcHint();
        } else if(data.data.length > 1) {
          searchRoot.vm.checkDigitInput.reset();
          searchRoot.vm.subtitle("LID contains more than one SID");
        } else {
          searchRoot.vm.checkDigitInput.reset();
          searchRoot.vm.subtitle("SID or LID unknown");
        }
      } else {
        searchRoot.vm.checkDigitInput.reset();
        searchRoot.vm.subtitle("SID or LID unknown");
      }

      //render always
      searchFunctions.vm.enableFunctions();
      m.endComputation();
    });

  },

  onscan: function(n) {
    this.submitScan(n);
  },
  init : function() {
    if(!this.dialog) {
      this.dialog = new ModalMessageBar("search");
    }
    this.defaultSubtitle = "Key-in SID or LID checkdigit";
    this.subtitle =  m.prop(this.defaultSubtitle);
    this.oninput = function(input) {
      m.startComputation();
      var req = {"by-sid": true, "by-lid": true}
      if(this.checkDigitInput.lastInput.length > 0) {
        var lastState = this.checkDigitInput.state() === this.checkDigitInput.STATES.UP ? "checkdigit1" : "checkdigit0";
        req[lastState] = this.checkDigitInput.lastInput.join("");
      }
      var currentState = this.checkDigitInput.state() === this.checkDigitInput.STATES.UP ? "checkdigit0" : "checkdigit1";
      req[currentState] = input;
      global.autobahn.sync({event:"search", query: req, sessionId: global.autobahn.sessionId, search: "checkdigit-to-sid"}).then(function(data) {
        //reset data model
        search.data = [];

        if(data.data !== undefined) {
          //we got a functional response
          if(data.data.data !== undefined) {
            if(data.data.data.length === 1) {
              //here false means to remove the old stuff
              search.data = data.data.data;
              searchRoot.vm.checkDigitInput.reset();
              searchRoot.vm.recalcHint();
            } else if(data.data.data.length > 1) {
              searchRoot.vm.checkDigitInput.switchState();
            } else {
              searchRoot.vm.checkDigitInput.reset();
              searchRoot.vm.subtitle("SID or LID unknown");
            }
          }
        }

        //render always
        searchFunctions.vm.enableFunctions();
        m.endComputation();

      });
    };
    this.recalcHint = function() {
      if(searchRoot.vm.checkDigitInput.input.length == 0 && searchRoot.vm.checkDigitInput.lastInput.length == 0) {
        this.subtitle(this.defaultSubtitle);
        return;

      }

      var xs = new LRStringBuffer();
      if(this.checkDigitInput.lastInput.length>0) {
        xs.append("Checkdigit ").append(this.checkDigitInput.lastInput.join("")).append(" is not unique. ");
      }
      if(this.checkDigitInput.input.length == 0) {
        xs.append("Key-in other checkdigit on card.");
      } else {
        xs.append("You keyed in ").append(this.checkDigitInput.input.join(""));
      }
      this.subtitle(xs.toString());
    }
    this.hint = function(showHint) {
      if(showHint) {
        this.recalcHint();
      } else {
        this.subtitle(this.defaultSubtitle);
      }

      searchFunctions.vm.functions.enable("cancel", showHint);
      
    };
    this.checkDigitInput = new MobileCheckDigitInput({oninput: this.oninput.bind(this),
                                                      hint: this.hint.bind(this)});

    //this is done just the first time 
    onscanCallback(this.onscan.bind(this));
    onkeypressCallback(this.onkeypress.bind(this));

  },
  onload: function() {
    onscanCallback(this.onscan.bind(this));
    onkeypressCallback(this.onkeypress.bind(this));
    this.checkDigitInput.reset();
    if(!this.dialog) {
      this.dialog = new ModalMessageBar("search");
    } else {
      //get in a new queue
      this.dialog.reset();
    }
  }
}


searchFunctions.vm = {
  trash: function() {
    m.startComputation();
    var data = [{key: search.data[0][0], coll: search.data[0][1].coll }];
    
    searchRoot.vm.dialog.show({severity: ModalMessageSeverity.WARNING, 
                               message: (data.length > 1 ? "The selected SIDs will be deleted. Are you sure?" : "This SID will be deleted. Are you sure?"),
                               title: "Are you sure?",
                               okLabel: "Delete",
                               onCancel: function(callback) {
                                 m.endComputation();
                                 callback();
                               },
                               onOk: function(callback) {
                                 global.autobahn.sync({event:"card", data: data, sessionId: global.autobahn.sessionId, fn: "delete"}).then(function(data) {
                                   search.data = [];
                                   searchFunctions.vm.enableFunctions();
                                   m.endComputation();
                                   callback();
                                 })
                                   .catch(function(msg) {
                                     console.log(msg);
                                     m.endComputation();
                                     callback();
                                   });

                               }});
  },

  init: function() {
    searchFunctions.vm.functions = new FunctionPanel(

      {cancel:{imageClass: "glyphicon-remove", tooltip: "Cancel last checkdigit input",
               onclick: function() {
                 searchRoot.vm.checkDigitInput.onreset();
                 searchRoot.vm.recalcHint();
               }, enabled: false},
       xfer: {imageClass: "glyphicon-fullscreen", tooltip: "Transfer stock",
              onclick: function() {
                if(search.data.length === 1) {
                  xfer.data = search.data;
                  route("/xfer", xferRoot);
                }
              }, enabled: (search.data.length == 1)},
       trash: {imageClass: "glyphicon-trash", tooltip: "Delete card",
               onclick: (function() {
                 if(search.data.length === 1) {
                   this.trash();
                 }
               }).bind(this), enabled: (search.data.length == 1)}
      });
  },
  enableFunctions: function() {
    ["trash", "xfer"].map(function(n) {
      searchFunctions.vm.functions.enable(n, search.data.length == 1);
    });
    searchFunctions.vm.functions.enable("cancel", searchRoot.vm.checkDigitInput.input.length > 0 || searchRoot.vm.checkDigitInput.lastInput.length > 0);
  }
};

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
search.controller =  function() {
}
search.view = function(ctrl) {
  return m.component(MobileSmallSid, {model: search.data.length == 1 ? search.data[0] : undefined});
}

searchFunctions.controller = function() {
  searchFunctions.vm.init();
};
searchFunctions.view = function(ctrl) {
  return searchFunctions.vm.functions.view(ctrl);
}

searchRoot.controller = function() {
  searchRoot.vm.init();
  return {
    searchFunctions : submodule(searchFunctions),
    search: submodule(search),
    checkDigitInput : submodule(checkDigitInput),

    onunload: function() {
      searchRoot.vm.onunload();
    }
  }
}

searchRoot.onload = function() {
  searchRoot.vm.onload();
}

searchRoot.view = function(ctrl) {
  var maxDim = Math.min(window.innerHeight * 0.35, window.innerWidth * 0.75 - 10);
  maxDim = maxDim * 1;
  var r = maxDim / 2;
  var cx = window.innerWidth / 2;
  var left = cx - r;
  var top = window.innerHeight * 0.65;
  var style = new LRStringBuffer();
  style = style.append("left: ").append(left + "px").append("; top:").append(top + "px;")
    .append("; width: ").append(maxDim + "px").append("; height: ").append(maxDim + "px;")
    .toString(); 


  return [m("div[class=spaHeader]", [
    m("div[class=title]","Identify SID"),
    m("div[class=subtitle]",searchRoot.vm.subtitle())]),
          m("div[class=spaFunctions]", ctrl.searchFunctions()),
          m("div[class=spaNorth]",{id:"spaNorth"}, ctrl.search()),
          m("div[class=spaSouth]", {id:"spaSouth", style: style}, searchRoot.vm.checkDigitInput.view())]
}
