//SID Edit Process, Transfer

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state
/////////////////////////////////////////////////////
var sideditRoot = {
  data: [],
  editField: undefined
}
var sideditFunctions = {}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////
sideditFunctions.vm = {
  init: function() {
    sideditFunctions.vm.functions = new FunctionPanel(
      {home: {imageClass: "glyphicon glyphicon-home", tooltip: "Back to search", onclick: function() {
        route("/search", searchRoot);
      }, enabled: true}});
  }
}

sideditRoot.vm = {
  responseQueue : d3_queue.queue(1),
  
  nonJsonErrors: function(xhr) {
    return xhr.status > 200 ? JSON.stringify(xhr.responseText) : xhr.responseText
  },

  onedit: function(edit, path, attr, cancel) {
    //so we are interested when the user finishs edit (edit=false) and does not cancel the input (cancel=false) and in atomic vals (path = [])
    if(!edit && !cancel && path.length == 0) {
      //but we have to check whether the value changed
      var newval = sideditRoot.vm.bigsid.docPath(path, attr);
      if(sideditRoot.vm.bigsid.shadow() != newval) {
        console.log(edit + " " + path + " " + attr);
        var data = {keys: sideditRoot.data.map(function(n) {return n[0]}),
                    keyvals: [attr, newval]};
        
        global.autobahn.sync({event:"card", data: data, sessionId: global.autobahn.sessionId, fn: "alter-sids"}).then(function(data) {
          console.log("then " + data);
        }).catch(function(msg) {
          console.log("catch " + msg);
        });

      }
    }
  },

  init: function() {
      this.bigsid = new BigSID(sideditRoot.data[0], {
        editMode: true,
        onedit: this.onedit.bind(this)
      //oninput: sideditProcess.vm.oninput.bind(sideditProcess.vm),
      //onsubmit: sideditProcess.vm.onsubmit.bind(sideditProcess.vm),
      //oncancel: sideditProcess.vm.oncancel.bind(sideditProcess.vm)
      })
  }  
}


/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
sideditFunctions.controller = function() {
  sideditFunctions.vm.init();
};
sideditFunctions.view = function(ctrl) {
  return sideditFunctions.vm.functions.view(ctrl);
}


sideditRoot.controller = function() {
  sideditRoot.vm.init();
  return {
    sideditFunctions : submodule(sideditFunctions),
    onunload: function() {
    }
  };
}

sideditRoot.view = function(ctrl) {
  return [m("div[id=spaFunctions]", ctrl.sideditFunctions()),
          m("div[id=spaLeft]", {class: "col-60"}, this.vm.bigsid.view())];
}

sideditRoot.onload = function() {
}
