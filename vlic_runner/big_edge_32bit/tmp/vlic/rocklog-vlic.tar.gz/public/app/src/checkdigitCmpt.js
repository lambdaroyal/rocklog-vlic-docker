var onscanCallback = m.prop();

var onscan = function(data){
        if(onscanCallback()) {
          (onscanCallback())(data);
        }
}

var onkeypressCallback = m.prop();

document.onkeypress =  function(n) {
  if(onkeypressCallback()) {
    console.log("press " + n.charCode);
    (onkeypressCallback())(n);
  }
}

var MobileCheckDigitInput = function(options) {
  this.STATES = Object.freeze(
    {"UP": [1,2,3,4],
     "DOWN": [5,6,7,8]});
  //covers the input so far
  this.input = [];
  this.lastInput = [];
  this.state = m.prop(this.STATES.UP);
  this.collapseTimer = m.prop(undefined);

  var settings = {
    /** log debug messages. */
    debug: true,
    /** true denotes that the control starts colapsed to 25%, when moving the mouse over, the thingy gets expanded, after finite time without moving the pointer in the thing gets colapsed again*/
    autoCollapse: false,
    collapsedRatio: 0.50,
    fontSize: 2.5,
    id: "checkDigitInput",
    oninput: function(input){},
    hint: function(showHint){}
  }
  if (!options) { options = {}; }

  // Overwrite and define settings with options if they exist.
  for (var key in settings) {
    if (typeof options[key] !== 'undefined') {
      this[key] = options[key];
    } else {
      this[key] = settings[key];
    }
  }

  this.collapsed = m.prop(this.autoCollapse);

  this.reset = function() {
    this.input = [];
    this.lastInput = [];
    this.state = m.prop(this.STATES.UP);    
  }

  this.switchState = function() {
    this.state(this.state() === this.STATES.UP ? this.STATES.DOWN : this.STATES.UP);
    this.hint(true); 
  }


  this.onreset = function() {
    if(this.input.length == 0) {
      //reset to initial state
      this.lastInput = [];
      this.state(this.state() === this.STATES.UP ? this.STATES.DOWN : this.STATES.UP);
    } else {
      //just reset current input
      this.input = [];
    }

    if(this.lastInput.length == 0) {
      this.hint(false);
    }
  }

  this.onclick = function(text) {
    text = this.state()[text];
    this.input.push(text);
    if(this.input.length == 4) {
      if(this.oninput) {
        this.oninput(this.input.join(""));
      }
      this.lastInput = this.input.map(function(n) {return n;});
      this.input = [];
    } else {
      this.hint(true);
    }
  };
  this.expand = function() {
    if(this.collapsed()) {
      var tween = function() { return d3.interpolate("50%", "100%"); } 

      d3.select("#" + this.id).transition().duration(300).styleTween("width", tween).styleTween("height", tween);
      this.collapsed(false);
    }
  }

  this.collapse = function() {
    if(!this.collapsed()) {
      var tween = function() { return d3.interpolate("100%", "50%"); } 

      d3.select("#" + this.id).transition().duration(300).styleTween("width", tween).styleTween("height", tween);

      this.collapsed(true);
    }

  }


  this.startCollapseTimer = function() {
    if(this.autoCollapse) {
      if(!this.collapsed() && this.collapseTimer() === undefined) {
        this.collapseTimer(window.setTimeout(this.collapse.bind(this),3000));
      }
    }
  }

  this.cancelCollapseTimer = function() {
    if(this.autoCollapse) {
      if(this.collapseTimer()) {
        window.clearTimeout(this.collapseTimer());
        this.collapseTimer(undefined);
      }
    }
  }

  this.onmouseover = function() {
    if(this.autoCollapse) {
      this.cancelCollapseTimer();
      if(this.collapsed()) {
        this.expand();
      }
    }
  }

  this.view = function() {
    var event = "onclick";
    if(isApfel) {
      event = "ontouchstart";
    }

    var sizes = [100,this.fontSize];
    sizes = sizes.map((function(x) {
      return x * (this.collapsed() ? this.collapsedRatio : 1);
    }).bind(this));
    var xs = [0,1,3,2].map((function(n) {
      var styles = (new LRStringBuffer()).append("font-size: ").append("" + this.fontSize).append("em").toString();

      var attr = {style: styles, class: ("btn btn-function checkDigit" + this.state()[n])};
      attr[event] = this.onclick.bind(this, n);
      return m("div", attr, [m("div", this.state()[n])]);
    }).bind(this));
    var styles = (new LRStringBuffer()).append("width: ").append("" + sizes[0]).append("%; height: ").append("" + sizes[0]).append("%;").toString();
    return m("div.checkDigitInput", {id: this.id, style: styles, onmouseover: this.onmouseover.bind(this), onmouseout: this.startCollapseTimer.bind(this)}, xs);
  }

  return this;
}
