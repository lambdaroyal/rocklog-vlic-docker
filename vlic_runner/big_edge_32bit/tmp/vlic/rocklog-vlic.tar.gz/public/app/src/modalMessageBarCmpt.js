var ModalMessageSeverity = Object.freeze ({ "ERROR": "ERROR",
                                            "WARNING": "WARNING"});

var ModalMessageBar = function(id) {
  //fail fast - check whether another component still occupies the anker

  var $ = {
    id: id || "undef",
    queue: d3_queue.queue(1),
    abort: function() {
      this.queue.abort();
    },
    reset: function() {
      this.queue = d3_queue.queue(1);
    },
    render: function(args, callback) {
      var modalAnchor = document.getElementById("modalAnchor");

      var anchor = d3.select(modalAnchor).append("div")
        .attr("class", "modalMessageBarContainer")
        .attr("id", id || "undef")

      var container = 
        anchor.append("div").attr("class", "modalMessageBar")
        .append("div").attr("class","container");
      //milky glass
      anchor.append("div").attr("class", "milkyGlass");
      //title
      container.append("div")
        .attr("class", "titleContainer")
        .append("span").text(args.title);

      //message
      container.append("div")
        .attr("class", "messageContainer")
        .append("span").text(args.message);

      //button bar
      var xs = [];
      if(args.onCancel) {
        xs.push({class: "btn btk-lg btn-danger", text: "Cancel", onclick: args.onCancel.bind(this, callback), id: "cancel"});
      }
      if(args.onOk) {
        xs.push({class: "btn btk-lg btn-success", text: args.okLabel, onclick: args.onOk.bind(this, callback), id: "ok"});
      } else if(args.onConfirm) {
        xs.push({class: "btn btk-lg btn-success", text: "Confirm", onclick: args.onConfirm.bind(this, callback), id: "confirm"});
      }

      var buttonContainer = container.append("div")
        .attr("class", "buttonContainer");
      buttonContainer.selectAll("button").data(xs)
        .enter().append("button")
        .attr("type", "button")
        .attr("class", function(n) {
          return n.class;
        })
        .text(function(n) {
          return n.text;
        });
      buttonContainer.selectAll("button").each(function(n) {
        return this.onclick = n.onclick;
      });

      if(this.afterRenderCallback) {
        this.afterRenderCallback(callback);
      }
    },
    hide: function(callback) {
      d3.selectAll("div.modalMessageBarContainer").remove();
      callback();
    },

    show(args) {
      args = args || {};
      var settings = {
        severity: ModalMessageSeverity.ERROR,
        title: "",
        message: "",
        //all those function must accept a callback that is finally to be called without argument in order to close the message and to continue waiting for the next message to be shown (if any)
        okLabel: "Ok",
        onOk: undefined,
        onCancel: undefined,
        onConfirm: undefined,
        //provide this for if no button is present but the dialog must be disposes properly within some button, the fn must accept and call the provided callback
        afterRenderCallback: undefined
      }

      // Overwrite and define settings with options if they exist.
      for (var key in settings) {
        if (typeof args[key] === 'undefined') {
          args[key] = settings[key];
        }
      }

      //finally queue a lambda that displays the message and waits for the callback
      this.queue.defer(this.render.bind(this,args));
      //... as well as a lambda that hides the panel after the user pressed something
      this.queue.defer(this.hide.bind(this));
    },

    //use this function as well in mithril cpmt unload phase, this removes the dialog if present
    abort: function() {
      d3.selectAll("div.modalMessageBarContainer#" + this.id).remove();
      this.queue.abort();
    }
  }

  return $;
}

