var MobileSmallSid = {
  id: function(model) {
    return new LRStringBuffer()
      .append(model[1].coll)
      .append('_')
      .append(model[0])
      .toString()
  },

  tuneModel: function(model) {
    if(model[1]._amountHistory === undefined) {
      model[1]._amountHistory = [model[1].amount];
      if(model[1].origAmount && model[1].origAmount > model[1].amount) {
        model[1]._amountHistory.push(model[1].origAmount - model[1].amount);
        model[1]._amountRatio = (model[1].amount / model[1].origAmount * 100).toFixed(0);
      }
    }
  },
  
  renderLocation : function(model) {
    //fail fast
    if(!model[1].location)
      return "-";
    if(!model[1].location[0])
      return "-";
    if(!global.rampup.cardmeta.location)
      return "n/a";
    var res = global.rampup.cardmeta.location[1]["ui-trim"].reduce(function(acc,x,index) {
      var key = x[0];
      var val = model[1].location[1][key];
      if(val) {
        if(index > 0) {
          acc.append("-");
        }
        acc.append(("" + val).substring(0, x[1]));
      }
      return acc;
    }, new LRStringBuffer());
    return res.toString();
  },

  renderGroup : function(model, caption, path, attr, naText, maxLength, smallCss) {
    var val = "";
    if(typeof path === "function") {
      val = path.call(this, model);
    } else {
      val = docPath(model, path, attr, naText);
    }
    if(val.length > maxLength) {
      val = val.substring(0, maxLength) + "..";
    }
    return <div class="group col-50">
      <div class="smallCap">{caption}</div>
      <div class={smallCss !== undefined ? smallCss : "small"}>{val}</div>
      </div>
  },

  renderReservedAmountPie : function(pie, model) {
    if(model[1]._reservedAmount || model[1].reservedAmount) {
      var width = 45,
          height = 45,
          radius = Math.min(width, height) / 2;

      var arc2 = d3.svg.arc()
          .innerRadius(radius)
          .outerRadius(radius - 5);
      var orig = model[1].origAmount || model[1].amount;
      var div = model[1]._reservedAmount || model[1].reservedAmount;
      return pie([(div / orig * 100).toFixed(0),
                  ((orig - div) / orig * 100).toFixed(0)]).map(function(x,i) {           
        return <path class={i === 0 ? "checkThis" : "none"} d={arc2(x)}/>
      });
    } else {
      return undefined;
    }
  },

  renderInitialAmount: function(model) {
    var x = model[1].origAmount || model[1].amount;
    if(x === undefined) {
      x = "";
    }

    if(x > 1000000) {
      return <div class="big" style="text-align: right">{x}</div>
    } else {
      return <div class="big" style="text-align: center">{x}</div>
    }
  },

  renderCurrentAmount: function(model) {
    var orig = model[1].origAmount || model[1].amount;
    if(model[1].origAmount !== undefined && model[1].origAmount > model[1].amount) {
      var x = model[1].amount;

      if(x > 1000000) {
        return <div class="medium" style="text-align: right">{x}</div>
      } else {
        return <div class="medium" style="text-align: center">{x}</div>
      }

    } else {
      return <div class="big">{String.fromCharCode(160)}</div>      
    }
  },

  renderReservedAmount: function(model) {
    var orig = model[1].origAmount || model[1]._reservedAmount || model[1].reservedAmount;
    if(model[1]._reservedAmount !== undefined || model[1].reservedAmount) {
      var x = model[1]._reservedAmount || model[1].reservedAmount;

      if(x > 1000000) {
        return <div class="checkThis" style="text-align: right">{x}</div>
      } else {
        return <div class="checkThis" style="text-align: center">{x}</div>
      }

    } else {
      return <div class="big">{String.fromCharCode(160)}</div>      
    }
  },

  openPdf: function(pdf) {
    window.open(global.pathnamePrefix + '/printing/result?file=' + pdf);
  },

  renderFunel: function(model) {
    if(model[1].initialSidLabel !== undefined) {
      return <a data-toogle="tooltop" data-placement="top" title="Click here to open the attachment in a new tab" onclick={this.openPdf.bind(this, model[1].initialSidLabel)}><span class="glyphicons glyphicons-paperclip"></span></a>
    } else {
      return <div class="big">{String.fromCharCode(160)}</div>      
    }
  },

  renderAmount : function(model) {
    var width = 55,
        height = 55,
        radius = Math.min(width, height) / 2;

    var pie = d3.layout.pie()
        .sort(null);

    var arc = d3.svg.arc()
        .innerRadius(radius)
        .outerRadius(radius - 5);

    return <svg class="amount" width={width} height={height}>
      <g transform={"translate(" + width / 2 + "," + height / 2 + " )"}>
      {
        pie(model[1]._amountHistory).map(function(x, i) {
          return <path fill={i === 0 ? "#3e4690" : "#bcb4d6"} d={arc(x)}/>;
        })
      }
    {
      this.renderReservedAmountPie(pie, model)
    }
    </g></svg>;
  },

  view: function(ctrl, args) {
    //scope in data model (user scope tupel)
    if(args.model == undefined || args.model.length == 0) {
      return <div style="visible: hidden"/>
    }
    var model = args.model;
    this.tuneModel(model);
    
    var xs = [{caption: "LOCATION", path: this.renderLocation},
              {caption: "CLIENT", path: ["article"], attr: "client"},
              {caption: "ITEM", path: ["article"], attr: "ident"},
              {caption: "DESCRIPTION", path: ["article"], attr: "description"},
              {caption: "SID", path: function(d) {
                return "" + d[0];
              }},
              {caption: "INBOUND", path: [], attr: "creation-date"},
              {caption: "UNIT", path: ["article"], attr: "unit"}, 
              {caption: "BATCH", path: [], attr: "batch"}];
    
    xs = xs.map((function(x, i) {
      if(x === null) {
        //add some spacer
        return <div class="group col-50"><div class="smallCap"><span>{String.fromCharCode(160)}</span></div><div class="small-noBorder"><span>{String.fromCharCode(160)}</span></div></div>
      }
      return this.renderGroup(model, x.caption, x.path, x.attr, x.naText !== undefined ? x.naText : "n/a", x.maxLength !== undefined ? x.maxLength : 13, (i == xs.length - 1 || i == xs.length - 2) ? "small-noBorder" : "small");
    }).bind(this));

    return <div class={"card smallCard " + model[1].coll} id={this.id(model)}>
      <div class="col-66 noPadding">
      <div class="spacer"></div>
      </div>
      <div class="col-33 border-left-top-right noPadding bg">
      <div class="funel" style="text-align: center">
      {this.renderFunel(model)}
    </div>
      </div>
      <div class="border-left-bottom-right col-100 bg">
        <div class="col-66 border-top">
          <div class="col-100 padding-10"></div>
          {xs}
        </div>
        <div class="col-33">
          <div class="pixel-top-left"></div>
          <div class="col-100 padding-8"></div>
          <div class="group-noRuler">
            {this.renderInitialAmount(model)}
            {this.renderCurrentAmount(model)}
            <div style="text-align: center;">
              {this.renderAmount(model)}
            </div>
            {this.renderReservedAmount(model)}
          </div>
        </div>
      </div>
    </div>
  }

}
