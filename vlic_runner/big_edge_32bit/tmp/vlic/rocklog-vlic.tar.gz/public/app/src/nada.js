// Non-domain background view that just contains the worldmap and listens for worldmap events 

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state
/////////////////////////////////////////////////////
var nada = {};

nada.worldmapLoaded = m.prop(null);

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////

nada.vm = (function() {
  var vm = {}
  vm.mruLocations = [];

  vm.getXY = function(lat, lon) {
    return {
      cx: lon * (2.6938 * scale) + (465.4 * scale),
      cy: lat * (-2.6938 * scale) + (227.066 * scale)
    };
  };

  vm.initWorldmap = function() {
    m.request({method: "GET", url: "assets/js/worldmapData.json"}).then(function(res) {

      var worldWidth = window.innerWidth - 20,
          mapRatio = 0.4,
          worldHeight = worldWidth * mapRatio;
      scale = worldWidth / 1000;
      //adjust worldmap div
      var div = document.getElementById("worldmapDiv");
      div.style.top = window.innerHeight / 2.0 - worldHeight / 2.0 + "px"; 

      var paper = Raphael(document.getElementById("worldmap"), worldWidth, worldHeight);
      paper.rect(0, 0, worldWidth, worldHeight, 10).attr({
        stroke: "none",
        id: "worldmapSvg"
      });
      paper.setStart();
      for (var country in res.shapes) {
        paper.path(res.shapes[country]).attr({
          'stroke': '#FFFFFF',
          'stroke-width': 0.5,
          'stroke-opacity': 0.15,
          fill: "#fdfdfd",
          "fill-opacity": 1
        }).transform("s" + scale + "," + scale + " 0,0");
      }
      var world = paper.setFinish();
      world.getXY = vm.getXY;
    }); 
  }

  vm.renderLocationEvents = function() {
    if(vm.mruLocations.length > 0) {

      var i = 0;
      var p = d3.select("svg").selectAll("circle").data(vm.mruLocations).enter().
          append("circle", "rect")
          .attr("cx", function(d) {
            return d.cx;
          })
          .attr("cy", function(d) {
            return d.cy;
          })
          .attr("r", 1e-6)
          .style("stroke", d3.hsl((i = (i + 1) % 360), 1, .5))
          .style("stroke-opacity", 1)
          .transition()
          .duration(1000)
          .ease(Math.sqrt)
          .attr("r", 50)
          .style("stroke-opacity", 1e-6)
          .remove()
      vm.mruLocations = [];
    }
  }

  vm.init = function() {

    //lift this by buffer . throttle to have just some events in time that can be processed at once
    setInterval(vm.renderLocationEvents.bind(nada), 350);

    //subscribe worldmap events from server
    nada.vm.worldmapSub = global.autobahn.sub(global.TOPICS.worldmap, function(data) {
      if(!login.Session.id) {
        //console.log("received message on topic worldmap: " + JSON.stringify(data) + " coord" + vm.getXY(data.latitude, data.longitude));
        nada.vm.mruLocations.push(vm.getXY(data.latitude, data.longitude));
      }
    });


    if(!nada.worldmapLoaded()) {
      nada.worldmapLoaded(true);
      d3_queue.queue().defer(function(callback) {
        nada.vm.initWorldmap();
        callback();
      });
    }
  }
  return vm;
}());

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
nada.controller = function() {
  nada.vm.init();
}

//here's the view
nada.view = function() {
  return null;
};
