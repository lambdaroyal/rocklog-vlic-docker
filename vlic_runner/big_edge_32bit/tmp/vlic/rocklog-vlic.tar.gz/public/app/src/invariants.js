//Invariants - Contains invariant stuff like autobahn
//stat components as well as logout button and
//user name component

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state,
// this gets scoped without regard to the controller
// so this won't die if the user steps out of a
// mithril modul that gets unmounted
/////////////////////////////////////////////////////

var invariants = {
  //promise resolve callback invoked within config in render phase
  //in layman terms this resolves the promise returned by mount function
  onMount: undefined
}
var autobahnState = function(autobahn) {
  if(autobahn) {
  switch(autobahn.state()) {
    case(autobahn.States.OUTOFSERVICE): return {caption:"out of service", css:"outofservice"};
    case(autobahn.States.CLOSED): return {caption:"offline", css:"offline"};
    case(autobahn.States.OPEN): return {caption:"online", css:"online"};
  }} else {
    return {caption: "offline", css: "offline"}
  }
}

/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////
var AutobahnComp = {
  view: function(ctrl, args) {
    var autobahn = global.autobahn;
    return <div class="btn btn-default btn-lg btn-function autobahn" data-toggle="tooltip" data-placement="top" title="Connection status">
      <div id="autobahnState" class={autobahnState(autobahn).css}>{autobahnState(autobahn).caption}</div>
      <div class="autobahnRoundtripPL">
      <svg height="13" width="50">
      <path d="M3 10 Q0 10 0 5 Q 0 2 5 2 L10 2 Q20 2 20 6 Q20 10 10 10 L5 10"/>
      <path d="M5 10 L11 7 11 13 Z" style="fill: rgba(0,0,0,0.25)"/>
      <text id="autobahnState_delay" x="22" y="10">n/a</text>
      </svg>
      </div>
      </div>
  },

  setDelay: function(delay) {
    d3.select("#autobahnState_delay").text(delay);
  },

  setState: function() {
    var state = autobahnState(global.autobahn)
    d3.select("#autobahnState")
      .attr("class", state.css)
      .text(state.caption);
  }
}

invariants.vm = {
  autobahnGlobalStateSub: function(state) {
    AutobahnComp.setState();
  },

  //is called as post-fn after render phase of the components
  //this initializes the autobahn if not yet done
  onload: function(element, isInitialized, context) {
    if(!isInitialized && !global.autobahn) {
      this.dialog = new ModalMessageBar("search");
      this.dialog.show({severity: ModalMessageSeverity.WARNING,
                        message: "Waiting for networking connection to be established.",
                        title: "Preparing your session"});

      this.initAutobahn().then(function() {
        //invoke the promise on invariants.mount()
        invariants.onMount();

        //close the dialog after 0.5s
        window.setTimeout(function() {
          invariants.vm.dialog.abort();
        }, 500);
      });;
    }
  },

  // returns a promise and initializes the loading of important master data
  // this gets called when the autobahn is ready to process
  initRampup : function() {
    if(!global.rampup) {
      global.rampup = new Rampup();
      return global.rampup.init(global.autobahn);
    } else {
      return new Promise(function(resolve, reject) {
      });
    }
  },

  initAutobahn : function() {
    return new Promise(function(resolve, reject) {
    global.pathnamePrefix = window.location.pathname.substring(0, window.location.pathname.indexOf("/static"));
    global.autobahn = new Autobahn("ws://" + window.location.host + window.location.pathname.substring(0, window.location.pathname.indexOf("/static")) + "/autobahn", 
                                   { debug: false,
                                     syncTimeout: 3000,
                                     lanes: 2,
                                     stateCallback: function(state) {

                                       this.mbus.pub(global.TOPICS.AUTOBAHN_STATE_TRANSITION, state);
                                       if(state == global.autobahn.States.OPEN) {
                                         invariants.vm.initRampup().then(function(){ 
                                           invariants.vm.postInitAutobahn();
                                           resolve() 
                                         });
                                       }
                                     },
                                     statsOnSyncResponse : function(ws, delay) {
                                       if(delay) {
                                         console.log("received sync resp after (ms) " + delay + " on ws " + ws.lane);
                                       } else {
                                         console.log("received sync resp after TIMEOUT on ws " + ws.lane);
                                       }
                                     }
                                   });
    global.autobahn.mbus.sub(global.TOPICS.AUTOBAHN_STATE_TRANSITION, invariants.vm.autobahnGlobalStateSub);

      });


  },

  postInitAutobahn: function() {
    //subscribe server state events from server
    global.autobahn.sub(global.TOPICS.ping, function(data) {
      global.autobahn.async(global.TOPICS.ping, data.ts);
    });

    global.autobahn.sub(global.TOPICS.pong, function(data) {
      AutobahnComp.setDelay(data.delay+"ms")
    });

    //subscribe printing events
    global.autobahn.sub(global.TOPICS.printresult, function(data) {
      if(data.file) {
        window.open(global.pathnamePrefix + '/printing/result?file=' + data.file);
      }
    });
  },

  exit: function() {
    
  },

  init: function() {
    invariants.vm.functions = new FunctionPanel(

      {logout: {imageClass: "glyphicon-log-out", tooltip: "Logout",
                onclick: function() {
                  login.Session.destroy();
                  route("/", login);
                }, enabled: false
               }});
  }
}


/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
invariants.controller = function() {
  invariants.vm.init();
}

invariants.view = function(ctrl) {
  return m("div", {config: invariants.vm.onload.bind(invariants.vm)}, [invariants.vm.functions.view(ctrl), m.component(AutobahnComp)]);
}

invariants.mount = function() {
  return new Promise(function(resolve, reject) {
    invariants.onMount = resolve; 
    m.mount(document.getElementById("spaInvariants"), {controller: invariants.controller, view: invariants.view});
  });
}
