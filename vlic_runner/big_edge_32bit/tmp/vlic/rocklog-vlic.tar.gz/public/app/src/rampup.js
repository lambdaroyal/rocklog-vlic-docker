// The ramp-up is a non-ui module, that slurpes in some data from the server asynchronously that used later by various processes
// use this module to slurp data, to subscribe to data publishions that are independent of a certain ui modul

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state
/////////////////////////////////////////////////////
var Rampup = function() {
  $ = {cardmeta:{}, numberranges: m.prop(), onlinestats: m.prop()};

  $.getCardmeta = function(autobahn) {
    return new Promise(function(resolve, reject) {
      //gettin cardmeta
      if(!$.cardmeta.location) {
        autobahn.sync({event:"search", query: "location", sessionId: autobahn.sessionId, search: "cardmeta"}).then(function(data) {
          $.cardmeta.location = data.data;
          resolve($.cardmeta.location);
        }).catch(function(msg) {
          reject(msg);
        });;
      } else {
        resolve($.cardmeta.location);
      }
    })}

  $.getNumberranges = function(autobahn) {
    return new Promise(function(resolve, reject) {
      if(!$.numberranges()) {
        autobahn.sync({event:"search", query: "",  sessionId: autobahn.sessionId, search: "numberrange"}).then(function(data) {
          $.numberranges(data.data);
          resolve($.numberranges);
        }).catch(function(msg) {
          reject(msg);
        });

        //observing server-side number range events
        autobahn.sub(global.TOPICS.numberrange, (function(data) {
          //update model
          var nrange = this.numberranges() ? this.numberranges().find(function(n) {
            return n[0] == data.data[0];
          }) : undefined;
          if(nrange) {
            if(data.data[1].running > nrange[1].running) {
              //check whether incomming data is never
              nrange[1] = data.data[1];
              //notify client components
              autobahn.mbus.pub(global.TOPICS.numberrangeFollow, nrange);
            }else {
              //mhm, new one, least likely
              this.numberranges().push(data.data);
            }


          }}).bind($));

      } else {
        resolve($.numberranges);
      }
    })};

  $.getOnlinestats = function(autobahn) {
    return new Promise(function(resolve, reject) {
      if(!$.onlinestats()) {
        autobahn.sync({event: "search", search:"onlinestats", sessionId: autobahn.sessionId}).then(function(data) {
          $.onlinestats(data.data);
          //observing server-side number range events
          autobahn.sub(global.TOPICS.onlinestats, (function(data) {
            if(data.data) {
              this.onlinestats()[data.data[0]] = data.data[1];
              //notify client components
              autobahn.mbus.pub(global.TOPICS.onlinestatsFollow, data.data);
            }}).bind($));
          resolve($.onlinestats);
        }).catch(function(msg) {
          reject(msg);
        })
          } else {
            resolve($.onlinestats);
          }
    });
  };

  $.init = function(autobahn) {
    return new Promise(function(resolve, reject) {
      $.getCardmeta(autobahn).then(function() {
        $.getNumberranges(autobahn).then(function() {
          $.getOnlinestats(autobahn).then(function() {
            resolve();
          }). catch(function(msg) {
            reject(msg);
          }).catch(function(msg) {
            reject(msg);
          })
            }).catch(function(msg) {
              reject(msg);
            });
      })})};

  return $;
  
}
