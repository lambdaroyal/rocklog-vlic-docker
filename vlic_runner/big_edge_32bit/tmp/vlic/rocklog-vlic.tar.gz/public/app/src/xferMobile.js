//XFER Process - This is a aggregating process that comes with function menu on the left,
//and a search on the right initially taking all space up

/////////////////////////////////////////////////////
// Domain Model related state and functions
// called often in order to mutate this state,
// this gets scoped without regard to the controller
// so this won't die if the user steps out of a
// mithril modul that gets unmounted
/////////////////////////////////////////////////////

var xferRoot = {}
var xferFunctions = {}
var xfer = {data: []}


/////////////////////////////////////////////////////
// View Model related state and functions
// called often in order to mutate this state
// aggregates the domain model
/////////////////////////////////////////////////////

xferRoot.vm = {
  input: m.prop([]),
  onenter: function() {
      if(xferRoot.vm.input().length > 0) {
        xferRoot.vm.submitScan(xferRoot.vm.input().join(""));
      }
      xferRoot.vm.input([]);
  },
  onkeypress: function(event) {
    switch(event.charCode) {
    case 0:
      xferRoot.vm.onenter();
      break;
    case 13: 
      xferRoot.vm.onenter();
      break;
    case 27: xferRoot.vm.input([]); break;
    default: xferRoot.vm.input().push(String.fromCharCode(event.charCode));
    }},

  submitScan: function(req) {
    global.autobahn.sync({event:"search", query: req, sessionId: global.autobahn.sessionId, search: "lid-by-ident"}).then(function(data) {
        if(data.data !== undefined) {
          //we got a functional response
            if(data.data.length === 1) {
              xferRoot.vm.xfer(data.data[0]);
            } else if(data.data.length > 1) {
              xferRoot.vm.checkDigitInput.reset();
              xferRoot.vm.subtitle("LID not unique");
            } else {
              xferRoot.vm.checkDigitInput.reset();
              xferRoot.vm.subtitle("LID unknown");
            }
        } else {
          xferRoot.vm.checkDigitInput.reset();
          xferRoot.vm.subtitle("LID unknown");
        }

        m.endComputation();
      });

  },

  onscan: function(n) {
    this.submitScan(n);
  },

  xfer: function(lid) {
    //we got a unique location
    global.autobahn.sync({event:"xfer", fn:"drop-single", data: {sid: xfer.data[0][0], lid: lid[0]}}).then(function(data) {
      if(data.data) {
        //jump back to search with the updated card
        search.data = [data.data];
        route("/search", searchRoot);
      } else {
        m.startComputation();
        xferRoot.vm.checkDigitInput.reset();
        xferRoot.vm.hint(false);
        xferRoot.vm.subtitle("Transfer failed. Location occupied.");
        m.endComputation();
      }
    }).catch(function(msg) { 
      console.log(msg)
    });
  },

  init : function() {
    this.defaultSubtitle = "Key-in LID checkdigit";
    this.subtitle =  m.prop(this.defaultSubtitle);
    this.oninput = function(input) {
      m.startComputation();
      var req = {"by-sid": true, "by-lid": true}
      if(this.checkDigitInput.lastInput.length > 0) {
        var lastState = this.checkDigitInput.state() === this.checkDigitInput.STATES.UP ? "checkdigit1" : "checkdigit0";
        req[lastState] = this.checkDigitInput.lastInput.join("");
      }
      var currentState = this.checkDigitInput.state() === this.checkDigitInput.STATES.UP ? "checkdigit0" : "checkdigit1";
      req[currentState] = input;
      global.autobahn.sync({event:"search", query: req, sessionId: global.autobahn.sessionId, search: "checkdigit-to-lid"}).then(function(data) {
        if(data.data !== undefined) {
          //we got a functional response
          if(data.data.data !== undefined) {
            if(data.data.data.length === 1) {
              xferRoot.vm.xfer(data.data.data[0]);
            } else if(data.data.data.length > 1) {
              xferRoot.vm.checkDigitInput.switchState();
            } else {
              xferRoot.vm.checkDigitInput.reset();
              xferRoot.vm.subtitle("LID unknown");
            }
          }
        }
        m.endComputation();

      });
    };
    this.recalcHint = function() {
      if(xferRoot.vm.checkDigitInput.input.length == 0 && xferRoot.vm.checkDigitInput.lastInput.length == 0) {
        this.subtitle(this.defaultSubtitle);
        return;

      }

      var xs = new LRStringBuffer();
      if(this.checkDigitInput.lastInput.length>0) {
        xs.append("Checkdigit ").append(this.checkDigitInput.lastInput.join("")).append(" is not unique. ");
      }
      if(this.checkDigitInput.input.length == 0) {
        xs.append("Key-in other checkdigit on card.");
      } else {
        xs.append("You keyed in ").append(this.checkDigitInput.input.join(""));
      }
      this.subtitle(xs.toString());
    }
    this.hint = function(showHint) {
      if(showHint) {
        this.recalcHint();
      } else {
        this.subtitle(this.defaultSubtitle);
      }

      xferFunctions.vm.functions.enable("cancel", showHint);
      
    };
    this.checkDigitInput = new MobileCheckDigitInput({oninput: this.oninput.bind(this),
                                                      hint: this.hint.bind(this)});

  },
  onload: function() {
    onscanCallback(this.onscan.bind(this));
    onkeypressCallback(this.onkeypress.bind(this));
    this.checkDigitInput.reset();
  }
}


xfer.vm = {
}

xferFunctions.vm = {
  init: function() {
    xferFunctions.vm.functions = new FunctionPanel(
      {cancel:{imageClass: "glyphicon-remove", tooltip: "Cancel last checkdigit input",
              onclick: function() {
                xferRoot.vm.checkDigitInput.onreset();
                xferRoot.vm.recalcHint();
              }, enabled: false},
        home: {imageClass: "glyphicon glyphicon-home", tooltip: "Back to search", onclick: function(){route("/search", searchRoot)}, enabled: true}});
  }
};

/////////////////////////////////////////////////////
// Controller scopes things together and is glue
// between view and model. Contains functions
// that are called once during initialization.
// interface to the outer world if view or view model
// consume something from abroad
/////////////////////////////////////////////////////
xfer.controller =  function() {
}
xfer.view = function(ctrl) {
  return m.component(MobileSmallSid, {model: xfer.data.length == 1 ? xfer.data[0] : undefined});
}

xferFunctions.controller = function() {
  xferFunctions.vm.init();
};
xferFunctions.view = function(ctrl) {
  return xferFunctions.vm.functions.view(ctrl);
}
 
xferRoot.controller = function() {
  xferRoot.vm.init();
  return {
    xferFunctions : submodule(xferFunctions),
    xfer: submodule(xfer),
    checkDigitInput : submodule(checkDigitInput),
  }
}

xferRoot.onload = function() {
  xferRoot.vm.onload();
};

xferRoot.view = function(ctrl) {
  var maxDim = Math.min(window.innerHeight * 0.35, window.innerWidth * 0.75 - 10);
  maxDim = maxDim * 1;
  var r = maxDim / 2;
  var cx = window.innerWidth / 2;
  var left = cx - r;
  var top = window.innerHeight * 0.65;
  var style = new LRStringBuffer();

  style = style.append("left: ").append(left + "px").append("; top:").append(top + "px;")
    .append("; width: ").append(maxDim + "px").append("; height: ").append(maxDim + "px;")
    .toString(); 
  return [m("div[class=spaHeader]", [m("div[class=title]","Identify target location"),
                                     m("div[class=subtitle]",xferRoot.vm.subtitle())]),
          m("div[class=spaFunctions]", ctrl.xferFunctions()),
          m("div[class=spaNorth]",{id:"spaNorth"}, ctrl.xfer()),
          m("div[class=spaSouth]", {style: style}, xferRoot.vm.checkDigitInput)]
}
