 //Cross Cutting Concerns for UI


var route = (function(){
  var q = d3_queue.queue(1);
  return function(target, module) {
    m.startComputation();
    
    if(module.beforeLoad) {
      q.defer(function(callback) {
        module.beforeLoad.call(module);
        callback();
      });
    }
    q.defer(function(callback) {
      m.route(target);
      m.endComputation();
      callback();
    });

    if(module.onload) {
      q.defer(function(callback) {
        setTimeout(function() {
          module.onload.call(module);
          callback();
        }, 150);
      });
    }
  }
})();

/////////////////////////////////////////////////////
// Check Digit Input Component
/////////////////////////////////////////////////////

//Component Renderer

var CheckDigitInput = {
  /** push in the entire component (checkDigitInput) as args*/
  view: function(ctrl, args) {
    return <div class="checkDigitInput">
      <div class={"btn btn-default btn-lg btn-function checkDigit" + args.vm.state()[0]} onclick={args.vm.onclick.bind(args.vm, 0)}><div>{args.vm.state()[0]}</div></div>
      <div class={"btn btn-default btn-lg btn-function checkDigit" + args.vm.state()[1]} onclick={args.vm.onclick.bind(args.vm, 1)}><div>{args.vm.state()[1]}</div></div>
      <div class={"btn btn-default btn-lg btn-function checkDigit" + args.vm.state()[2]} onclick={args.vm.onclick.bind(args.vm, 2)}><div>{args.vm.state()[2]}</div></div>
      <div class={"btn btn-default btn-lg btn-function checkDigit" + args.vm.state()[3]} onclick={args.vm.onclick.bind(args.vm, 3)}><div>{args.vm.state()[3]}</div></div>
      </div>
  }
}

//model is almost empty, we just tracking ui state, so view model is ok
var checkDigitInput = {
  STATES: Object.freeze(
    {"UP": [1,2,3,4],
     "DOWN": [5,6,7,8]}),
  //covers the input so far
  input : [],
  lastInput : [],
  upperInput: [],
  lowerInput: []
}

checkDigitInput.vm = (function() {
  vm = {
    STATES: Object.freeze({"UP": checkDigitInput.STATES.UP, "DOWN":checkDigitInput.STATES.DOWN})
  };
  vm.init = function() {
    //starting with the upper check digit
    vm.state = m.prop(vm.STATES.UP);
    vm.hint = m.prop(false);
  };

  vm.reset = function() {
    vm.state = m.prop(vm.STATES.UP);
    vm.hint = m.prop(false);
    checkDigitInput.lastInput = [];
    checkDigitInput.input = [];
  };

  vm.switchState = function() {
    vm.hint(true);
    vm.state(vm.state() === vm.STATES.UP ? vm.STATES.DOWN : vm.STATES.UP);
  }

  vm.oninput = function(input) {
    vm.switchState();
  }

  vm.onclick = function(text) {
    text = vm.state()[text];
    checkDigitInput.input.push(text);
    if(checkDigitInput.input.length == 4) {
      if(vm.oninput) {
        vm.hint(false);
        vm.oninput(checkDigitInput.input.join(""));
      }
      checkDigitInput.lastInput = checkDigitInput.input.map(function(n) {return n;});
      checkDigitInput.input = [];
    } else {
      vm.hint(true);
    }

  };

  vm.onreset = function() {
    if(checkDigitInput.input.length == 0) {
      //reset to initial state
      checkDigitInput.lastInput = [];
      vm.state(vm.state() === vm.STATES.UP ? vm.STATES.DOWN : vm.STATES.UP);
    } else {
      //just reset current input
      checkDigitInput.input = [];
    }

    if(checkDigitInput.lastInput.length == 0) {
      vm.hint(false);
    }
  }
  return vm;
})();

checkDigitInput.controller = function() {
  checkDigitInput.vm.init();
};

checkDigitInput.view = function() {
  return [<div class={"btn btn-default btn-lg btn-function sprechblase " + (checkDigitInput.vm.hint() ? "visible" : "hidden")} onclick={checkDigitInput.vm.onreset.bind(checkDigitInput.vm)}>
          <span class={checkDigitInput.lastInput.length > 0 ? "" : "hidden"}>Checkdigit <span class="input">{checkDigitInput.lastInput}</span> is not unique</span><br/>
          <span class={"force " + (checkDigitInput.lastInput.length > 0 ? "" : "hidden")}>Key in the other checkdigit on the card.</span><br/>
          <span class={checkDigitInput.input.length > 0 ? "" : "hidden"}>You keyed in <span class="input">{checkDigitInput.input}</span></span><br/>
          <br/>Press this speech bubble to reset the input.</div>,
          m.component(CheckDigitInput, checkDigitInput)];
}


/////////////////////////////////////////////////////
// Function Button Panel
// - are essentially links, that can be
// enabled/disabled by id. Furthermore they can be
// decorated by a custom link listener.
// All this is wrapped up this very panel, the
// Function Button Panel, which gets initiated
// when the user is logged in
/////////////////////////////////////////////////////

//First we got some Mithril Wrappers

var FunctionComp = {
  view: function(ctrl, args) {
    var clickHandler = (args || {}).onclick || function() {
      console.log("no onclick handler assigned");
    }

    var attr = {class: args.hrefClass || "btn btn-default btn-lg btn-function", 
                "data-toggle":"tooltip",
                "onclick": clickHandler,
                "data-placement":"top",
                title:args.tooltip}

    if(!args.enabled()) {
      attr.disabled=true;
    }

    return m("a",attr,[m("div", {class: args.functionClass ? args.functionClass : "function"}, [m("span", {class:"glyphicon " + args.imageClass + " " + (args.addClass ? args.addClass() : ""), "aria-hidden":"true"}, args.imageRenderer ? args.imageRenderer.view(ctrl, args) : [])])]);
  }
}

var FunctionSelectAll = {
  view: function(ctrl, args) {
    return <span class="glyphicon glyphicon glyphicon-select-all"  aria-hidden="false"><svg height="19" width="19">
      <path d="M0 0 L18 0 L18 18 L0 18 Z" style="fill:none;stroke:rgb(51,51,51);stroke-width:2;stroke-dasharray: 2 2">
      </path>
      <line x1="10" y1="12" x2="16" y2="12" style="fill:none;stroke:rgb(51,51,51);stroke-width:2"/>
      <line x1="13" y1="9" x2="13" y2="15" style="fill:none;stroke:rgb(51,51,51);stroke-width:2"/>  
      </svg></span>
  }
}

var FunctionDeselectAll = {
  view: function(ctrl, args) {
    return <span class="glyphicon glyphicon glyphicon-select-all" aria-hidden="false"><svg height="19" width="19">
      <path d="M0 0 L18 0 L18 18 L0 18 Z" style="fill:none;stroke:rgb(51,51,51);stroke-width:2;stroke-dasharray: 2 2">
      </path>
      <line x1="10" y1="12" x2="16" y2="12" style="fill:none;stroke:rgb(51,51,51);stroke-width:2"></line>
      </svg></span>
  }
}

/**
 * fnMap is a Map (Object), where the key uniquely denotes a functionbutton, 
 * the value is supposed to contain :imageClass e.g. glyphicon-plus, 
 * a :tooltip a onclick handler fn that is internally wrapped, so one can programatically
 * replace a function button listener, 
 * an optional :imageRenderer which is itself a mithril view component
 */
var FunctionPanel = function(fnMap) {

  var $ = {fnMap: new Map()};

  $.indirection = function(key) {
    if(this.fnMap[key].onclickFn()) {
      (this.fnMap[key].onclickFn())();
    } else {
      console.log(key + " pressed");
    }
  }

  for (var key in fnMap) {
    var val = fnMap[key];
    val.key = key;
    val.onclickFn = m.prop(val.onclick);
    val.onclick = $.indirection.bind($, key);
    val.enabled = m.prop(val.enabled !== undefined ? val.enabled : true);
    $.fnMap[key] = val;
  }

  //supposed to be called by some controller that scopes this thing in
  $.view = function(ctrl, args) {
    var xs = [];
    for(var key in $.fnMap) {
      if($.fnMap[key].enabled()) xs.push(m.component(FunctionComp, $.fnMap[key]));
    }
    return xs;
  };

  $.disableAll = function() {
    for(var key in $.fnMap) {
      $.fnMap[key].enabled(false);
    }
  };

  $.enable = function(key, enable) {
    if($.fnMap[key]) {
      $.fnMap[key].enabled(enable);
    }
  };

  $.enabled = function(key) {
    if($.fnMap[key]) {
      return $.fnMap[key].enabled();
    }
  };

  $.setOnclick = function(key, handler) {
    if($.fnMap[key]) {
      $.fnMap[key].onclickFn(handler);
    }
  };

  return $;

}



/**
 * BigSID - Big SID Card Component, used to display details on a SID as well as SID Creation, the model is injected from the outside and is a lambdaroyal memory tupel, consisting of the key as well as the data
 */
var BigSID = function(model, options) {

  var $ = {model: (model || [undefined, {coll: "stock", amount: 1}])};

  //setting attributes (to default values)
  var settings = {

    /** log debug messages. */
    debug: true,
    //time(ms) relevant mouseevents gets throttled
    throttleTime: 50,
    ///states whether this card is used for creating new sids or to edit existing ones
    editMode: false,
    //callback on edit toggle
    onedit: function(edit, path, args) {},
    //callback on input
    oninput: function(value, path, args) {},
    //callback on enter
    onsubmit: function(path, args) {},
    //callback on escape
    oncancel: function(path, args) {},
    //denotes whether we just show the SID ident or create new SIDs and therefor show the numberrange component
    numberrangeComp: undefined,
    //callback that renders a portion inside the card after all invariant content  
    footerRenderer: undefined,
    //mutable state representing the current editfield, necessary if this instance is created during mithril's repaint phase rather than in view model init phase. For the later we have just one instance for the whole lifecycle whereas for the first we need to track the state of the editfield independent of the lifetime of this instance
    editField: m.prop(undefined),
    editPath: m.prop(undefined),
    shadow: m.prop(undefined)
  }
  if (!options) { options = {}; }

  // Overwrite and define settings with options if they exist.
  for (var key in settings) {
    if (typeof options[key] !== 'undefined') {
      $[key] = options[key];
    } else {
      $[key] = settings[key];
    }
  }

  var tuneModel = function(model) {
    if(model[1]._amountHistory === undefined) {
      model[1]._amountHistory = [model[1].amount];
      if(model[1].origAmount && model[1].origAmount > model[1].amount) {
        model[1]._amountHistory.push(model[1].origAmount - model[1].amount);
        model[1]._amountRatio = (model[1].amount / model[1].origAmount * 100).toFixed(0);
      }
    }
  }

  tuneModel($.model);

  $.disableEdit = function() {
    m.startComputation();
    $.editField(undefined);
    m.endComputation();
  }

  if($.numberrangeComp) {
    $.numberrangeComp.disableEditOnWrapper = $.disableEdit;
  }

  $.docPath = function(path, attr) {
    return docPath($.model, path, attr, settings.nonEditEmptyText)
  }

  $.stopEdit = function(path, attr, cancel) {
    var x = $.pathToString(path, attr);
    m.startComputation();

    $.editField(undefined);

    //invoke higher order listener
    $.onedit(false, path, attr, cancel);
    m.endComputation();
  }

  $.onclick = function(path, attr) {
    var x = $.pathToString(path, attr);
    m.startComputation();

    if($.isEdit(x)) {
      $.editField(undefined);
    } else {
      //check whether another field was active before, trigger listener
      if($.editField()) {
        $.onedit(false, $.editPath[0], $.editPath[1], false);
      }
      
      //remind current model value for reset
      $.shadow(docPath($.model, path, attr));

      $.editField(x);
    }

    //remind current path as old one
    $.editPath = [path, attr];

    //invoke higher order listener
    $.onedit($.isEdit(x), path, attr, false);

    //focus the issue
    if($.isEdit(x)) {
      setTimeout(function() {
        var div = document.getElementById(x);
        if(div) {
          div.focus();
        }
      }, 20);
    }
    m.endComputation();
  }

  $.isEdit = function(x) {
    return x == $.editField();
  }

  //given a lambdamemory tupel data path consisting of path elements [path] and an attribute [attr] returns a string representation for easy mapping
  $.pathToString = function(path, args) {
    return pathToString(path,args);
  }

  $.renderLocation = function() {
    //fail fast
    if(!$.model[1].location)
      return "-";
    if(!$.model[1].location[0])
      return "-";
    if(!global.rampup.cardmeta.location)
      return "n/a";
    var res = global.rampup.cardmeta.location[1]["ui-trim"].reduce(function(acc,x,index) {
      var key = x[0];
      var val = $.model[1].location[1][key];
      if(val) {
        if(index > 0) {
          acc.append("-");
        }
        acc.append(("" + val).substring(0, x[1]));
      }
      return acc;
    }, new LRStringBuffer());
    return res.toString();
  }

  $.renderJustSID = function() {
    return <div class="padder col-33">
        <div class="group">
          <div class="smallCap">SID</div>
          <div class="small"><div class="table-cell">{$.model[0]}</div></div>
        </div>
      </div>
  }

  $.renderReadOnly = function(path, attr) {
    return <div class="small"><div class="table-cell">{docPath($.model, path, attr, "n/a")}</div></div>
  }

  //renders the amount for small SIDs
  $.renderAmount = function() {
    var width = 110,
        height = 110,
        radius = Math.min(width, height) / 2;

    var pie = d3.layout.pie()
        .sort(null);

    var arc = d3.svg.arc()
        .innerRadius(radius)
        .outerRadius(radius - 10);

    return <div class="small"><svg onclick={$.onclick.bind($, [], "amount")} class="amount" style={"visibility:" + ($.isEdit($.pathToString([],"amount")) ? "hidden" : "")} width={width} height={height}>
      <g transform={"translate(" + width / 2 + "," + height / 2 + " )"}>
      {
        pie($.model[1]._amountHistory).map(function(x, i) {
          return <path fill={$.model[1]._amountColor} d={arc(x)}/>;
        })
      }
      <text type="number" class="amount" text-anchor="middle" x="0" y="0.3em">{docPath($.model, [], "amount", "n/a")}</text>
      <text class="uom" text-anchor={$.model[1]._amountRatio ? "end" : "middle"} 
    x={$.model[1]._amountRatio ? "-2" : "0"} 
    y="1.7em">{docPath($.model, ["article","uom"], "ident", "")}</text>
      <text class="uom" text-anchor={$.model[1]._amountRatio ? "start" : "middle"} 
    x="2" 
    y="1.7em">{docPath($.model, ["article","uom"], "ident", "")}</text>
      </g></svg></div>;
  }

  $.renderEditableField = function(path, attr, options) {
    //setting attributes (to default values)
    var settings = {
      type: "text",
      editEmptyText: "",
      nonEditEmptyText: "-",
      editCssClass : "small",
      nonEditCssClass : "",
      nonEditRenderer: undefined,
      editDivCssClass: "small"
    }
    if (!options) { options = {}; }

    // Overwrite and define settings with options if they exist.
    for (var key in settings) {
      if (typeof options[key] !== 'undefined') {
        settings[key] = options[key];
      }
    }

    //fail fast if we are in edit mode
    if($.editMode && path.length > 0) {
      return $.renderReadOnly(path, attr)
    }
    
    var id = $.pathToString(path, attr); 
    if(!$.isEdit(id)) {
      if(settings.nonEditRenderer) {
        return settings.nonEditRenderer();
      } else {
        return <div class={"big " + settings.nonEditCssClass} 
        onclick={$.onclick.bind($, path, attr)}><div class="table-cell">
          {docPath($.model, path, attr, settings.nonEditEmptyText)}</div></div>
      }
    } else {
      return <div class={settings.editDivCssClass}><input class={"big " + settings.editCssClass} id={id} type={settings.type}
      onfocus="this.value = this.value;"
      onkeyup={$.onkeyup.bind($, path, attr)} 
      value={docPath($.model, path, attr, settings.editEmptyText)} 
      oninput={m.withAttr("value", $.onvaluechange.bind($, path, attr))} 
      sonblur={$.onclick.bind($, path, attr)}/></div>
    }

  }

  $.onvaluechange = function(path, attr, value) {
    setAttrToPath($.model, path, attr, value);
    $.oninput(path, attr, value);
  }

  $.onkeyup = function(path, attr, event) {
    switch(event.keyCode) {
    case 13: $.stopEdit(path, attr, false); $.onsubmit(path, attr); break;
    case 27: setAttrToPath($.model, path, attr, $.shadow()); $.stopEdit(path, attr, true); $.oncancel(path, attr); break;
    }}

  $.openPdf = function(pdf) {
    window.open('/printing/result?file=' + pdf);
  }

  $.renderFunel = function(model) {
    if(model[1].initialSidLabel !== undefined) {
      return <a data-toogle="tooltop" data-placement="top" title="Click here to open the attachment in a new tab" onclick={$.openPdf.bind($, model[1].initialSidLabel)}><span class="glyphicons glyphicons-tag"></span></a>
    } else {
      return <div class="big">{String.fromCharCode(160)}</div>      
    }
  }

  $.renderFooter = function() {
    if($.footerRenderer) {
      return <div class="col-100 border-top cardFooter">
        {$.footerRenderer.call($)}
      </div>
    } else {
      return undefined;
    }

  }

  //supposed to be called by some controller that scopes this thing in
  $.view = function() {
    //if we a are create mode then, we have a first row of medium sized elements (since the numberrange comp is quite large) rather than small ones
    var groupClass = !$.editMode ? "group medium col-33 editable" : "group col-33 editable";
    var valueClass = !$.editMode ? "medium" : "small";
    var inputClass = !$.editMode ? "medium" : "small";
    return <div id="cardPanel">
      <div class={"card bigCard " + $.model[1].coll}>
        <div class="col-66 noPadding border-bottom">
          <div class="spacer"></div>
        </div>
        <div class="border-left-top-right noPadding bg funel-container" style="overflow: auto;">
          <div class="funel" style="text-align: center">
            {$.renderFunel(model)}
          </div>
        </div>
      <div class="col-100 border-left-bottom-right bg shadow">
      {$.numberrangeComp ? $.numberrangeComp.view() : $.renderJustSID()}
      <div class="padder col-33">
      <div class={!$.editMode ? "group medium col-33 editable" : "group col-33"}>
      <div class="smallCap">Item</div>
      {$.renderEditableField(["article"], "ident", {nonEditCssClass: valueClass, editCssClass: inputClass})}
    </div>
      </div>
      <div class="padder-noRuler col-33">
      <div class={groupClass}>
      <div class="smallCap">Amount</div>
      {$.renderEditableField([], "amount", {nonEditCssClass: valueClass, editCssClass: inputClass, type: "number"})}
    </div>
    </div>
      <div class="padder col-33">
      <div class="group editable">
      <div class="smallCap">Inbound</div>
      {$.renderEditableField([], "creation-date", {type: "date", nonEditCssClass: "small", editDivCssClass: "small"})}
    </div>
      </div>

      <div class="padder col-33">
      <div class="group">
      <div class="smallCap">Location</div>
      <div class="small"><div class="table-cell">{$.renderLocation()}</div></div>
      </div>
      </div>
      <div class="padder-noRuler col-33">
      <div class="group">
      <div class="smallCap">Description</div>
      <div class="small"><div class="table-cell">{docPath($.model, ["article"], "description", "-")}</div></div>
      </div>
      </div>
      <div class="padder col-33">
      <div class="group group-noBorder">
      <div class="smallCap">Unit</div>
      <div class="small"><div class="table-cell">{docPath($.model, ["article"], "unit", "-")}</div></div>
      </div>
      </div>
      <div class="padder col-33">
      <div class="group group-noBorder">
      <div class="smallCap">Client</div>
      <div class="small"><div class="table-cell">{docPath($.model, ["article"], "client", "-")}</div></div>
      </div>
      </div>
      <div class="padder-noRuler col-33">
      <div class="group group-noBorder editable">
      <div class="smallCap">Batch</div>
      {$.renderEditableField([], "batch", {type: "string", nonEditCssClass: "small", editDivCssClass: "small"})}
      </div>
      </div>

      <div class="col-100"><div class="spacer"></div></div>
      {$.renderFooter()}
    </div>
      </div>
</div>

  };

  return $;

}

/**
 * SIDNumberrangeComp - takes a array of numberranges as well as the current numberrange into account and the count of numbers to display or take. all parameters are supposed to be properties (mithril functions) 
 */
var SIDNumberrangeComp = function(numberranges, currentNumberrangeId, count) {

  var $ = {previousNumberrangeEnabled: m.prop(false),
           nextNumberrangeEnabled: m.prop(false),
           currentIndex: undefined,
           //denotes a function that if set disables edit mode on the wrapping component
           disableEditOnWrapper: undefined,
           //denotes a function that is supposed to consume a (1) callback that must be called afterwards and (2) the nrange ust. The function passed in is supposed to be a partial function that is bound to the callback parameter already
           onRollForward: undefined,
           //a property set from the context that needs to be informed
           currentNumberrange: undefined};

  //gets the currently used numberrange from global.rampup.numberranges
  $.getNumberrange = function() {
    currentIndex: undefined;
    //fail fast
    if(numberranges()) {
      //get the one that is assigned to the user
      if(currentNumberrangeId()) {
        return numberranges().find(function(n, i) {
          if(n[0] == currentNumberrangeId()) {
            $.currentIndex = i;
            return true;
          }
          return false;
        });
      } else {
        //just take the first one - prefiltered!!
        var nrange = numberranges().find(function(n, i) {
          $.currentIndex = i;
          return true;
        }); 
        //tell the session (and indirectly the server to modify the user)
        if(nrange) {
          currentNumberrangeId(nrange[0]);
          return nrange;
        }
      }
    }

    return null;
  }

  //renders the amount for small SIDs
  $.renderNumberrangeCapacity = function(nrange) {
    nrange = nrange[1];
    var width = 55,
        height = 55,
        radius = Math.min(width, height) / 2;

    var pie = d3.layout.pie()
        .sort(null);

    var arc = d3.svg.arc()
        .innerRadius(radius)
        .outerRadius(radius - 3);
    var arcBold = d3.svg.arc()
        .innerRadius(radius)
        .outerRadius(radius - 5);
    var percentageLeft = (nrange.max - nrange.running) <= 0 ? 0 : (1 + (nrange.max - nrange.running)) / nrange.items * 100;

    return <svg class="numberrange" width={width} height={height}>
      <g transform={"translate(" + width / 2 + "," + height / 2 + " )"}>
      {
        pie([nrange.items - (nrange.max - nrange.running), (nrange.max - nrange.running)]).map(function(x, i) {
          return <path fill={i > 0 ? "#3e4690" : "#bcb4d6"} d={i==0 ? arc(x) : arcBold(x)}/>;
        })
      }
      <text type="number" class="percentage" text-anchor="middle" x="0" y="0.3em">{Math.round(percentageLeft) + "%"}</text>
      <text type="number" class="explanation" text-anchor="middle" x="0" y="1.3em">left</text>
      </g></svg>;
  }

  $.renderSidRange = function(nrange) {
    if(count() == 1) {
      return <div class="top">
        <div class="leftCompressed">{nrange[1].running}</div>
        {FunctionComp.view(null, {hrefClass:" ", imageClass: "glyphicon glyphicon-arrow-down", tooltip:"Skip to the next number visible on your numberrange roller", enabled: m.prop(true), onclick: function() {
          if($.disableEditOnWrapper) {
            $.disableEditOnWrapper();
          }

          if ($.onRollForward) $.onRollForward(numberranges()[$.currentIndex])
        }})}
      </div>
    } else {
      return <div class="top"><div class="leftCompressed">{nrange[1].running}</div>
        {FunctionComp.view(null, {hrefClass:" ", imageClass: "glyphicon glyphicon-arrow-down", tooltip:"Skip to the next number visible on your numberrange roller", enabled: m.prop(true), onclick: function() {
          if($.disableEditOnWrapper) {
            $.disableEditOnWrapper();
          }
          if ($.onRollForward) $.onRollForward(numberranges()[$.currentIndex])
        }})}
        <div class="left">{(parseInt(nrange[1].running) + parseInt(count()) - 1)}</div></div>
    }
  }

  $.onPreviousNumberrange = function() {
    if($.disableEditOnWrapper) {
      $.disableEditOnWrapper();
    }
    
    if($.currentIndex > 0) {
      $.currentIndex = $.currentIndex - 1;
      var nrange = numberranges()[$.currentIndex];
      currentNumberrangeId(nrange[0]);
    }

    $.previousNumberrangeEnabled($.currentIndex != 0);
  }

  $.onNextNumberrange = function() {
    if($.disableEditOnWrapper) {
      $.disableEditOnWrapper();
    }
    
    if(numberranges().length > ($.currentIndex + 1)) {
      $.currentIndex = $.currentIndex + 1;
      var nrange = numberranges()[$.currentIndex];
      currentNumberrangeId(nrange[0]);
    }
    $.nextNumberrangeEnabled(numberranges().length > ($.currentIndex + 1));
  }

  $.renderNumberrange = function() {
    var nrange = $.getNumberrange();
    if($.currentNumberrange) {
      $.currentNumberrange(nrange);
    }

    //check bounds to enable/disable buttons
    $.previousNumberrangeEnabled(false);
    $.nextNumberrangeEnabled(false);
    if(nrange) {
      $.previousNumberrangeEnabled($.currentIndex != 0);
      $.nextNumberrangeEnabled(numberranges().length > $.currentIndex + 1);

      return <div class="padder col-33">
        <div class="group medium col-33 editable">
        <div class="smallCap">SID</div>
        <div class="medium">
        <div class="subgroup" style="width: 50%">
        <div class="subgroupCapLeft">New Ident</div>
        {$.renderSidRange(nrange)}
      </div>
        <div class="subgroup" style="width: 50%">
        <div class="subgroupCap">Number Range</div>
        {$.renderNumberrangeCapacity(nrange)}
        <div class="col-2-center">
        {  FunctionComp.view(null, {hrefClass:" ", functionClass: "functionCenter", imageClass: "glyphicon-arrow-left", tooltip:"Choose the previous numberrange", enabled: $.previousNumberrangeEnabled, onclick: $.onPreviousNumberrange.bind($)})}
      </div>
        <div class="col-2-center">
        {  FunctionComp.view(null, {hrefClass:" ", functionClass: "functionCenter", imageClass: "glyphicon-arrow-right", tooltip:"Choose the next numberrange", enabled: $.nextNumberrangeEnabled, onclick: $.onNextNumberrange.bind($)})}
      </div>
        </div>
        </div>
        </div>
        </div>
        
    } else {
      return <div class="padder col-33">
        <div class="group medium">
        <div class="smallCap">SID</div>
        <div class="medium">n/a</div>
        </div>
        </div>
    }
  }

  //supposed to be called by some controller that scopes this thing in
  $.view = function() {
    return $.renderNumberrange();
  };

  return $;

}

var StatsComp = function(rootSelection, model) {
  $ = model || {};
  $["sid-count"] = $["sid-count"] || 0;
  $["lid-count"] = $["lid-count"] || 0;
  $.sidReservedCount = model.sidReservedCount || 0;

  $.viewModel = function() {
    var model = [{icon: "glyphicons-cargo", count: $["lid-count"], title: "Number of LIDs"},
            {icon: "glyphicons-sort", count: $["sid-count"], title: "Number of SIDs"},
            {icon: "glyphicons-unlock", count: $["sid-count"], title: "Number of available SIDs"}];
    if($.delay) {
      model.push({icon: "glyphicons-stopwatch", count: $.delay, title: "runtime of most recent search batch", id: "delay"})
    }

    return model;
  }

  $.view = function() {
    var data = $.viewModel();
    var categories = rootSelection.append("div").attr("class", "statsContainer")
    .append("div").attr("class", "stats").selectAll("div.category")
    .data(data, function(n) { 
      return n.icon; 
    })
    .enter().append("div").attr("class","category");
    categories.append("span").attr("class", function(n) {
      return "glyphicons " + n.icon;
    })
    .attr("data-toogle", "tooltop")
    .attr("data-placement", "top")
    .attr("title", function(n) {
      return n.title;
    });
    categories.append("span").attr("class", "count")
    .attr("data-toogle", "tooltop")
    .attr("data-placement", "top")
    .attr("id", function(n) {
      return n.icon;
    })
    .attr("title", function(n) {
      return n.title;
    })
    .text(function(n) {
      return n.count;
    })
  }

  $.update = function() {
    var data = $.viewModel();
    var categories = rootSelection.selectAll("span.count").data(data, function(n) {
      return n.icon;
    })
    .text(function(n) {
      if(n.id && n.id === "delay") {
        return n.count + "ms";
      } else {
        return n.count;
      }
    })

  }

  return $;
}
