//dataimport.mithril.js

var Cardtype = function(data) {
  data = data || {}
  this.id = m.prop(data[0])
}
Cardtype.list = function(data) {
  return m.request({method: "GET", url:"/cardtype", data:data})
}

var Cardtypeimportdefinition = function(data) {
  data = data || {}
}
Cardtypeimportdefinition.list = function(data) {
  return m.request({method: "GET", url:"/cardtypeimportdefinition", data:data})
}

var dataimport = {}

dataimport.vm = {
  init: function() {
    dataimport.vm.cardtypes = Cardtype.list();
    dataimport.vm.process = new UIProcess();
    var chooseCardtype = new UIProcessStep();
    chooseCardtype.title = "Choose Cardtype to import data for";
    chooseCardtype.cancel = null;
    chooseCardtype.component = {view: function(ctrl, args) {
      
      return m("table",[
        dataimport.vm.cardtypes().map(function(cardtype) {
          return m("tr", 
                   [m("td", cardtype)]);
        })
      ])
    }};

    dataimport.vm.process.add(chooseCardtype);

    var chooseImportdefinition = new UIProcessStep();
    chooseImportdefinition.title = "Choose Importdefinition and file to upload";
    chooseImportdefinition.onEnter = function(retainContent, callback) {
      if(!retainContent) {
        dataimport.vm.cardtypeimportdefinitions = Cardtypeimportdefinition.list();
        dataimport.vm.cardtypeimportdefinitions.then(function() { 
          callback()
        });

      } else {
        callback();
      }
    };
    chooseImportdefinition.component = {
      view: function(ctrl, args) {
        return m("div[class=progress]", [
          m("div",{"class":"progress-bar", 
                   "role":"progressbar", 
                   "aria-valuenow":"60", 
                   "aria-valuemin":"0", 
                   "aria-valuemax": "100", 
                   "style": "width:50%"},"Achtung: 40%")

        ]);

      }
    }
    dataimport.vm.process.add(chooseImportdefinition);
    

    var step = new UIProcessStep();
    step.title = "Sneak Preview";
    step.interactive = false;
    dataimport.vm.process.add(step);
    
    for(var i = 0; i < 100; i++) {

      
      var step = new UIProcessStep();
      step.title = "Confirm Upload " + i;
      dataimport.vm.process.add(step);
    }
    var step = new UIProcessStep();
    step.title = "Confirm Upload the second time";
    step.submit = "Yes, I am"
    dataimport.vm.process.add(step);


    dataimport.vm.process.init();
    
  }
}

dataimport.controller = function() {
  dataimport.vm.init();
};
dataimport.view = function(ctrl) {
  return m.component(UIProcessComp, {process: dataimport.vm.process});
};
