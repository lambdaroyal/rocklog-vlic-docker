vlic.controller('worldmapCtrl', function ($scope, focus, $http, $location, $websocket) {
  
  
  //resets the form in order to allow the user to submit a new search
  $scope.keyUp = function(e) {
    if(e.which == 27) {
    }
  };

  (function initWorldmap(){
    $http.get('assets/js/worldmapData.json')
      .then(function(res) {
        $scope.data = res.data;

        var worldWith = window.innerWidth - 30,
            mapRatio = 0.4,
            worldHeight = worldWith * mapRatio,
            scale = worldWith / 1000;
        var paper = Raphael(document.getElementById("worldmap"), worldWith, worldHeight);
        paper.rect(0, 0, worldWith, worldHeight, 10).attr({
          stroke: "none"
        });
        paper.setStart();
        for (var country in $scope.data.shapes) {
          paper.path($scope.data.shapes[country]).attr({
            'stroke': '#05121b',
            'stroke-width': 0.5,
            'stroke-opacity': 0.25,
            fill: "#67777F",
            "fill-opacity": 0.25
          }).transform("s" + scale + "," + scale + " 0,0");
        }
        var world = paper.setFinish();
        world.getXY = function(lat, lon) {
          return {
            cx: lon * (2.6938 * scale) + (465.4 * scale),
            cy: lat * (-2.6938 * scale) + (227.066 * scale)
          };
        };
      });
  }());

  (function initWebSocket(){
      var path = 'ws://' + $location.$$host + ':' + $location.$$port + '/worldmap/event';

      $scope.websocket = $websocket.$new({url: path,
                                                 lazy: false,
                                                 enqueue: false,
                                                 reconnect: true,
                                                 protocols: []});
      $scope.websocket
        .$on('$close', function () {
          console.log('worldmap ws closed.');
        });


  }());

})
